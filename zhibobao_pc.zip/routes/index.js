var express = require('express');
var router = express.Router();

var routerMain = require('./main.js');
var tvDomain = require('./tvDomain');

var moment = require('moment');
var industry = require('../data/industry');
var platformList = require('../data/platformList');
var categoryList = require('../data/categoryList');
var rankList = require('../data/rankList');
var timeList = require('../data/timeList');
var anchorInfo = require('../data/anchorInfo');

router.get('/', routerMain);

router.get('/data', routerMain);

router.get('/tool', function(req, res, next) {
	res.render('page/tool/tool', {
		g_isTvDomain: tvDomain(req.hostname),
		pageType: 'tool',
		title: '专业游戏直播工具_直播宝_直播平台大数据'
	});
});

router.get('/rank', function(req, res, next) {
	var opts = {};
	// var optsField = ['userType', 'platform', 'category', 'timeType', 'timeValue'];

	// 平台
	var platformListData = platformList(req.query);
	opts.platform = platformListData.curPlatform;
	// userType
	var userTypeList = ['anchor', 'new_anchor', 'user'];
	for (var i = 0, len = userTypeList.length; i < len; i++) {
		if (userTypeList[i] == req.query['userType']) {
			opts.userType = userTypeList[i];
			break;
		}
	}
	if (!opts.userType) {
		opts.userType = 'anchor';
	}
	// category
	opts.category = req.query['category'];
	// time
	opts.timeType = req.query['timeType'];
	opts.timeValue = req.query['timeValue'];

	var arrRequest = [];
	// userType == 'user' 的只有礼物没有弹幕
	if (opts.userType != 'user') {
		arrRequest = [platformListData, categoryList(Object.assign({}, opts, {
			'platform': '',
			'allCategory': true
		})), timeList(opts), rankList(Object.assign({}, opts, {
			'rankType': 'gift',
			'limit': 100
		})), rankList(Object.assign({}, opts, {
			'rankType': 'barrage',
			'limit': 100
		}))];
	} else {
		arrRequest = [platformListData, categoryList(Object.assign({}, opts, {
			'platform': '',
			'allCategory': true
		})), timeList(opts), rankList(Object.assign({}, opts, {
			'rankType': 'gift',
			'limit': 100
		}))];
	}

	Promise.all(arrRequest).then((arrValue) => {
		var platformListData = arrValue[0];
		var categoryListData = arrValue[1];
		var timeListData = arrValue[2];
		var rankListGiftData = arrValue[3];
		var rankListBarrageData, updateTime;
		if (opts.userType != 'user') {
			rankListBarrageData = arrValue[4];
			updateTime = Math.max(parseInt(rankListGiftData.data.timestamp), parseInt(rankListBarrageData.data.timestamp));
		} else {
			updateTime = parseInt(rankListGiftData.data.timestamp);
		}
		updateTime = moment(updateTime * 1000).format('HH:mm');

		res.render('page/rank/rank', {
			g_isTvDomain: tvDomain(req.hostname),
			pageType: 'rank',
			title: '主播榜单_直播宝_直播平台大数据',
			curUserType: opts.userType,
			curPlatform: opts.platform,
			curCategory: categoryListData.curCategory,
			curTimeType: timeListData.curTimeType,
			curTimeValue: timeListData.curTimeValue,
			platformListData: platformListData,
			rankListGiftData: rankListGiftData,
			rankListBarrageData: rankListBarrageData,
			categoryListData: categoryListData,
			updateTime: updateTime,
			timeListData: timeListData
		});
	}).catch((e) => {
		console.warn('===== warn =====', e);
		res.render('error', {
			message: e.msg,
			code: e.code
		});
	});
});

router.get('/platform', function(req, res, next) {
	var arrRequest = [platformList({}), categoryList({}), timeList({})];

	Promise.all(arrRequest).then((arrValue) => {
		var platformListData = arrValue[0];
		var categoryListData = arrValue[1];
		var timeListData = arrValue[2];

		res.render('page/platform/platform', {
			g_isTvDomain: tvDomain(req.hostname),
			pageType: 'platform',
			title: '直播行业数据_直播宝_直播平台大数据',
			platformListData: platformListData,
			categoryListData: categoryListData,
			timeListData: timeListData
		});
	}).catch((e) => {
		console.warn('===== warn =====', e);
		res.render('error', {
			message: e.msg,
			code: e.code
		});
	});
});

router.get('/anchor', function(req, res, next) {
	var opts = {
		platform: req.query['platform'],
		roomId: req.query['roomId']
	};

	var arrRequest = [anchorInfo(opts)];

	Promise.all(arrRequest).then((arrValue) => {
		var anchorInfoData = arrValue[0];

		var title = anchorInfoData.info.nickname + '_' + anchorInfoData.info.platformName + anchorInfoData.info.cateName + '主播' + '_直播宝_直播平台大数据';

		res.render('page/anchor/anchor', {
			g_isTvDomain: tvDomain(req.hostname),
			title: title,
			pageType: 'anchor',
			isNewHeadClass: true,
			anchorInfoData: anchorInfoData
		});
	}).catch((e) => {
		console.warn('===== warn =====', e);

		res.render('page/anchor/anchor', {
			g_isTvDomain: tvDomain(req.hostname),
			title: '主播_直播宝_直播平台大数据',
			pageType: 'anchor',
			isNewHeadClass: true,
			anchorInfoData: {}
		});
	});
});

router.get('/search', function(req, res, next) {
	var opts = {
		search: req.query['search']
	};

	var arrRequest = [];

	Promise.all(arrRequest).then((arrValue) => {
		res.render('page/search/search', {
			g_isTvDomain: tvDomain(req.hostname),
			title: '主播搜索_直播宝_直播平台大数据',
			isNewHeadClass: true
		});
	}).catch((e) => {
		console.warn('===== warn =====', e);
		res.render('error', {
			message: e.msg,
			code: e.code
		});
	});
});


router.get('/liveReport', function(req, res, next) {
	var opts = {
		platform: req.query['platform'],
		roomId: req.query['roomId'],
	};

	function durationString(duration) {
		var str = '';
		if (duration >= 3600) {
			var hour = parseInt(duration / 3600);
			var min = parseInt((duration - hour * 3600) / 60);
			str = hour + '小时' + min + '分钟';
		} else {
			var min = parseInt(duration / 60);
			str = min + '分钟';
		}
		return str;
	};

	var arrRequest = [anchorInfo(opts)];

	Promise.all(arrRequest).then((arrValue) => {
		var anchorInfoData = arrValue[0];

		var title = anchorInfoData.info.nickname + '_直播小结_' + anchorInfoData.info.platformName + anchorInfoData.info.cateName + '主播' + '_直播宝_直播平台大数据';

		// 开播时间，持续时间
		var startTime = moment(parseInt(req.query['start']) * 1000).format('YYYY/MM/DD HH:mm');
		var duration = parseInt(req.query['stop']) - parseInt(req.query['start']);
		var strHtml = startTime + ' 开播，共播了<span class="special-text">' + durationString(duration) + '</span>';

		res.render('page/liveReport/liveReport', {
			title: title,
			anchorInfoData: anchorInfoData,
			durationHtml: strHtml
		});
	}).catch((e) => {
		console.warn('===== warn =====', e);
		
		res.render('page/liveReport/liveReport', {
			title: '直播小结_直播宝_直播平台大数据',
			anchorInfoData: {}
		});
	});
});


module.exports = router;