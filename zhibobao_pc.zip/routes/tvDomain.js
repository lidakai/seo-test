module.exports = function(hostname) {
	return hostname == 'www.zhibobao.tv' ? true : false;
};