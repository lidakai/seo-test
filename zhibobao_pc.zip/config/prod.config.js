module.exports = {
	env: 'prod',
	proxy: 'http://api.zhibobao.com',
	port: 3002
};