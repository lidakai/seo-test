define(function(require) {
    // 302
    var MOBILE_UA_REGEXP = /(iPhone|iPod|Android|ios|iOS|iPad|Backerry|WebOS|Symbian|Windows Phone|Phone|Prerender|MicroMessenger)/i;
    if (MOBILE_UA_REGEXP.test(navigator.userAgent)) {
        var pathname = location.pathname;
        var search = location.search;
        window.location.replace(ZBB.mDomain + pathname + search);
        return;
    }

    var Header = require('widget/header');
    var Footer = require('widget/footer');

    var oPage = {
        init: function() {
            this.render();
            this.bindEvent();
        },
        render: function() {
            this.header = new Header('index');
            $('.main-header').append(this.header.$el);

            var footer = new Footer();
            $('.main-footer').append(footer.$el);
        },
        bindEvent: function() {
            var self = this;
            var height = window.innerHeight;
            $(document).scroll(
                _.debounce(function() {
                    var h = $(this).scrollTop();
                    if (h > height) {
                        $(".back_top").show();
                    } else {
                        $(".back_top").hide();
                    }

                }, 100)
            );

            $(".back_top").on('click', function() {
                $('html,body').animate({
                    scrollTop: 0
                }, 500, 'swing');
            })
        }
    };

    var pages = {
        'index': require('page/index'),
        'rank': require('page/rank'),
        'platform': require('page/platform')
    };

    var navIndexList = {
        'index': 0,
        'rank': 1,
        'platform': 2
    };

    var currentPage;
    var enterPage = function(name, pageContent) {
        if (name == 'index' || name == 'platform') {
            $(document).scrollTop(0);
        }

        // oPage.header.activeNav(navIndexList[name]);

        var $main_body = $('.main-body');
        $main_body.append(pageContent.$el);

        currentPage = pageContent;
    };

    var router = function(name) {
        return function(ctx) {
            if (currentPage) {
                currentPage.destroy();
            }
            var factory = pages[name] || pages.index;
            factory(ctx, function(page) {
                enterPage(name, page);
            });
        };
    };


    oPage.init();

    page('/rank', router('rank'));
    page('/platform', router('platform'));
    if(window.location.hostname == 'www.zhibobao.com'){
        page('/', router('index'));
    }else{
        page('/data', router('index'));
    }


    page();


});