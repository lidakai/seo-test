define(function(require) {
    // 302
    var MOBILE_UA_REGEXP = /(iPhone|iPod|Android|ios|iOS|iPad|Backerry|WebOS|Symbian|Windows Phone|Phone|Prerender|MicroMessenger)/i;
    if (MOBILE_UA_REGEXP.test(navigator.userAgent)) {
        var pathname = location.pathname;
        var search = location.search;
        window.location.replace(ZBB.mDomain + pathname + search);
        return;
    }

    var Header = require('widget/header');
    var Footer = require('widget/footer');
    var Search = require("widget/search");
    var SearchResult = require("widget/searchResult");
    var Pagination = require("widget/pagination");

    var $body = $('body');
    var $main_search = $body.find('.main-search');
    var $main_body = $body.find('.main-body');

    var oPage = {
        init: function() {
            var urlRequestParams = ZBB.urlRequestParams();
            if (urlRequestParams['search']) {
                this.search = decodeURIComponent(urlRequestParams['search']);
            }
            this.render();
            this.bindEvent();
        },
        render: function() {
            var header = new Header('search');
            header.$el.addClass("w-header-new");
            $('.main-header').append(header.$el);

            var footer = new Footer();
            $('.main-footer').append(footer.$el);

            this.searchCons = new Search({
                search: this.search,
                flag: 'search'
            });
            $main_search.html(this.searchCons.$el);

            this.searchResult = new SearchResult({
                isPagination: true,
                search: this.search
            });
            $main_body.prepend(this.searchResult.$el);

            this.pagination = new Pagination();
            $main_body.append(this.pagination.$el);
        },
        bindEvent: function() {
            var self = this;
            $.sub('page/change', function(e, data) {
                self.pagination.init(data);
            });
            $.sub('search/getResult', function(e, data) {
                self.searchResult.getData(data);
            });
        }

    };

    oPage.init();



});