var arrPlatform = [{
	'name': '全平台',
	'val': ''
}, {
	'name': '斗鱼',
	'val': 'douyu'
}, {
	'name': '虎牙',
	'val': 'huya'
}, {
	'name': '全民',
	'val': 'quanmin'
}, {
	'name': '熊猫',
	'val': 'panda'
}, {
	'name': '战旗',
	'val': 'zhanqi'
}, {
	'name': '龙珠',
	'val': 'longzhu'
}, {
	'name': '触手',
	'val': 'chushou'
}];

var platformList = (opts) => {
	var curPlatform;

	for (var i = 0, len = arrPlatform.length; i < len; i++) {
		if (arrPlatform[i].val == opts.platform) {
			curPlatform = arrPlatform[i].val;
			break;
		}
	}

	curPlatform = curPlatform || '';

	return {
		list: arrPlatform,
		curPlatform: curPlatform
	}
};

module.exports = platformList;