const request = require('./myRequest');
const globalConfig = require('./global.js');

var rankList = (opts) => {
    opts = opts || {};

    var formData = {
        platform: opts.platform,
        roomId: opts.roomId
    };

    return new Promise(function(resolve, reject) {
        request.get({
            url: '/anchor/info',
            formData: formData
        }, function(error, response, body) {
            if (!error && response.statusCode == 200) {
                var data = JSON.parse(body);
                if (data.code == 0) {
                    data.data.info.avatar = globalConfig.parseAvatar(data.data.info.avatar);
                    data.data.info.platformName = globalConfig.platformName[data.data.info.platform];

                    resolve(data.data);
                } else {
                    reject(data.data);
                    // data.reqUrl = response.req.path;
                    // reject(data);
                }
            }
        });
    });
};

module.exports = rankList;