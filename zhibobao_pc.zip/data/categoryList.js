const request = require('./myRequest');

var categoryList = (opts) => {
    return new Promise(function(resolve, reject) {
        request.get({
            url: '/cate/active/list',
            formData: opts
        }, function(error, response, body) {
            if (!error && response.statusCode == 200) {
                var data = JSON.parse(body);
                if (data.code == 0) {
                    var curCategory;
                    if (opts.allCategory) {
                        data.data.list.unshift({
                            'category': '',
                            'categoryName': '所有'
                        });
                    }

                    for (var i = 0, len = data.data.list.length; i < len; i++) {
                        if (data.data.list[i].category == opts.category) {
                            curCategory = data.data.list[i].category;
                            break;
                        }
                    }

                    data.data.curCategory = curCategory == undefined ? '' : curCategory;

                    resolve(data.data);
                } else {
                    data.reqUrl = response.req.path;
                    reject(data);
                }
            }
        });
    });
};

module.exports = categoryList;