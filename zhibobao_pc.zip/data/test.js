const url = require('url');
var moment = require('moment');

var t = new Date();
// console.log(t);

console.log(moment.duration(120));

// console.log(moment(1318781876406).format('HH:mm'));