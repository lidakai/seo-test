const request = require('request');
const url = require('url');
const crypto = require('crypto');
const md5 = crypto.createHash('md5');
const extend = require('extend');
const config = require('../config');

const domain = config.proxy;

const generateSign = () => {
	var key = 'GapV#&2%b';
	var timestamp = new Date().getTime();
	var md5 = crypto.createHash('md5');
	var sign = md5.update(timestamp + key).digest('hex');
	return {
		sign,
		timestamp
	};
};

const myRequest = function(requestParam) {

};

myRequest.prototype.get = function(opts, callback) {
	var objSign = generateSign();

	if (typeof opts == 'string') {
		request({
			url: domain + opts,
			method: "GET",
			headers: {
				'T-code': objSign.sign
			},
			qs: {
				'_timestamp': objSign.timestamp,
				'source': 0
			}
		}, function(error, response, body) {
			console.log('==== get', response.request.href, body);

			if (typeof callback == 'function') {
				callback(error, response, body);
			}
		});
	} else {
		opts.formData = extend({}, opts.formData, {
			'_timestamp': objSign.timestamp,
			'source': 0
		});

		request({
			url: domain + opts.url,
			method: "GET",
			headers: {
				'T-code': objSign.sign
			},
			qs: opts.formData
		}, function(error, response, body) {
			console.log('==== get', response.request.href, body);

			if (typeof callback == 'function') {
				callback(error, response, body);
			}
		});
	}
};

myRequest.prototype.post = function(opts, callback) {
	var objSign = generateSign();

	opts.formData = extend({}, opts.formData, {
		'_timestamp': objSign.timestamp,
		'source': 0
	});

	request({
		url: domain + opts.url,
		method: "POST",
		json: opts.formData,
		headers: {
			'T-code': objSign.sign
		}
	}, function(error, response, body) {
		console.log('==== post', response.request.href, body);

		if (typeof callback == 'function') {
			callback(error, response, body);
		}
		// if (!error && response.statusCode == 200) {

		// }
	});
};

module.exports = new myRequest();