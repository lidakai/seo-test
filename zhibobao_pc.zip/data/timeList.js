var moment = require('moment');

var timeList = (opts) => {
    opts = opts || {};

    if (!opts.timeType || !opts.timeValue) {
        opts.timeType = 'hour';
        opts.timeValue = 1;
    }

    var arrTimeList = [];
    var curTimeText = '时间选择';

    // 近七天时间字符串
    var now = new Date();
    if (now.getHours() < 2) {
        now.setDate(now.getDate() - 1);
    }
    for (var i = 0; i < 7; i++) {
        now.setDate(now.getDate() - 1);
        let t = moment(now).format('YYYY/MM/DD');
        arrTimeList.push({
            time: t,
            text: t,
            timeType: 'day'
        })
        if (opts.timeType == 'day') {
            if (moment(now).format('YYYYMMDD') == opts.timeValue) {
                curTimeText = moment(now).format('YYYY/MM/DD');
            }
        }
    }

    // 近5周时间字符串
    for (var j = 0; j < 35; j = j + 7) {
        var arr = [];
        var week = new Date();
        week.setDate(week.getDate() - week.getDay() - j);
        arr.push(moment(week).format('YYYY/MM/DD'));
        week.setDate(week.getDate() - week.getDay() - 6);
        arr.unshift(moment(week).format('YYYY/MM/DD'));
        arrTimeList.push({
            time: arr.join(" - "),
            text: arr.join(' - '),
            timeType: "dayRange"
        });
        if (opts.timeType == 'dayRange') {
            if (arr.join(" - ").replace(/\//g, "").replace(/\s/g, "") == opts.timeValue) {
                curTimeText = arr.join(" - ");
            }
        }
    }

    // 近3个月时间字符串
    for (var k = 0; k < 3; k++) {
        var arr = [];
        var text = '';
        var month = new Date();
        month.setMonth(month.getMonth() - k, 1);
        month.setDate(month.getDate() - 1);
        arr.push(moment(month).format('YYYY/MM/DD'));
        month.setMonth(month.getMonth(), 1);
        arr.unshift(moment(month).format('YYYY/MM/DD'));
        text = moment(month).format('YYYY年MM月');
        arrTimeList.push({
            time: arr.join(" - "),
            timeType: "dayRange",
            text: text
        });

        if (opts.timeType == 'dayRange') {
            if (arr.join(" - ").replace(/\//g, "").replace(/\s/g, "") == opts.timeValue) {
                curTimeText = arr.join(" - ");
            }
        }

    }

    return {
        curTimeText: curTimeText,
        timeList: arrTimeList,
        curTimeType: opts.timeType,
        curTimeValue: opts.timeValue
    };
};

module.exports = timeList;