const request = require('./myRequest');

var industry = (objUrlQuery) => {
	return new Promise(function(resolve, reject) {
		request.get({
			url: '/indust/all',
			formData: objUrlQuery
		}, function(error, response, body) {
			if (!error && response.statusCode == 200) {
				var data = JSON.parse(body);
				if (data.code == 0) {
					resolve(data.data);
				} else {
					data.reqUrl = response.req.path;
					reject(data);
				}
			}
		});
	});
};

module.exports = industry;