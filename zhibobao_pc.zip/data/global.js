module.exports = {
	parseAvatar: function(str) {
		if (!str) {
			return this.platformDefaultAvatar['default'];
		}
		if (/^https?:\/\//.test(str)) {
			return str;
		}
		return 'http://fentuan-image.oss-cn-hangzhou.aliyuncs.com/' + str;
	},
	platformDefaultAvatar: {
		default: __uri('/lib/tools/avatar/zhibobao.png'),
		douyu: __uri('/lib/tools/avatar/douyu.png'),
		huya: __uri('/lib/tools/avatar/huya.png'),
		quanmin: __uri('/lib/tools/avatar/quanmin.png'),
		panda: __uri('/lib/tools/avatar/panda.png'),
		zhanqi: __uri('/lib/tools/avatar/zhanqi.png'),
		longzhu: __uri('/lib/tools/avatar/longzhu.png'),
		chushou: __uri('/lib/tools/avatar/chushou.png')
	},
	platformName: {
		douyu: '斗鱼',
		huya: '虎牙',
		quanmin: '全民',
		panda: '熊猫',
		zhanqi: '战旗',
		longzhu: '龙珠',
		chushou: '触手'
	},
	platformUnit: {
		douyu: '鱼翅',
		huya: '金豆',
		quanmin: '牛币',
		panda: '猫币',
		zhanqi: '金币',
		longzhu: '龙币',
		chushou: '触手币'
	}
};