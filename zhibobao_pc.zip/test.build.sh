#!/bin/bash
# rm -rf ../zhibobao_pc_dist/static
# fis2 config
fis release -cmpwd ../zhibobao_pc_dist

# fis3 config
# fis3 release -wd ../zhibobao_pc_dist 
