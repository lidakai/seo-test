define(function(require) {
	// 302
    var MOBILE_UA_REGEXP = /(iPhone|iPod|Android|ios|iOS|iPad|Backerry|WebOS|Symbian|Windows Phone|Phone|Prerender|MicroMessenger)/i;
    if (MOBILE_UA_REGEXP.test(navigator.userAgent)) {
        var urlParams = ZBB.urlRequestParams();
        if (urlParams['isPc']) {

        } else {
            var pathname = location.pathname;
            var search = location.search;
            window.location.replace(ZBB.mDomain + pathname + search);
            return;
        }
    }

	var Header = require('widget/header');
	var Footer = require('widget/footer');

	var CategoryList = require('widget/categoryList_new');
	var IndustryCharts = require('widget/industryCharts');
	var PlatformList = require('widget/platformList_new');
	var PieCharts = require('widget/pieCharts');
	var ResultList = require('widget/resultList');
	var TimeList = require('widget/timeList');
    var iconExhibition = require('widget/iconExhibition');
	var IndicatorList = require('widget/indicatorList');

	var oPage = {
		init: function() {
			this.render();
			this.bindEvent();
		},
		render: function() {
			this.header = new Header('index');
		},
		bindEvent: function() {
			var self = this;
			var height = window.innerHeight;
			$(document).scroll(
				_.debounce(function() {
					var h = $(this).scrollTop();
					if (h > height) {
						$(".back_top").show();
					} else {
						$(".back_top").hide();
					}

				}, 100)
			);

			$(".back_top").on('click', function() {
				$('html,body').animate({
					scrollTop: 0
				}, 500, 'swing');
			})
		}
	};

	function PlatformPage() {
		this.$el = $('.platform-wrap');

		this.$category_list = this.$el.find('.js-w-platform_category_list');
		this.$category_indicator_list = this.$el.find('.js-w-platform_category_indicator_list');
		this.$company_indicator_list = this.$el.find('.js-w-platform_company_indicator_list');
		this.$industry_charts = this.$el.find('.js-w-platform_industry_charts');
		this.$platform_list = this.$el.find('.js-w-platform_company_list');
		this.$pie_charts = this.$el.find('.js-w-platform_pie_charts');
		this.$company_resultlist = this.$el.find('.js-w-platform_company_result_list');
		this.$category_resultlist = this.$el.find('.js-w-platform_category_result_list');
		this.$company_timelist = this.$el.find('.js-w-platform_company_time_list');
		this.$category_timelist = this.$el.find('.js-w-platform_category_time_list');
        this.$iconExhibition = this.$el.find('.w-iconExhibition-box');
		this.isFirstInitResult = false;
		this.init();
	}

	PlatformPage.prototype.init = function() {
		this.dataOption = {
			category: this.$category_list.find('[data-category]').eq(0).data('category'),
			platform: "",
			indicator: "barrage",
			timeType: "hour",
			timeValue: "1"
		};
		this.render();
		this.bindEvent();
	};
	PlatformPage.prototype.bindEvent = function() {
		var self = this;

		// 行业-频道类型
		$.sub('category/change', function(e, data) {
			self.dataOption.category = Number(data.category);
			self.industryCharts.getData(data);
			self.$industry_charts.html(self.industryCharts.$el);
			self.categoryResultList.getData(data);
		});

		// 行业-指标
		$.sub('indicator/change', function(e, data) {
			if (data.type == "category") {
				self.industryCharts.getData(data);
				self.$industry_charts.html(self.industryCharts.$el);
			} else {
				self.pieCharts.getData(data);
				self.$pie_charts.html(self.pieCharts.$el);
			}
		});

		//行业-平台类型
		$.sub('platform/change', function(e, data) {
			self.pieCharts.getData(data);
			self.$pie_charts.html(self.pieCharts.$el);
			self.companyResultList.getData(data);
		});

		// 时间选择
		$.sub('timeType/change', function(e, data) {
			if (data.type == "category") {
				self.industryCharts.getData(data);
				self.$industry_charts.html(self.industryCharts.$el);
			} else {
				self.pieCharts.getData(data);
				self.$pie_charts.html(self.pieCharts.$el);
			}
		});
	};
	PlatformPage.prototype.render = function() {
		// 上半部
		this.categoryList = new CategoryList({
			'$dom': this.$category_list
		});
		this.categoryTimeList = new TimeList({
			'$dom': this.$category_timelist,
			'type': 'category'
		});
		this.category_indicator_list = new IndicatorList({
			'$dom': this.$category_indicator_list,
			'type': 'category'
		});
		this.categoryResultList = new ResultList({
			'category': this.dataOption.category
		});
		this.$category_resultlist.html(this.categoryResultList.$el);
		this.renderIndustryCharts();

		// 下半部
		this.platformList = new PlatformList({
			'$dom': this.$platform_list
		});
        this.iconExhibitionUrl = new iconExhibition({
            '$dom': this.$iconExhibition
        });
		this.companyTimeList = new TimeList({
			'$dom': this.$company_timelist,
			'type': 'company'
		});
		this.company_indicator_list = new IndicatorList({
			'$dom': this.$company_indicator_list,
			'type': 'company'
		});
		this.companyResultList = new ResultList({
			'platform': ''
		});
		this.$company_resultlist.html(this.companyResultList.$el);
		this.renderPieCharts();

		return this;
	};

	PlatformPage.prototype.renderIndustryCharts = function() {
		var $domCategory = this.$category_list.find('[data-category]').eq(0);
		$domCategory.addClass('active');

		this.industryCharts = new IndustryCharts({
			category: this.dataOption.category,
			indicator: this.dataOption.indicator,
			timeType: this.dataOption.timeType,
			timeValue: this.dataOption.timeValue
		});
		this.$industry_charts.html(this.industryCharts.$el);
	};
	PlatformPage.prototype.renderPieCharts = function() {
		this.pieCharts = new PieCharts({
			platform: this.dataOption.platform,
			indicator: this.dataOption.indicator,
			timeType: this.dataOption.timeType,
			timeValue: this.dataOption.timeValue
		});
		this.$pie_charts.html(this.pieCharts.$el);
	};

	oPage.init();
	var oPlatformPage = new PlatformPage();

});