define(function(require) {
    var API = require('common/api');
    var Header = require('widget/header');
    var Footer = require('widget/footer');

    var oPage = {
        data: {
            maxLoopCount: 30,
            loopCount: 0
        },
        init: function() {
            var urlParams = ZBB.urlRequestParams();

            this.template = _.template(__inline('./liveReportContent.html'));

            this.render();
            this.bindEvent();

            if (urlParams['roomId'] && urlParams['platform']) {
                // this.getAnchorInfo(urlParams);
                if (urlParams['start'] && urlParams['stop']) {
                    this.getData(urlParams);
                }
            } else {
                console.log('参数不正确');
            }
        },
        render: function() {
            this.header = new Header();
        },
        renderPeopleReportChart: function(data) {
            var xAxisData = [],
                seriesData = [];
            $.each(data, function(i, obj) {
                xAxisData.push(new Date(obj.timestamp).Format('hh:mm'));
                seriesData.push(Number(obj.value));
            });
            this.initLiechart({
                xAxisData: xAxisData,
                seriesData: seriesData,
                peopleMarkPoint: true,
                el: $(".main-body").find(".peopleReport-chart")
            });
        },
        renderRewardReportChart: function(data) {
            var nameData = ["土豪", "打赏观众"];
            var seriesData = [{
                value: data.richTotal.toFixed(1),
                name: "土豪"
            }, {
                value: data.viewerTotal.toFixed(1),
                name: "打赏观众"
            }];
            var legendObj = {
                "土豪": "土豪：" + data.richTotal.toFixed(1) + "元\r\n\n占比：" + (data.richTotal / (data.richTotal + data.viewerTotal) * 100).toFixed() + "%",
                "打赏观众": "打赏观众：" + data.viewerTotal.toFixed(1) + "元\r\n\n占比：" + (data.viewerTotal / (data.richTotal + data.viewerTotal) * 100).toFixed() + "%"
            }
            this.initPieChart({
                nameData: nameData,
                seriesData: seriesData,
                legendObj: legendObj,
                el: $(".main-body").find(".rewardReport-chart")
            });
        },
        renderGiftReportChart: function(data) {
            var nameData = [],
                seriesData = [],
                count = [],
                legendObj = {};
            $.each(data.list, function(i, obj) {
                nameData.push(obj.giftName);
                seriesData.push({
                    value: Number(obj.value),
                    name: obj.giftName,
                    count: Number(obj.count),
                    total: data.total
                });
                legendObj[obj.giftName] = obj.count;
                count.push(Number(obj.count));
            });
            this.initGiftPieChart({
                nameData: nameData,
                seriesData: seriesData,
                legendObj: legendObj,
                el: $(".main-body").find(".giftReport")
            });
        },
        renderBarrageReportChart: function(data, arrBarragePeak) {
            var xAxisData = [],
                seriesData = [];
            $.each(data, function(i, obj) {
                xAxisData.push(new Date(obj.timestamp).Format('hh:mm'));
                seriesData.push(Number(obj.value));
            });
            this.initLiechart({
                xAxisData: xAxisData,
                seriesData: seriesData,
                arrBarragePeak: arrBarragePeak,
                el: $(".main-body").find(".barrageReport-chart")
            });
        },
        initLiechart: function(data) {
            var arrMarkPoint = [];
            // 弹幕标注点
            if (data.arrBarragePeak) {
                for (var i = 0, len = data.arrBarragePeak.length; i < len; i++) {
                    arrMarkPoint.push({
                        'coord': [data.arrBarragePeak[i].index, data.arrBarragePeak[i].value]
                    });
                }
            }
            // 人气标注点
            if (data.peopleMarkPoint) {
                arrMarkPoint.push({
                    type: 'max',
                    label: {
                        normal: {
                            formatter: function(param) {
                                return 'max';
                            }
                        }
                    }
                });
            }

            this.$el = $('<div class="w-lie-charts"></div>');
            data.el.html(this.$el);
            echarts.init(this.$el[0]).clear();
            var myChart = echarts.init(this.$el[0]);
            var myChartOption = {
                backgroundColor: {
                    type: 'pattern',
                    image: ZBB.canvasWaterMark(),
                    repeat: 'repeat'
                },
                title: {
                    show: false
                },
                tooltip: {
                    trigger: 'axis',
                    axisPointer: { // 坐标轴指示器，坐标轴触发有效
                        type: 'shadow', // 默认为直线，可选为：'line' | 'shadow'
                        shadowStyle: {
                            color: {
                                type: 'linear',
                                x: 0,
                                y: 0,
                                x2: 0,
                                y2: 1,
                                colorStops: [{
                                    offset: 0,
                                    color: 'rgba(48, 131, 255, 0)' // 0% 处的颜色
                                }, {
                                    offset: 1,
                                    color: 'rgba(48, 131, 255, 0.1)' // 100% 处的颜色
                                }],
                                globalCoord: false // 缺省为 false
                            }
                        }
                    }
                },
                legend: {},
                toolbox: {
                    show: false
                },
                xAxis: [{
                    type: 'category',
                    axisLabel: {
                        textStyle: {
                            color: '#8492af'
                        },
                    },
                    axisLine: {
                        lineStyle: {
                            type: 'dotted',
                            color: '#8492af'
                        }
                    },
                    boundaryGap: false,
                    data: data.xAxisData
                }],
                yAxis: [{
                    type: 'value',
                    axisLabel: {
                        textStyle: {
                            color: '#8492af'
                        },
                        formatter: '{value}'
                    },
                    axisLine: {
                        lineStyle: {
                            type: 'dotted',
                            color: '#8492af'
                        }
                    },
                    axisTick: {
                        show: false
                    },
                    splitLine: {
                        lineStyle: {
                            type: 'dotted',
                            color: '#8492af',
                            opacity: 0.55
                        }
                    }
                }],
                animation: false,
                // animationDuration:500,
                series: [{
                    name: '',
                    type: 'line',
                    data: data.seriesData,
                    showSymbol: false,
                    itemStyle: {
                        normal: {
                            color: "#6796ff",
                            areaStyle: {
                                type: 'default',
                                color: {
                                    type: 'linear',
                                    x: 0,
                                    y: 0,
                                    x2: 0,
                                    y2: 1,
                                    colorStops: [{
                                        offset: 0,
                                        color: 'rgba(48, 131, 255, 1)' // 0% 处的颜色
                                    }, {
                                        offset: 1,
                                        color: 'rgba(48, 131, 255, 0.2)' // 100% 处的颜色
                                    }],
                                    globalCoord: false // 缺省为 false
                                }

                            },
                            lineStyle: {
                                color: "#6796ff"
                            }
                        }
                    },
                    markPoint: {
                        data: arrMarkPoint
                    }
                }]
            };
            myChart.setOption(myChartOption);
            return this;
        },
        initGiftPieChart: function(chartParams) {
            this.$el = $('<div class="w-pie-charts"></div>');
            chartParams.el.html(this.$el);
            echarts.init(this.$el[0]).clear();
            var myChart = echarts.init(this.$el[0]);
            var chartColors = [{
                type: 'linear',
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [{
                    offset: 0,
                    color: '#5549f4' // 0% 处的颜色
                }, {
                    offset: 1,
                    color: '#4788ff' // 100% 处的颜色
                }],
                globalCoord: false // 缺省为 false
            }, {
                type: 'linear',
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [{
                    offset: 0,
                    color: '#3477ff' // 0% 处的颜色
                }, {
                    offset: 1,
                    color: '#43bfff' // 100% 处的颜色
                }],
                globalCoord: false // 缺省为 false
            }, {
                type: 'linear',
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [{
                    offset: 0,
                    color: '#3aaeff' // 0% 处的颜色
                }, {
                    offset: 1,
                    color: '#56edff' // 100% 处的颜色
                }],
                globalCoord: false // 缺省为 false
            }, {
                type: 'linear',
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [{
                    offset: 0,
                    color: '#fe9131' // 0% 处的颜色
                }, {
                    offset: 1,
                    color: '#ffd541' // 100% 处的颜色
                }],
                globalCoord: false // 缺省为 false
            }, {
                type: 'linear',
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [{
                    offset: 0,
                    color: '#ff4f4f' // 0% 处的颜色
                }, {
                    offset: 1,
                    color: '#ff8c3f' // 100% 处的颜色
                }],
                globalCoord: false // 缺省为 false
            }, {
                type: 'linear',
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [{
                    offset: 0,
                    color: '#ff5172' // 0% 处的颜色
                }, {
                    offset: 1,
                    color: '#fe927a' // 100% 处的颜色
                }],
                globalCoord: false // 缺省为 false
            }, {
                type: 'linear',
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [{
                    offset: 0,
                    color: '#0ec7f5' // 0% 处的颜色
                }, {
                    offset: 1,
                    color: '#26f0c3' // 100% 处的颜色
                }],
                globalCoord: false // 缺省为 false
            }, {
                type: 'linear',
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [{
                    offset: 0,
                    color: '#16cf69' // 0% 处的颜色
                }, {
                    offset: 1,
                    color: '#6ef3bc' // 100% 处的颜色
                }],
                globalCoord: false // 缺省为 false
            }];
            var chartColorsLength = chartColors.length;
            // 指定图表的配置项和数据
            var myChartOption = {
                backgroundColor: {
                    type: 'pattern',
                    image: ZBB.canvasWaterMark(),
                    repeat: 'repeat'
                },
                tooltip: {
                    trigger: 'item'
                },
                legend: {
                    orient: 'vertical',
                    left: '10%',
                    top: 'center',
                    itemGap: 15,
                    itemWidth: 15,
                    itemHeight: 15,
                    textStyle: {
                        color: '#8492af'
                    },
                    icon: 'circle',
                    data: chartParams.nameData,
                    formatter: function(name) {
                        if (!chartParams.legendObj) return name;
                        return chartParams.legendObj[name] + "个" + name;

                    }
                },
                toolbox: {
                    show: false
                },
                series: {
                    center: ['60%', '52%'],
                    color: chartColors,
                    type: 'pie',
                    selectedMode: 'single',
                    radius: [0, 130],
                    legendHoverLink: true,
                    label: {
                        normal: {
                            position: 'outside',
                            textStyle: {
                                color: '#8492af'
                            },
                            fontSize: 16,
                            formatter: function(params) {
                                return params.name + "：" + params.data.value + "元    " + params.percent + "%"
                            }
                        }
                    },
                    labelLine: {
                        normal: {
                            lineStyle: {
                                color: '#8492af'
                            },
                            length: 60,
                            length2: 30
                        }
                    },
                    itemStyle: {
                        normal: {
                            color: function(params) {
                                return chartColors[params.dataIndex % chartColorsLength];
                            }
                        },
                        emphasis: {
                            shadowBlur: 20,
                            shadowColor: 'rgba(0, 0, 0, 0.5)'
                        }
                    },
                    data: chartParams.seriesData
                }
            };

            // 使用刚指定的配置项和数据显示图表。
            myChart.setOption(myChartOption);

            return this;
        },
        initPieChart: function(chartParams) {
            this.$el = $('<div class="w-pie-charts"></div>');
            chartParams.el.html(this.$el);
            echarts.init(this.$el[0]).clear();
            var myChart = echarts.init(this.$el[0]);

            var chartColors = [
                "#5258f7", "#1ee8d3"
            ];
            // 指定图表的配置项和数据
            var myChartOption = {
                backgroundColor: {
                    type: 'pattern',
                    image: ZBB.canvasWaterMark(),
                    repeat: 'repeat'
                },
                tooltip: {
                    trigger: 'item'
                },
                legend: {
                    orient: 'horizontal',
                    left: 'center',
                    bottom: '10%',
                    itemGap: 25,
                    itemWidth: 15,
                    itemHeight: 15,
                    textStyle: {
                        color: '#8492af',
                        height: 50,
                        lineHeight: 50
                    },
                    icon: 'circle',
                    data: chartParams.nameData,
                    formatter: function(name) {
                        return chartParams.legendObj[name];
                    }
                },
                toolbox: {
                    show: false
                },
                series: {
                    center: ['50%', '40%'],
                    color: chartColors,
                    type: 'pie',
                    selectedMode: 'single',
                    radius: [0, 100],
                    legendHoverLink: true,
                    label: {
                        normal: {
                            position: 'outside',
                            textStyle: {
                                color: '#8492af'
                            },
                            fontSize: 16,
                            formatter: function(params) {
                                return params.name + "：共 " + params.data.value + "元\r\n占比：" + params.percent + "%";
                            }
                        }
                    },
                    labelLine: {
                        normal: {
                            lineStyle: {
                                color: '#8492af'
                            },
                            length: 20,
                            length2: 10
                        }
                    },
                    itemStyle: {
                        normal: {
                            color: function(params) {
                                return chartColors[params.dataIndex % chartColors.length];
                            }
                        },
                        emphasis: {
                            shadowBlur: 20,
                            shadowColor: 'rgba(0, 0, 0, 0.5)'
                        }
                    },
                    data: chartParams.seriesData
                }
            };

            // 使用刚指定的配置项和数据显示图表。
            myChart.setOption(myChartOption);

            return this;
        },
        getData: function(opts) {
            var self = this;
            var path = 'anchor/live/report';
            var options = {
                roomId: opts['roomId'],
                platform: opts['platform'],
                start: opts['start'],
                stop: opts['stop']
            };
            this.data.loopCount++;

            API.get(path, options, function(data) {
                if (data.code == 0) {
                    API.get(data.data.url, {}, function(response) {
                        var afterTime = response.online.peakTime - parseInt(options.start) * 1000;
                        afterTime = parseInt(afterTime / 60000);

                        var arrBarragePeak = self.barragePeakTimes(response.barrage);
                        response.barrage.peakTimes = arrBarragePeak.length;

                        $(".report-block-two").html(self.template({
                            'data': response,
                            'afterTime': afterTime
                        }));
                        $("#gift_num").text(response.gift.total);
                        $("#reward_num").text(response.rich.total);
                        $("#barrage_num").text(response.barrage.total);
                        $("#online_num").text(response.online.peak);
                        if (response.roomInfo.follow.value >= 0) {
                            $(".follow").html("关注：" + response.roomInfo.follow.value);
                            if (response.roomInfo.follow.up < 0) {
                                $("#follow_change").addClass("down");
                            }
                            $("#follow_change").html(response.roomInfo.follow.up);
                            $('.anchor-info_follow').show();
                        }

                        self.renderGiftReportChart(response.gift);
                        self.renderRewardReportChart({
                            richTotal: response.rich.richTotal,
                            viewerTotal: response.rich.viewerTotal
                        });
                        self.renderBarrageReportChart(response.barrage.list, arrBarragePeak);
                        self.renderPeopleReportChart(response.online.list);
                    });
                } else if (data.code == 1234) {
                    if (self.data.loopCount < self.data.maxLoopCount) {
                        setTimeout(function() {
                            self.getData(opts);
                        }, 2000);
                    }
                }
            });
        },
        barragePeakTimes: function(barrageSource) {
            var arrList = [];
            var minPearVal = Math.max(barrageSource.avgBar * 2, 10);

            for (var i = 0, len = barrageSource.list.length; i < len; i++) {
                if (barrageSource.list[i].value > minPearVal) {
                    barrageSource.list[i].index = i;
                    arrList.push(barrageSource.list[i]);
                }
            }
            var timeStep = 1000 * 60 * 5; // 时间间隔内部重复计算峰值点
            for (var i = 0, len = arrList.length; i < len; i++) {
                for (var j = i + 1; j < len; j++) {
                    if (arrList[j].timestamp - arrList[i].timestamp < timeStep) {
                        if (arrList[j].value > arrList[i].value) {
                            arrList.splice(i, 1);
                            i--;
                            len--;
                            break;
                        } else {
                            arrList.splice(j, 1);
                            j--;
                            len--;
                        }
                    }
                }
            }
            return arrList;
        },
        getAnchorInfo: function(opts) {
            var self = this;
            var path = 'anchor/info';
            API.get(path, {
                'platform': opts.platform,
                'roomId': opts.roomId
            }).then(function(data) {
                if (data.code == 0) {
                    // self.renderAnchorInfo(data.data.info, opts);
                }
            });
        },
        renderAnchorInfo: function(data, options) {
            if (data) {
                $('#avatar').attr('src', ZBB.parseAvatar(data.avatar));
                $('#nickname').text(data.nickname);
                $('#roomid').text(data.roomId);
                $('#platform').text(ZBB.platformName[data.platform]).show();
                $('#category').text(data.cateName).show();
                // 开播时间，持续时间
                var startTime = new Date(parseInt(options.start) * 1000).Format('yyyy/MM/dd hh:mm');
                var duration = parseInt(options.stop) - parseInt(options.start);
                var strHtml = startTime + ' 开播，共播了<span class="special-text">' + this.durationString(duration) + '</span>';
                $('#start_time').html(strHtml);
            }
        },
        durationString: function(duration) {
            var str = '';
            if (duration >= 3600) {
                var hour = parseInt(duration / 3600);
                var min = parseInt((duration - hour * 3600) / 60);
                str = hour + '小时' + min + '分钟';
            } else {
                var min = parseInt(duration / 60);
                str = min + '分钟';
            }
            return str;
        },
        bindEvent: function() {
            $(".report-tab_tab").on("click", function() {
                var $this = $(this);
                if ($this.hasClass("report-tab_tab_active")) return;
                $this.addClass("report-tab_tab_active").siblings().removeClass("report-tab_tab_active");
                $(".report-block-two").find(".report_wrap_content").hide();
                $("." + $this.data("type")).show();
            });
        }
    };



    oPage.init();


});