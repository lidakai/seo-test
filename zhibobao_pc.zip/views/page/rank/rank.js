define(function(require) {
    // 302
    var MOBILE_UA_REGEXP = /(iPhone|iPod|Android|ios|iOS|iPad|Backerry|WebOS|Symbian|Windows Phone|Phone|Prerender|MicroMessenger)/i;
    if (MOBILE_UA_REGEXP.test(navigator.userAgent)) {
        var urlParams = ZBB.urlRequestParams();
        if (urlParams['isPc']) {

        } else {
            var pathname = location.pathname;
            var search = location.search;
            window.location.replace(ZBB.mDomain + pathname + search);
            return;
        }
    }
    
    var Header = require('widget/header');
    var Footer = require('widget/footer');

    var RankTab = require('widget/rankTab');
    var PlatformList = require('widget/platformList');
    var Rank = require('widget/rank');
    var CategoryList = require('widget/categoryList');
    var TimeList = require('widget/timeList');
    var RankUpdateTime = require('widget/rank/rankUpdateTime.js');

    var oPage = {
        init: function() {
            this.render();
            this.bindEvent();
        },
        render: function() {
            this.header = new Header('index');
        },
        bindEvent: function() {
            var self = this;
            var height = window.innerHeight;
            $(document).scroll(
                _.debounce(function() {
                    var h = $(this).scrollTop();
                    if (h > height) {
                        $(".back_top").show();
                    } else {
                        $(".back_top").hide();
                    }

                }, 100)
            );

            $(".back_top").on('click', function() {
                $('html,body').animate({
                    scrollTop: 0
                }, 500, 'swing');
            })
        }
    };

    function RankPage(opts) {
        this.opts = opts || {};
        this.opts = {
            userType: this.opts.userType,
            platform: this.opts.platform,
            category: this.opts.category,
            limit: 100,
            timeType: this.opts.timeType,
            timeValue: this.opts.timeValue
        };

        this.$el = $('.rank-wrap');

        this.$gift_rank = this.$el.find('.js-w-rank_gift');
        this.$barrage_rank = this.$el.find('.js-w-rank_barrage');
        this.$money_rank = this.$el.find('.js-w-rank_money');
        this.$rank_update_time = this.$el.find('.js-w-rank_rankUpdateTime');
        this.init();
    }

    RankPage.prototype.init = function() {
        this.bindEvent();
        this.render();
    };

    RankPage.prototype.render = function() {
        this.rankTab = new RankTab({
            '$dom': $('.js-w-rank_tab')
        });

        this.platformList = new PlatformList({
            '$dom': $('.js-w-rank_platform_list')
        });

        this.categoryList = new CategoryList({
            '$dom': $('.js-w-rank_category_list')
        });

        this.companyTimeList = new TimeList({
            '$dom': $('.js-w-rank_timeList'),
            'userType': this.opts.userType
        });

        this.rankUpdateTime = new RankUpdateTime({
            '$dom': $('.js-w-rank_rankUpdateTime')
        });

        return this;
    };

    RankPage.prototype.bindEvent = function() {
        var self = this;

        //tab切换监听
        $.sub('rankTab/change', function(e, data) {
            self.opts.userType = data.userType;
            // if (data.userType == "new_anchor" && self.opts.timeType == 'dayRange') {
            //     self.opts.timeType = 'hour';
            //     self.opts.timeValue = 1;
            // }
            self.companyTimeList.updateUserType(data.userType);
            self.location();
        });

        //平台切换监听
        $.sub('platform/change', function(e, data) {
            self.opts.platform = data.platform;
            self.location();
        });

        //直播频道监听
        $.sub('category/change', function(e, data) {
            self.opts.category = data.category;
            self.location();
        });

        //  时间监听
        $.sub('timeType/change', function(e, data) {
            self.opts.timeType = data.timeType;
            self.opts.timeValue = data.timeValue;
            self.location();
        });

        //更新時間監聽
        $.sub('rank/updateEnd', function(e, data) {
            self.rankUpdateTime.update(data);
        });
    };


    RankPage.prototype.renderRank = function() {
        this.giftRank = new Rank({
            userType: this.opts.userType,
            rankType: 'gift',
            platform: this.opts.platform,
            category: this.opts.category,
            limit: this.opts.limit,
            timeType: this.opts.timeType,
            timeValue: this.opts.timeValue
        });
        this.giftRank.getData();
        this.$gift_rank.html(this.giftRank.$el);

        this.barrageRank = new Rank({
            userType: this.opts.userType,
            rankType: 'barrage',
            platform: this.opts.platform,
            category: this.opts.category,
            limit: this.opts.limit,
            timeType: this.opts.timeType,
            timeValue: this.opts.timeValue
        });
        this.barrageRank.getData();
        this.$barrage_rank.html(this.barrageRank.$el);

        $('.js-w-rank_money').hide();
        $('.js-w-rank_gift').show();
        $('.js-w-rank_barrage').show();
    };
    RankPage.prototype.renderMoneyRank = function() {
        this.moneyRank = new Rank({
            userType: 'user',
            rankType: 'gift',
            platform: this.opts.platform,
            category: this.opts.category,
            limit: this.opts.limit,
            timeType: this.opts.timeType,
            timeValue: this.opts.timeValue
        });
        this.moneyRank.getData();
        this.$money_rank.html(this.moneyRank.$el);

        $('.js-w-rank_gift').hide();
        $('.js-w-rank_barrage').hide();
        $('.js-w-rank_money').show();
    };
    //页面无刷新修改url
    RankPage.prototype.location = function() {
        page('/rank?' + $.param(this.opts));
        // page('/rank?platform=' + this.opts.platform +
        //     '&category=' + this.opts.category +
        //     '&userType=' + this.opts.userType +
        //     '&limit=' + this.opts.limit +
        //     '&timeType=' + this.opts.timeType +
        //     '&timeValue=' + this.opts.timeValue);
    };

    page('/rank', function() {
        if (oRankPage.opts.userType == 'user') {
            oRankPage.renderMoneyRank();
        } else {
            oRankPage.renderRank();
        }
    });

    oPage.init();
    var oRankPage = new RankPage(g_curState);

});