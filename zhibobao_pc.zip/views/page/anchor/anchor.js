define(function(require) {
    // 302
    var MOBILE_UA_REGEXP = /(iPhone|iPod|Android|ios|iOS|iPad|Backerry|WebOS|Symbian|Windows Phone|Phone|Prerender|MicroMessenger)/i;
    if (MOBILE_UA_REGEXP.test(navigator.userAgent)) {
        var urlParams = ZBB.urlRequestParams();
        if (urlParams['isPc']) {

        } else {
            var pathname = location.pathname;
            var search = location.search;
            window.location.replace(ZBB.mDomain + pathname + search);
            return;
        }
    }

    var api = require('common/api');
    var Header = require('widget/header');
    var Footer = require('widget/footer');
    var LieCharts = require('widget/lieCharts');
    var LiveDensity = require('widget/liveDensity');
    var AnchorRank = require('widget/anchorRank');
    var AnchorInfo = require('widget/anchorInfo');

    var $body = $('body');
    var $action_line_charts = $body.find('.js_w_action_line_charts');
    var $gift_line_charts = $body.find('.js_w_gift_line_charts');
    var $time_line_charts = $body.find('.js_w_time_line_charts');
    var $people_line_charts = $body.find('.js_w_people_line_charts');
    var $action_list = $body.find('.js_action_list');
    var $gift_list = $body.find('.js_gift_list');
    var $liveDensity = $body.find('.js_w_liveDensity');
    var $anchorRank = $body.find('.js_w_anchorRank');

    var oPage = {
        init: function() {
            var self = this;
            var urlRequestParams = ZBB.urlRequestParams();
            if (urlRequestParams['roomId']) {
                self.roomId = urlRequestParams['roomId'];
            }
            if (urlRequestParams['platform']) {
                self.platform = urlRequestParams['platform'];
            }
            this.params = {
                offset: 7,
                platform: self.platform,
                roomId: self.roomId
            };
            this.option = {
                type: "",
                key: ""
            }
            this.dataObject = {}
            this.getData(this.option);
            this.render();
            this.bindEvent();
        },
        render: function(data) {
            var header = new Header();

            var liveDensity = new LiveDensity(this.params);
            $liveDensity.append(liveDensity.$el);

        },
        renderLieCharts: function(obj) {
            var self = this;
            $.each(obj.data, function(key, val) {
                switch (key) {
                    case 'barrage':
                        self.action_line_charts = new LieCharts({
                            value: val,
                            type: self.option.key || "barrage"

                        });
                        $action_line_charts.html(self.action_line_charts.$el);
                        self.action_line_charts.init();
                        break;
                    case 'gift':
                        self.gift_line_charts = new LieCharts({
                            value: val,
                            type: self.option.key || "gift"

                        });
                        $gift_line_charts.html(self.gift_line_charts.$el);
                        self.gift_line_charts.init();
                        break;
                    case 'liveTime':
                        $.each(val, function(index, item) {
                            val[index] = Number(item).toFixed(1)
                        });
                        self.time_line_charts = new LieCharts({
                            value: val,
                            type: "liveTime"

                        });
                        $time_line_charts.html(self.time_line_charts.$el);
                        self.time_line_charts.init();
                        break;
                    case 'online':
                        self.people_line_charts = new LieCharts({
                            value: val,
                            type: "online"

                        });
                        $people_line_charts.html(self.people_line_charts.$el);
                        self.people_line_charts.init();
                        break;
                    default:
                        break
                }
            });
        },
        bindEvent: function() {
            var self = this;
            //用户弹幕相关
            $action_list.on('click', 'li', function() {
                var $this = $(this);
                var action = $this.data('action');
                if (!$this.hasClass('active')) {
                    $this.addClass('active').siblings().removeClass('active');
                    self.option = {
                        type: "barrage",
                        key: $this.data('action')
                    };
                    self.getData(self.option);

                    if( action != 'barrage' ){
                        $(".all_barrage_week,.all_barrage_month").css('display','none');
                    }else{
                        if( self.params.offset==7 ){
                            $(".all_barrage_week").css('display','block');
                        }else{
                            $(".all_barrage_month").css('display','block');
                        }
                    }

                }
            });

            //用户礼物相关
            $gift_list.on('click', 'li', function() {
                var $this = $(this);
                var gift = $this.data('gift');
                if (!$this.hasClass('active')) {
                    $this.addClass('active').siblings().removeClass('active');
                    self.option = {
                        type: "gift",
                        key: $this.data('gift')
                    };
                    self.getData(self.option);

                    if( gift != 'gift' ){
                        $(".all_gift_week,.all_gift_month").css('display','none');
                    }else{
                        if( self.params.offset==7 ){
                            $(".all_gift_week").css('display','block');
                        }else{
                            $(".all_gift_month").css('display','block');
                        }
                    }
                }
            });

            //时间段选择
            $(".anchor-title-time").on('click', 'span', function() {
                var $this = $(this);
                if (!$this.hasClass('active')) {
                    $this.addClass('active').siblings().removeClass('active');
                    self.params.offset = $this.data('time');
                    self.getData({});
                    if (!self.dataObject[self.params.offset]) {
                        return;
                    }
                    if( $this.data('type') == 'week' ){
                        $(".all_live_time_week").css('display','block');
                        $(".all_live_time_month").css('display','none');
                        if( $(".js_action_list").find('.active').data('action')=='barrage' ){
                            $(".all_barrage_week").css('display','block');
                            $(".all_barrage_month").css('display','none');
                        }
                        if( $(".js_gift_list").find('.active').data('gift')=='gift' ){
                            $(".all_gift_week").css('display','block');
                            $(".all_gift_month").css('display','none');
                        }
                    }else{
                        $(".all_live_time_week").css('display','none');
                        $(".all_live_time_month").css('display','block');
                        if( $(".js_action_list").find('.active').data('action')=='barrage' ){
                            $(".all_barrage_week").css('display','none');
                            $(".all_barrage_month").css('display','block');
                        }
                        if( $(".js_gift_list").find('.active').data('gift')=='gift' ){
                            $(".all_gift_week").css('display','none');
                            $(".all_gift_month").css('display','block');
                        }
                    }
                }
            })
        },
        getData: function(option) {
            var self = this;
            var path = 'anchor/trends';

            if (this.dataObject[self.params.offset]) {

                if (option.type == 'gift') {
                    self.gift_line_charts = new LieCharts({
                        value: this.dataObject[self.params.offset][option.key],
                        type: option.key
                    });
                    $gift_line_charts.html(self.gift_line_charts.$el);
                    self.gift_line_charts.init();
                } else if (option.type == 'barrage') {
                    self.action_line_charts = new LieCharts({
                        value: this.dataObject[self.params.offset][option.key],
                        type: option.key
                    });
                    $action_line_charts.html(self.action_line_charts.$el);
                    self.action_line_charts.init();
                } else {
                    self.renderLieCharts({
                        data: this.dataObject[self.params.offset]
                    });
                }
                return;
            }

            api.get(path, this.params).done(function(data) {
                if (data.code == 0) {
                    if (option.type == 'gift') {
                        self.gift_line_charts = new LieCharts({
                            value: data.data.info[option.key],
                            type: option.key
                        });
                        $gift_line_charts.html(self.gift_line_charts.$el);
                        self.gift_line_charts.init();
                    } else if (option.type == 'barrage') {
                        self.action_line_charts = new LieCharts({
                            value: data.data.info[option.key],
                            type: option.key
                        });
                        $action_line_charts.html(self.action_line_charts.$el);
                        self.action_line_charts.init();
                    } else {
                        var barrage_all = 0,gift_all = 0,liveTime_all=0;
                        $.each(data.data.info,function (item,obj) {

                            if( item == 'barrage' ){
                                $.each(obj,function (index,num) {
                                    barrage_all += Number( num );
                                })
                            }

                            if( item == 'gift' ){
                                $.each(obj,function (index,num) {
                                    gift_all += Number( num );
                                })
                            }

                            if( item == 'liveTime' ){
                                $.each(obj,function (index,num) {
                                    data.data.info[item][index] = Number( num / 3600 );
                                    liveTime_all += Number( num / 3600 );
                                })
                            }

                        });
                        if( self.params.offset == 7 ){
                            $(".all_barrage_week").css('display','block').find('i').html( barrage_all.toLocaleString() );
                            $(".all_gift_week").css('display','block').find('i').html( gift_all.toLocaleString() );
                            $(".all_live_time_week").css('display','block').find('i').html( (liveTime_all).toFixed(1) );
                        }else{
                            $(".all_barrage_week").css('display','none');
                            $(".all_gift_week").css('display','none');
                            $(".all_live_time_week").css('display','none');
                            $(".all_barrage_month").css('display','block').find('i').html( barrage_all.toLocaleString() );
                            $(".all_gift_month").css('display','block').find('i').html( gift_all.toLocaleString() );
                            $(".all_live_time_month").css('display','block').find('i').html( (liveTime_all).toFixed(1) );
                        }
                        self.renderLieCharts({
                            data: data.data.info
                        });
                    }
                    self.dataObject[self.params.offset] = data.data.info;
                }
            });
        }
    };

    oPage.init();
});