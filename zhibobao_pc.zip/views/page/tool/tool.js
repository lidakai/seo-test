define(function(require) {
    var api = require('common/api');
    var Header = require('widget/header');
    var Footer = require('widget/footer');


    var update_content = [
        {
            version:"V1.24.6",
            update_item:[
                {
                    title:"修复：Win7 安装兼容问题",
                },
                {
                    title:"修复：麦克风声音太小",
                },
                {
                    title:"修复：设置-设备 展示错误",
                },
                {
                    title:"修复：添加采集源时点取消后采集源仍然被保存",
                },
                {
                    title:"修复：防窥屏延迟设置不生效",
                },
                {
                    title:"新增：默认关闭 Win7 Aero 效果",
                },
                {
                    title:"优化：优化弹幕显示",
                },
            ]
        },
        {
            version:"V1.25.1",
            update_item:[
                {
                    title:"修复：添加多个游戏源直播宝无响应卡死",
                },
                {
                    title:"修复：同步录制视频有些情况下无法保存",
                },
                {
                    title:"修复：重置推流秘钥后可能导致推流失败",
                },
                {
                    title:"修复：开始直播按钮状态和文件显示错乱",
                },
                {
                    title:"新增：手机验证码登录功能（第三方登录）",
                },
                {
                    title:"优化：开始直播按钮 UI 交互",
                },
                {
                    title:"优化：同步录播开关 UI 交互",
                },
                {
                    title:"优化：设计界面 UI 交互",
                },
                {
                    title:"优化：非 Win7 系统隐藏 Aero 设置项",
                },
            ]
        },
        {
            version:"V1.26.0",
            update_item:[
                {
                    title:"新增：弹幕礼物面板",
                    des:[
                        "可以显示直播间弹幕和礼物信息","可以灵活移动弹幕面板位置和大小","可以灵活设置弹幕面板透明度","可以灵活设置贵宾弹幕等级"
                    ]
                },
                {
                    title:"新增：崩溃信息自动上报",
                },
                {
                    title:"修复：关闭赏金结算页面可能导致直播宝关闭",
                },
                {
                    title:"修复：弹幕插件热更新有几率不能下载成功",
                },
                {
                    title:"修复：一些其他异常和崩溃问题",
                },
                {
                    title:"优化：整体 UI 交互体验",
                }
            ]
        },
        {
            version:"V1.27.1",
            update_item:[
                {
                    title:"新增：直播宝模板，方便一键配置与直播",
                },
                {
                    title:"新增：新手开播引导",
                },
                {
                    title:"新增：直播环境检测与推流设置",
                },
                {
                    title:"新增：直播推流状态监控与一键优化",
                },
                {
                    title:"修复：若干异常和崩溃问题",
                },
                {
                    title:"优化：整体 UI 交互体验",
                }
            ]
        },
        {
            version:"V1.27.3",
            update_item:[
                {
                    title:"修复：少数用户模板选择界面画面为空",
                },
                {
                    title:"修复：开播环境检崩溃",
                },
                {
                    title:"修复：直播同步录制开关失效",
                },
                {
                    title:"修复：Win7 关闭 Aero（隐藏 QQ）功能失效",
                }
            ]
        },
        {
            version:"V1.28.0",
            update_item:[
                {
                    title:"直播宝终于支持万众期待的美颜功能了，效果拔群哦",
                },
                {
                    title:"麦克风最大支持增强到300%，音量小，听不到？不存在的",
                },
                {
                    title:"简化文字添加功能",
                },
                {
                    title:"优化托盘图标点击行为",
                },
                {
                    title:"删除元素新增快捷键-Delete",
                },
                {
                    title:"若干优化和问题修复",
                }
            ]
        },
        {
            version:"V1.28.3",
            update_item:[
                {
                    title:"修复崩溃问题",
                }
            ]
        },
        {
            version:"V1.29.1",
            update_item:[
                {
                    title:"更改了推流配置（兼容全民新的推流秘钥格式），旧版两周后不能直播，大家务必下载新版本更新",
                },
                {
                    title:"新增直播小结功能（直播超过半小时后，下播时自动弹出），这“播”亏不亏，一看就知道~",
                },
                {
                    title:"弹幕增加直播环境显示，实时监控直播效果",
                },
                {
                    title:"若干问题修复及细节优化",
                }
            ]
        },
        {
            version:"V1.29.1",
            update_item:[
                {
                    title:"更改了推流配置（兼容全民新的推流秘钥格式），旧版两周后不能直播，大家务必下载新版本更新",
                },
                {
                    title:"新增直播小结功能（直播超过半小时后，下播时自动弹出），这“播”亏不亏，一看就知道~",
                },
                {
                    title:"弹幕增加直播环境显示，实时监控直播效果",
                },
                {
                    title:"若干问题修复及细节优化",
                }
            ]
        },
        {
            version:"V1.29.3",
            update_item:[
                {
                    title:"修复崩溃问题。",
                }
            ]
        },
        {
            version:"V1.29.5",
            update_item:[
                {
                    title:"直播宝启动后系统音量降低的问题"
                },
                {
                    title:"添加不了摄像头设备和在摄像头高分辨率下无图像的问题"
                },
                {
                    title:"增加吃鸡配置画质推荐，增大码率上限"
                },
                {
                    title:"双显卡情况下桌面捕获和游戏捕获黑屏的问题"
                },
                {
                    title:'其它细节优化'
                }
            ]
        },
        {
            version:"V1.29.7",
            update_item:[
                {
                    title:"修复了若干情况下的崩溃"
                }
            ]
        },
        {
            version:"V2.0.1",
            update_item:[
                {
                    title:"新增直播宝独立帐号"
                },
                {
                    title:"支持斗鱼及自定义推流地址"
                },
                {
                    title:"弹幕标签样式更新"
                },
                {
                    title:"弹幕设置更加丰富（可自定义标签显示）"
                }
            ]
        }
    ];
    var oPage = {
        init: function() {
            var self = this;
            this.render();
            this.bindEvent();

            $(".tool_header_download").attr("href","http://zbb-dl.zhibobao.com/zhibobao_v2.0.2.exe?t="+new Date().getTime())
        },
        render: function(data) {
            var header = new Header();
            $('.main-header').append(header.$el);

            var footer = new Footer();
            $('.main-footer').append(footer.$el);

            var str = "";
            update_content = update_content.reverse();
            $.each(update_content,function (index,obj) {
                var item ="";
                var des="";
                $.each(obj.update_item,function (index,obj) {
                    if(obj.des){
                        $.each(obj.des,function (i,data) {
                            des+='<span class="history_update_item_content">'+data+'</span>'
                        })
                    }
                    item+= '<p class="history_update_title">'+obj.title+'</p>'+des;
                    des="";
                });
                str+='<li class="history_update_unit">\
                        <div class="history_update_des hide">'+obj.version+'</div>\
                        <div>'+item+'</div>\
                    </li>';
            });
            $(".history_update").html(str);
        },
        bindEvent: function() {
            var self = this;
            $(".history_update_des").on("click",function () {
                var $this = $(this);
                if($this.hasClass("hide")){
                    $this.addClass("show").removeClass("hide");
                    $this.siblings().find("p").show().animate({opacity:1},500);
                    $this.siblings().find("span").css("display","block").animate({opacity:1},500);
                }else{
                    $this.addClass("hide").removeClass("show");
                    $this.siblings().find("p").animate({opacity:0},500,function () {
                        $this.siblings().find("p").hide();
                    })
                    $this.siblings().find("span").animate({opacity:0},500,function () {
                        $this.siblings().find("span").hide();
                    })
                }
            });

            $(".tool_update_record").on("click",function () {
                // $("body").scrollTop($(".update_content").offset().top);
                $("html,body").animate({scrollTop:$(".update_content").offset().top - 120},500)
            });
        }
    };
    oPage.init();
});