define(function(require) {
    // 302
    var MOBILE_UA_REGEXP = /(iPhone|iPod|Android|ios|iOS|iPad|Backerry|WebOS|Symbian|Windows Phone|Phone|Prerender|MicroMessenger)/i;
    if (MOBILE_UA_REGEXP.test(navigator.userAgent)) {
        var urlParams = ZBB.urlRequestParams();
        if (urlParams['isPc']) {

        } else {
            var pathname = location.pathname;
            var search = location.search;
            window.location.replace(ZBB.mDomain + pathname + search);
            return;
        }
    }

    var Header = require('widget/header');
    var Footer = require('widget/footer');

    var ResultList = require('widget/resultList');
    var RankTab = require('widget/rankTab');
    var PlatformList = require('widget/platformList');
    var Rank = require('widget/rank');
    var RankUpdateTime = require('widget/rank/rankUpdateTime.js');
    var iconExhibition = require('widget/iconExhibition');
    var CategoryList = require('widget/categoryList_new');
    var IndustryCharts = require('widget/industryCharts');
    var IndicatorList = require('widget/indicatorList');

    var oPage = {
        init: function() {
            this.render();
            this.bindEvent();
        },
        render: function() {
            this.header = new Header('index');
        },
        bindEvent: function() {
            var self = this;
            var height = window.innerHeight;
            $(document).scroll(
                _.debounce(function() {
                    var h = $(this).scrollTop();
                    if (h > height) {
                        $(".back_top").show();
                    } else {
                        $(".back_top").hide();
                    }

                }, 100)
            );

            $(".back_top").on('click', function() {
                $('html,body').animate({
                    scrollTop: 0
                }, 500, 'swing');
            })
        }
    };


    function MainPage() {
        this.$el = $('.main-body');

        this.$rank_tab = this.$el.find('.js-w-index_rank_tab');
        this.$platform_list = this.$el.find('.js-w-index-platform_list');
        this.$gift_rank = this.$el.find('.js-w-index_rank_gift');
        this.$barrage_rank = this.$el.find('.js-w-index_rank_barrage');
        this.$rank_update_time = this.$el.find('.js-w-index_rank_update_time');
        this.$category_list = this.$el.find('.js-w-index_category_list');
        this.$indicator_list = this.$el.find('.js-w-index_indicator_list');
        this.$industry_charts = this.$el.find('.js-w-index_industry_charts');
        this.$iconExhibition = this.$el.find('.w-iconExhibition-box');
        this.init();
    }

    MainPage.prototype.init = function() {
        this.render();
        this.bindEvent();
    };

    MainPage.prototype.render = function() {
        this.rankTab = new RankTab({
            '$dom': this.$rank_tab
        });
        this.iconExhibitionUrl = new iconExhibition({
            '$dom': this.$iconExhibition
        });

        this.platformList = new PlatformList({
            '$dom': this.$platform_list
        });

        this.indicatorList = new IndicatorList({
            '$dom': this.$indicator_list
        });

        this.categoryList = new CategoryList({
            '$dom': this.$category_list
        });

        this.renderRank();

        this.renderIndustryCharts();

        return this;
    };

    MainPage.prototype.bindEvent = function() {
        var self = this;
        // 榜单
        $.sub('rankTab/change', function(e, data) {
            //修改下部按钮的href属性
            var url = $(".more-rank").attr("href");
            $(".more-rank").attr("href", self.replaceParams(url, "userType", data.userType));

            self.giftRank.getData({
                'userType': data.userType
            });

            if (data.userType == "user") {
                self.barrageRank.getData({
                    'userType': data.userType,
                    'rankType': 'gift',
                    'timeType': 'today',
                    'timeValue': (new Date()).Format('yyyy/MM/dd').replace(/\//g, "").replace(/\s/g, "")
                });
            } else {
                self.barrageRank.getData({
                    'userType': data.userType,
                    'rankType': 'barrage',
                    'timeType': 'hour',
                    'timeValue': 1
                });

            }
        });

        $.sub('platform/change', function(e, data) {
            //修改下部按钮的href属性
            var url = $(".more-rank").attr("href");
            $(".more-rank").attr("href", self.replaceParams(url, "platform", data.platform));

            self.giftRank.getData({
                'platform': data.platform
            });
            self.barrageRank.getData({
                'platform': data.platform
            });
        });

        $.sub('rank/updateEnd', function(e, data) {
            self.rankUpdateTime.update(data);
        });

        // 行业-频道类型
        $.sub('category/change', function(e, data) {
            self.industryCharts.getData(data);
        });

        // 行业-指标
        $.sub('indicator/change', function(e, data) {
            self.industryCharts.getData(data);
        });

        // 时间选择
        $.sub('timeType/change', function(e, data) {
            self.industryCharts.getData(data);
        });
    };


    MainPage.prototype.renderRank = function(data) {
        this.giftRank = new Rank({
            $dom: this.$gift_rank,
            rankType: 'gift',
            limit: 5,
            timeType: 'hour',
            timeValue: 1
        });

        this.barrageRank = new Rank({
            $dom: this.$barrage_rank,
            rankType: 'barrage',
            limit: 5,
            timeType: 'hour',
            timeValue: 1
        });

        this.rankUpdateTime = new RankUpdateTime({
            timeType: 'hour',
            timeValue: 1
        });
        this.$rank_update_time.html(this.rankUpdateTime.$el);
    };
    MainPage.prototype.renderIndustryCharts = function() {
        var $domCategory = this.$category_list.find('[data-category]').eq(0);
        var curCategory = $domCategory.data('data-category');
        var $dom = this.$indicator_list.find('li').eq(0);
        $domCategory.addClass('active');
        this.industryCharts = new IndustryCharts({
            indicator: $dom.data('indicator'),
            timeType: 'hour',
            timeValue: 1,
            category: curCategory
        });
        this.$industry_charts.html(this.industryCharts.$el);
    };

    MainPage.prototype.replaceParams = function(url, arg, arg_val) {
        var pattern = arg + '=([^&]*)';
        var replaceText = arg + '=' + arg_val;
        if (url.match(pattern)) {
            var tmp = '/(' + arg + '=)([^&]*)/gi';
            tmp = url.replace(eval(tmp), replaceText);
            return tmp;
        } else {
            if (url.match('[\?]')) {
                return url + '&' + replaceText;
            } else {
                return url + '?' + replaceText;
            }
        }
    };

    oPage.init();
    var oRankPage = new MainPage();

});