var LieCharts = require('widget/lieCharts');


var peopleReport = function (opts) {
    this.template = _.template(__inline('./peopleReport.html'));
    this.opts = opts || {};
    this.params = {

    };
    this.$el = $('<div class="w-peopleReport"></div>');
    this.$peopleReport_chart = this.$el.find(".w-peopleReport-chart");
    this.init();
};

peopleReport.prototype.init = function () {
    this.render();
    this.bindEvent();
};

peopleReport.prototype.bindEvent = function () {

};

peopleReport.prototype.render = function () {
    this.$el.html(this.template());


    this.LieCharts = new LieCharts();
    this.$peopleReport_chart.html( this.LieCharts.$el );
    this.LieCharts.init();
    return this;
};

peopleReport.prototype.getData = function (data) {
    $.extend(this.params, data);
    var self = this;
    api.get(path, this.params).done(function(data) {
        if (data.code == 0) {

        }
    }).fail(function () {

    });
};

module.exports = peopleReport;