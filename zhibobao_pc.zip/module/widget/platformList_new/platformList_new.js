var PLATFORM_LIST = [{
    'name': '全平台',
    'val': ''
}, {
    'name': '斗鱼',
    'val': 'douyu'
}, {
    'name': '虎牙',
    'val': 'huya'
}, {
    'name': '全民',
    'val': 'quanmin'
}, {
    'name': '熊猫',
    'val': 'panda'
}, {
    'name': '战旗',
    'val': 'zhanqi'
}, {
    'name': '龙珠',
    'val': 'longzhu'
}, {
    'name': '触手',
    'val': 'chushou'
}];

function PlatformList(opts) {
    // this.template = _.template(__inline('./platformList.html'));

    this.opts = opts || {};

    // this.$el = $('.js-w-rank_platform_list').find('.w-platform-list');
    if (this.opts.$dom && this.opts.$dom.length) {
        this.$el = this.opts.$dom.find('.w-platform-list').prevObject;
    } else {
        this.$el = $('.w-platform-list');
    }
    this.init();
};

PlatformList.prototype.init = function() {
    this.render();
    this.bindEvent();
};
PlatformList.prototype.render = function() {
    // this.$el.html(this.template({
    // 	'list': PLATFORM_LIST,
    // 	'platform': this.opts.platform
    // }));

    return this;
};
PlatformList.prototype.bindEvent = function() {
    var self = this;

    this.$el.on('click', 'div.swiper-slide', function() {
        var $this = $(this);
        var platform = $this.data('platform');
        if (platform != undefined) {
            if (!$this.hasClass('active')) {
                $this.addClass('active').siblings().removeClass('active');
                // self.curPlatform = platform;
                $.pub('platform/change', [{
                    'platform': platform
                }]);
            }
        }
    });
    return this;
};

module.exports = PlatformList;