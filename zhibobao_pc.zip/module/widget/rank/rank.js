var api = require('common/api');

/**
 * @param {String} [userType] [用户类型，主播'anchor', 新晋主播'new_anchor', 土豪'user']
 * @param {String} [platform]	[douyu，huya，quanmin，平台名拼音,没有的话则为全平台]
 * @param {Number} [category]	[类型，不传为全部]
 * @param {String} [timeType]	[时间类型：5分钟为minute、1小时为hour，今日为today；历史时间单日的为day；历史时间范围的为dayRange；]
 * @param {Number | String | Array} [timeValue] [对应时间类型的值：5分钟为5；1小时为1；历史单日如2017-08-10；历史范围为“[2017-07-01,2017-07-30]”]
 * @param {String | Array } [rankType] [榜单类型，'gift', 'barrage']
 * @param {Number} [limit] [限制展示的数量，默认不限制]
 */
function Rank(opts) {
	this.template = _.template(__inline('./rank.html'));
	this.opts = opts || {};
	this.limit = this.opts.limit || -1;
	this.params = {
		userType: this.opts.userType || 'anchor',
		platform: this.opts.platform,
		category: this.opts.category,
		timeType: this.opts.timeType || 'hour',
		timeValue: this.opts.timeValue || 1,
		rankType: this.opts.rankType || 'gift',
		limit: this.opts.limit || 5
	};
	this.rankData = {};
	if (this.opts.$dom && this.opts.$dom.length) {
		this.$el = this.opts.$dom.find('.w-rank');
	} else {
		this.$el = $('<div class="w-rank clearfix"></div>');
	}
	this.init();
};

Rank.prototype.init = function() {

};
Rank.prototype.render = function() {
	if (this.rankData) {
		if (this.opts.limit && this.rankData.list) {
			this.rankData.list = this.rankData.list.slice(0, this.opts.limit);
			if (this.params.rankType == 'gift') {
				for (var i = 0, len = this.rankData.list.length; i < len; i++) {
					this.rankData.list[i].value = this.rankData.list[i].value.toFixed(2);
				}
			}
		}
		this.$el.html(this.template(this.rankData));
	}
	this.$el.find(".lazy").lazyload();
	return this;
};
Rank.prototype.getData = function(data) {
	$.extend(this.params, data);
	var self = this;
	var path = "rank/list";

	api.get(path, this.params).done(function(data) {
		if (data.code == 0) {
			self.rankData = data.data;
			self.rankData.userType = self.params.userType;
			self.rankData.rankType = self.params.rankType;
			self.rankData.timeType = self.params.timeType;
			self.render();
			$.pub('rank/updateEnd', [{
				timestamp: data.data.timestamp,
				timeType: self.params.timeType,
				userType: self.params.userType,
				timeValue: self.params.timeValue
			}]);
		}
	}).fail(function() {
		self.rankData.list = [];
		self.render();
	});
};


module.exports = Rank;