/**
 * @param {String} [timeType] [时间类型：5分钟为minute、1小时为hour，今日为today；历史时间单日的为day；历史时间范围的为dayRange；]
 * @param {Number | String | Array} [timeValue] [对应时间类型的值：5分钟为5；1小时为1；历史单日如2017-08-10；历史范围为“[2017-07-01,2017-07-30]”]
 */
function RankUpdateTime(opts) {
	this.template = _.template(__inline('./rankUpdateTime.html'));

	this.opts = opts || {};
	// this.timeType = this.opts.timeType;
	// this.userType = this.opts.userType;
	// this.timeValue = this.opts.timeValue;
	// this.timestamp = this.opts.timestamp;

	// this.$el = $('<div class="w-rank-update-time" style="visibility: hidden"></div>');
	// this.$el = $('.w-rank-update-time');
	if (this.opts.$dom && this.opts.$dom.length) {
		this.$el = this.opts.$dom.find('.w-rank-update-time');
	} else {
		this.$el = $('.w-rank-update-time');
	}
	// this.init(this.opts.timestamp);
	// this.$el.html(this.template());
}

// RankUpdateTime.prototype.init = function() {
// 	this.render();
// };
// RankUpdateTime.prototype.render = function() {
// 	this.$el.html(this.template());
// 	this.update({
// 		timestamp: this.timestamp
// 	});
//
// 	return this;
// };
RankUpdateTime.prototype.update = function(data) {
	// this.$el.css('visibility', 'visible');
	var timeType = data.timeType || this.timeType;
	var timeValue = data.timeValue || this.timeValue;
	var userType = data.userType || this.userType;
	var t = new Date(Number(data.timestamp) * 1000);
	var str = [];

	if (timeType == 'day' || timeType == 'dayRange') {
		this.$el.html("");
		return;

	} else {
		this.$el.html(this.template());
	}
	if (timeType == 'minute') {

		str.push('最近<span class="w-rank-update-time_time"> ' + timeValue + '分钟 </span>');

	}
	if (timeType == 'hour') {

		str.push('最近<span class="w-rank-update-time_time"> ' + timeValue + '小时 </span>');

	}

	if (timeType == 'today') {

		str.push('<span class="w-rank-update-time_time"> 今日 </span>');

	}


	if (userType == "user") {
		str = ["礼物价值"];
	}

	this.$el.find('.js_time_type').html(str.join(''));
	this.$el.find('.js_lasttime').text(t.Format('hh:mm'));

	//
};

module.exports = RankUpdateTime;