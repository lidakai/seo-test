function Footer() {

    // if( window.location.hostname == 'www.zhibobao.com' ){
    //     this.template = _.template(__inline('./footer.html'));
    // }else{
    //     this.template = _.template(__inline('./footer_tv.html'));
    // }
    // this.$el = $('<div class="w-footer"></div>');

    // this.init();
};

// Footer.prototype.init = function() {
//     this.render();
//     this.bindEvent();
// };
// Footer.prototype.render = function() {
//     this.$el.html(this.template());

//     return this;
// };
// Footer.prototype.bindEvent = function() {
//     var self = this;

//     return this;
// };

module.exports = Footer;