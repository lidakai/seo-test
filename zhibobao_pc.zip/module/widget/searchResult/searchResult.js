var api = require('common/api');

/**
 * @param {String} [searchVal] [搜索关键词]
 * @param {Number} [page_num] [搜索的页数]
 */
function SearchResult(opts) {
    this.template = _.template(__inline('./searchResult.html'));
    this.$el = $('<div id="container"></div>');
    this.opts = opts || {};
    this.params = {
        page: this.opts.page || 1,
        search: this.opts.search,
        size:this.opts.size || 15
    };
    this.init();

}
SearchResult.prototype.render = function(data) {
    this.$el.html(this.template({
        'obj': data.data
    }));
};
SearchResult.prototype.init = function() {
    this.getData();
};
SearchResult.prototype.getData = function(data) {
    $.extend(this.params, data);
    if (!this.params.search) {
        this.$el.html( '<p class="default">(｢･ω･)｢嘿，请按套路来</p>' );
        return;
    }
    var self = this,
        path = 'search';
    api.get(path, this.params).done(function(data) {

        if (data.code == 0) {
            data.data.search= self.params.search;
            self.render({
                data: data.data
            });
            if( self.params.isPagination )return;
            $.pub('page/change', [{
                "page": Math.ceil( Number( data.data.total / self.params.size  ) ),
                "search": self.params.search,
                "current_page":1
            }]);
        }else{
            self.$el.html( '<p class="default">服务繁忙，请稍后重试</p>' );
            $.pub('page/change', [{"page": 0}]);
        }
    }).fail(function(data) {
        self.$el.html( '<p class="default">服务繁忙，请稍后重试</p>' );
        $.pub('page/change', [{"page": 0}]);
    });
};

module.exports = SearchResult;