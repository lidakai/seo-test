// 使用该模块的页面需引入echarts

var api = require('common/api');

/**
 * @param {Number} [company] [平台类型]
 * @param {String} [indicator] [指标：开播数anchor，礼物价值gift，弹幕数barrage，新增主播new_anchor]
 * @param {String} [timeType]	[时间类型：5分钟为minute、1小时为hour，今日为today；历史时间单日的为day；历史时间范围的为dayRange；]
 * @param {Number | String | Array} [timeValue] [对应时间类型的值：5分钟为5；1小时为1；历史单日如2017-08-10；历史范围为“[2017-07-01,2017-07-30]”]
 */
// 发送参数
// type参数：barrage弹幕量，发言人数chatPerson，barrageAvg人均弹幕
//             gift礼物价值，giftPerson送礼人数，giftAvg人均送礼，
//             liveTime直播时长，online在线人数
// dateRange: 7为7日，30为30日,
// platform: douyu,
// roomid: 12345
//
//
// {
//      type：['barrage', 'gift'],
//      dateRange: 7,
//      platform: 'douyu',
//      roomid: 12345
// }
function LieCharts(data) {
    this.data = data.value;
    switch ( data.type ){
        case "barrage":
        case "barrageAvg":
            this.unit = "条";
            break;
        case "chatPerson":
        case "giftPerson":
        case "online":
            this.unit = "人";
            break;
        case "liveTime":
            this.unit = "h";
            break;
        case "gift":
        case "giftAvg":
            this.unit = "元";
            break;
        default:
            this.unit = "人";
            break;
    }
    this.$el = $('<div class="w-lie-charts"></div>');
};

LieCharts.prototype.init = function() {
    var xAxisData = [];
    var seriesData = [];
    var self = this;
    $.each(self.data, function(i, n) {
        xAxisData.push(i);
        seriesData.push(Number(n));
    });
    var unit  = ZBB.IsBeyond( seriesData );
    if( unit ){
        ZBB.dataChange( seriesData );
        self.unit = "万"+self.unit;
    }
    self.render({
        xAxisData: xAxisData,
        seriesData: seriesData,
        unit:this.unit
    });
};
LieCharts.prototype.render = function(chartParams) {
    echarts.init(this.$el[0]).clear();
    this.myChart = echarts.init(this.$el[0]);

    this.myChartOption = {
        backgroundColor: {
            type: 'pattern',
            image: ZBB.canvasWaterMark(),
            repeat: 'repeat'
        },
        title: {
            show: false
        },
        tooltip: {
            trigger: 'axis',
            axisPointer: { // 坐标轴指示器，坐标轴触发有效
                type: 'shadow', // 默认为直线，可选为：'line' | 'shadow'
                shadowStyle: {
                    color: {
                        type: 'linear',
                        x: 0,
                        y: 0,
                        x2: 0,
                        y2: 1,
                        colorStops: [{
                            offset: 0,
                            color: 'rgba(48, 131, 255, 0)' // 0% 处的颜色
                        }, {
                            offset: 1,
                            color: 'rgba(48, 131, 255, 0.1)' // 100% 处的颜色
                        }],
                        globalCoord: false // 缺省为 false
                    }
                }
            }
        },
        legend: {},
        toolbox: {
            show: false
        },
        xAxis: [{
            type: 'category',
            axisLabel: {
                textStyle: {
                    color: '#8492af'
                },
            },
            axisLine: {
                lineStyle: {
                    type: 'dotted',
                    color: '#8492af'
                }
            },
            boundaryGap: false,
            data: chartParams.xAxisData
        }],
        yAxis: [{
            type: 'value',
            axisLabel: {
                textStyle: {
                    color: '#8492af'
                },
                formatter: '{value}' + chartParams.unit
            },
            axisLine: {
                lineStyle: {
                    type: 'dotted',
                    color: '#8492af'
                }
            },
            axisTick: {
                show: false
            },
            splitLine: {
                lineStyle: {
                    type: 'dotted',
                    color: '#8492af',
                    opacity: 0.55
                }
            }
        }],
        animation:false,
        // animationDuration:500,
        series: [{
            name: '',
            type: 'line',
            data: chartParams.seriesData,
            itemStyle: {
                normal: {
                    color: "#6796ff",
                    areaStyle: {
                        type: 'default',
                        color: {
                            type: 'linear',
                            x: 0,
                            y: 0,
                            x2: 0,
                            y2: 1,
                            colorStops: [{
                                offset: 0,
                                color: 'rgba(48, 131, 255, 1)' // 0% 处的颜色
                            }, {
                                offset: 1,
                                color: 'rgba(48, 131, 255, 0.2)' // 100% 处的颜色
                            }],
                            globalCoord: false // 缺省为 false
                        }

                    },
                    lineStyle: {
                        color: "#6796ff"
                    }
                }
            }

        }]
    };
    this.myChart.setOption(this.myChartOption);

    return this;
};

module.exports = LieCharts;