var api = require('common/api');

var DayList = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];

// 直播密度
// 返回最近30天的直播
// day表示周1-周日的，该日有过直播就加1；
// time表示一天24小时的，1表示0-1点，24表示23-24点，在该范围内有在直播的就加1
function LiveDensity( opts ) {

    this.opts = opts || {};
    this.params = {
        platform:this.opts.platform,
        roomId:this.opts.roomId
    };

    this.template = _.template(__inline('./liveDensity.html'));
    this.$el = $('<div class="w-live-density clearfix"></div>');
    this.getData();
};

LiveDensity.prototype.init = function() {
    var self = this;
    var dayDensity = [];
    var timeDensity = [];
    $.each(self.data.day, function(i, n) {
        dayDensity.push({
            name: i,
            value: Number(n),
            week_level: self.getWeekColor(n)
        });
    });
    $.each(self.data.time, function(i, n) {
        timeDensity.push({
            name: i,
            value: Number(n),
            hour_level: self.getHourColor(n)
        });
    });
    self.render({
        dayList: DayList,
        dayDensity: dayDensity,
        timeDensity: timeDensity
    });
};
LiveDensity.prototype.render = function(data) {
    this.$el.html(this.template({
        'data': data
    }));
    return this;
};

LiveDensity.prototype.getData = function(data) {
    $.extend( this.params , data );
    var self = this;
    var path = "anchor/live";

    api.get(path, this.params).done(function(data) {
        if ( data.code == 0 ) {
            self.data = data.data.live;
            self.init()
        }
    })
};

LiveDensity.prototype.getWeekColor = function(val) {
    var week_level ="";
    switch  ( val ){
        case 0 :
            week_level = "week_level1";
            break;
        case 1 :
            week_level = "week_level2";
            break;
        case 2 :
            week_level = "week_level3";
            break;
        case 3 :
            week_level = "week_level4";
            break;
        case 4 :
            week_level = "week_level5";
            break;
        case 5 :
            week_level = "week_level6";
            break;
        default:
            week_level = "week_level6";
    }
    return week_level;
};

LiveDensity.prototype.getHourColor = function(val) {
    var hour_level ="";
    switch  ( true ){
        case val == 0 :
            hour_level = "hour_level1";
            break;
        case val<=5:
            hour_level = "hour_level2";
            break;
        case val<=10 :
            hour_level = "hour_level3";
            break;
        case val<=18 :
            hour_level = "hour_level4";
            break;
        case val<=24 :
            hour_level = "hour_level5";
            break;
        case val<=28 :
            hour_level = "hour_level6";
            break;
        case val<=30 :
            hour_level = "hour_level7";
            break;
        case val<=31 :
            hour_level = "hour_level8";
            break;
        default:
            return "hour_level8";
    }
    return  hour_level;
};

module.exports = LiveDensity;