function Pagination(opts) {
	this.template = _.template(__inline('./pagination.html'));
	this.$el = $( "<div class='w-pagination'></div>" );
	this.opts = opts || {};
	this.params = {
        page : this.opts.page || 1,
        current_page:this.opts.current_page||1,
        search:this.opts.search
	};
    this.limit = 0;
	this.init({});
	this.bindEvent();
};

Pagination.prototype.init = function(data) {
    var self =this;
    // if( self.params.search == data.search && self.params.page == data.page )return;//换页时不更新分页
	$.extend( this.params , data );
    var obj = {},page_arr = [];
    self.limit = this.params.page > 5 ? (this.params.current_page > 1 ? (  this.params.page - this.params.current_page > 5 ? (this.params.current_page + 4) : this.params.page) : 5) : this.params.page;
    for( var i =this.params.current_page; i <= self.limit ; i++ ){
        page_arr.push( i );
    }
    if( data.special ){
        var active = this.limit;
        $.pub('search/getResult', [{
            'isPagination':true,
            "page":active
        }])
    }else{
        var active = this.params.current_page
    }
    this.render(({
        page_arr:page_arr,
        page:this.params.page,
        limit:this.limit,
        current_page:active
    }));
};
Pagination.prototype.render = function(obj) {
	this.$el.html(this.template({
		"page_obj":obj
	}));
	return this;
};
Pagination.prototype.bindEvent = function() {
	var self = this;
	self.$el.on('click','i',function () {
		var $this = $(this);
		if( $this.hasClass("active") )return;
		// 前后非数字按钮显示、隐藏
		if( $this.data("value") == "1" ){
            $(".w-searchResult-first,.w-searchResult-prev").addClass("disable");
            $(".w-searchResult-last,.w-searchResult-next").removeClass("disable");
		}else if( $this.data("value") == self.params.page  ){
            $(".w-searchResult-last,.w-searchResult-next").addClass("disable");
            $(".w-searchResult-first,.w-searchResult-prev").removeClass("disable");
        }else{
            $(".w-searchResult-last,.w-searchResult-next,.w-searchResult-first,.w-searchResult-prev").removeClass("disable");
		}
        $this.addClass("active").siblings().removeClass("active");
        $.pub('search/getResult', [{
            'isPagination':true,
        	"page":$this.data("value")
		}])
    });
    //首页点击
    self.$el.on('click','.w-searchResult-first',function () {
        if( $(this).hasClass("disable") )return;
        if( self.limit > 5 ){
            //    重新渲染
            self.init({current_page:1});
            $.pub('search/getResult', [{
                'isPagination':true,
                "page":1
            }]);
            return;
        }
        $(".w-searchResult-first,.w-searchResult-prev").addClass("disable");
        $(".w-searchResult-last,.w-searchResult-next").removeClass("disable");
        $(".w-searchResult-prev-ellipsis").css("display","none");
        self.$el.find('[data-value="1"]').addClass("active").siblings().removeClass("active");
        $.pub('search/getResult', [{
            'isPagination':true,
            "page":1
        }])
    });
    //末页点击
    self.$el.on('click','.w-searchResult-last',function () {
        if( $(this).hasClass("disable") )return;
        if( self.limit < self.params.page ){
        //    重新渲染
            var mod = self.params.page % 5;
            if( mod ){
                self.init({current_page:self.params.page - mod + 1,special:"lastpage"});
            }else{
                self.init({current_page:self.params.page - 4 ,special:"lastpage"});
            }
            return;
        }
        $(".w-searchResult-last,.w-searchResult-next").addClass("disable");
        $(".w-searchResult-first,.w-searchResult-prev").removeClass("disable");
        self.$el.find('[data-value="' + self.limit + '"]').addClass("active").siblings().removeClass("active");
        $.pub('search/getResult', [{
            'isPagination':true,
            "page":self.limit
        }])
    });

    //上一页点击
    self.$el.on('click','.w-searchResult-prev',function () {
        if( $(this).hasClass("disable") )return;
        var val = self.$el.find(".active").data( "value" );
        if( val == "2" ){
            self.$el.find('[data-value="1"]').addClass("active").siblings().removeClass("active");
            $(".w-searchResult-first,.w-searchResult-prev").addClass("disable");
            $(".w-searchResult-prev-ellipsis").css("display","none");
        }else if( val == self.params.current_page && val != '1'){
            //重新渲染
            self.init({current_page:self.params.current_page-5,special:"lastpage"});
            return;
        }else{
            $(".w-searchResult-last,.w-searchResult-next").removeClass("disable");
            self.$el.find('.active').prev().addClass("active").siblings().removeClass("active");
        }
        $.pub('search/getResult', [{
            'isPagination':true,
            "page":self.$el.find('.active').data("value")
        }])
    });

    //下一页点击
    self.$el.on('click','.w-searchResult-next',function () {
        if( $(this).hasClass("disable") )return;
        var val = self.$el.find(".active").data( "value" );
        if( val == self.params.page - 1 ){
            $(".w-searchResult-last,.w-searchResult-next").addClass("disable");
            self.$el.find('[data-value="' + self.limit + '"]').addClass("active").siblings().removeClass("active");
            $(".w-searchResult-next-ellipsis").css("display","none");
        }else if( val == self.limit && self.limit < self.params.page ){
            // 重新渲染
            self.init({current_page:self.params.current_page+5});
            $.pub('search/getResult', [{
                "page":self.params.current_page
            }])
            return;
        }else{
            $(".w-searchResult-first,.w-searchResult-prev").removeClass("disable");
            self.$el.find('.active').next().addClass("active").siblings().removeClass("active");
        }
        $.pub('search/getResult', [{
            'isPagination':true,
            "page":self.$el.find('.active').data("value")
        }])
    });

    //上一页省略点击
    self.$el.on('click','.w-searchResult-prev-ellipsis',function () {
        self.init({current_page:self.params.current_page-5,special:"lastpage"});
    });

    //下一页省略点击
    self.$el.on('click','.w-searchResult-next-ellipsis',function () {
        self.init({current_page:self.params.current_page+5});
        $.pub('search/getResult', [{
            'isPagination':true,
            "page":self.params.current_page
        }])
    });
	return this;
};
module.exports = Pagination;