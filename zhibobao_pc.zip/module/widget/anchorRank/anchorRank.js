
var api = require('common/api');
// 直播密度
// 返回最近30天的直播
// day表示周1-周日的，该日有过直播就加1；
// time表示一天24小时的，1表示0-1点，24表示23-24点，在该范围内有在直播的就加1
function anchorRank( data ) {
	this.template = _.template(__inline('./anchorRank.html'));

    this.data =data;
	this.$el = $('<div></div>');
};

anchorRank.prototype.init = function() {
    var self = this;
    this.render({
        data:self.data
    })
};
anchorRank.prototype.render = function(data) {
	this.$el.html( this.template({
        'anchorRank':data.data
	}));
	return this;
};
module.exports = anchorRank;