// var api = require('common/api');

function CategoryList(opts) {
    // this.template = _.template(__inline('./categoryList.html'));

    this.opts = opts || {};
    // this.params = {
    // 	platform: this.opts.platform || "",
    // 	category: this.opts.category || ""
    // };
    // this.hasAllCate = this.opts.hasAllCate || false;
    // this.dataPage = this.opts.dataPage || false;
    // this.categoryList = [];
    // this.$el = $('<ul class="w-category-list clearfix"></ul>');
    // this.$el = $('.w-category-list');
    if (this.opts.$dom && this.opts.$dom.length) {
        this.$el = this.opts.$dom.find('.w-category-list').prevObject;
    } else {
        this.$el = $('.w-category-list');
    }
    this.init();
}

CategoryList.prototype.init = function() {
    this.bindEvent();
};

CategoryList.prototype.bindEvent = function() {
    var self = this;

    this.$el.on('click', 'div.swiper-slide', function() {
        var $this = $(this);
        var category = $this.data('category');
        if (category != undefined) {
            if (!$this.hasClass("active")) {
                $this.addClass('active').siblings().removeClass('active');
                $.pub('category/change', [{
                    'category': category
                }]);
            }
        }

        /*if (self.hasAllCate) {
            $.pub('category/change', [{
                'category': category
            }]);
            return;
        }
        if (category != undefined) {
            if (!$this.hasClass("active")) {
                if (self.dataPage) {
                    localStorage.category = category;
                }
                $this.addClass('active').siblings().removeClass('active');
                $.pub('category/change', [{
                    'category': category
                }]);
            }
        }*/
    });

    return this;
};

module.exports = CategoryList;