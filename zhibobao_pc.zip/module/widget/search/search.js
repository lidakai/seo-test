var api = require('common/api');

/**
 * @param {String} [searchVal] [搜索关键词]
 */
function Search(opts) {
    this.opts = opts || {};
    
    // this.template = _.template(__inline('./search.html'));
    this.templateSearchList = _.template(__inline('./searchList.html'));

    // this.$el = $('<div class="w-search" id="w-search"></div>');
    if (this.opts.$dom && this.opts.$dom.length) {
        this.$el = this.opts.$dom.find('.w-search');
    } else {
        this.$el = $('.w-search');
    }
    this.params = {
        'isPagination': false,
        search: this.opts.search,
        size: 10
    };
    this.init();
}
Search.prototype.render = function() {
    // var self = this;
    // this.$el.html(self.template());
};
Search.prototype.init = function() {
    this.render();
    this.bindEvent();
};
Search.prototype.getData = function(data) {
    $.extend(this.params, data);
    var self = this,
        path = 'search';
    api.get(path, this.params).done(function(data) {
        if (data.code == 0) {
            var arr = [];
            $.each(data.data.list, function(index, item) {
                // 同时替换大小写
                var arrMatch = item.nickname.match(eval('/' + self.params.search + '/gi'));
                var replaceItem = item.nickname;
                $.each(arrMatch, function(i, n) {
                    replaceItem = replaceItem.replace(eval('/' + n + '/g'), '<i class="replaceItem">' + n + '</i>');
                });

                arr.push({
                    item: item.nickname,
                    replaceItem: replaceItem,
                    plat: item.plat
                });
            });
            self.$el.find('.js_w-search_list').html(self.templateSearchList({
                'data': arr
            }));
        }
    });
};

Search.prototype.bindEvent = function() {
    var self = this;
    //搜索点击
    this.$el.find(".w-icon_search").on("click", function() {
        self.params.search = $(this).next().val();
        if (!self.params.search) return;
        self.$el.find("input").val("");
        if (self.opts.flag == 'search') {

            self.$el.find('.js_w-search_list').hide();
            $.pub('search/getResult', [{
                isPagination: false,
                page: 1,
                search: self.params.search
            }]);
        } else {
            window.open("/search?search=" + self.params.search)
        }

    });

    //搜索结果点击
    self.$el.find('.js_w-search_list').on("click", ".w-search-result-value", function() {
        self.params.search = $(this).data('value');
        if (self.opts.flag == 'search') {
            self.$el.find("input").val("");
            self.$el.find('.js_w-search_list').hide();
            $.pub('search/getResult', [{
                isPagination: false,
                page: 1,
                search: self.params.search
            }]);
        } else {
            // location.href = "/search?search=" + self.params.search;
            window.open("/search?search=" + self.params.search)
        }
    });
    // 输入框请求
    this.$el.find("input").on("keyup",
        _.debounce(function(event) {
            var code = event.which || event.keyCode,
                val = $(this).val();
            if (!val) {
                self.$el.find('.js_w-search_list').hide();
                return;
            }
            if (code == 37 || code == 38 || code == 39 || code == 40) return;
            self.$el.find('.js_w-search_list').show();
            self.params.search = $(this).val();
            if (code == 13) {
                self.$el.find("input").val("");
                self.$el.find('.js_w-search_list').hide();
                if (self.$el.find(".w-search-result-value").hasClass("active")) {
                    self.params.search = self.$el.find(".active").data("value");
                }
                if (self.opts.flag == 'search') {
                    self.$el.find('.js_w-search_list').hide();
                    $.pub('search/getResult', [{
                        isPagination: false,
                        page: 1,
                        search: self.params.search
                    }]);
                } else {
                    window.open("/search?search=" + self.params.search)
                }
            } else {
                self.getData({
                    search: self.params.search
                });
            }
        }, 300));
    this.$el.find("input").on("keydown", function(event) {
        var $this = $(this);
        var code = event.which || event.keyCode;
        if (code == 38) { //上
            if ($this.next().find(".w-search-result-value").hasClass("active")) {
                if (!$this.next().find(".w-search-result-value").prev()) {
                    $this.next().find(".w-search-result-value").first().addClass("active");
                } else {
                    $this.next().find(".active").removeClass("active").prev().addClass("active");
                }
            } else {
                $this.next().find(".w-search-result-value").first().addClass("active");
            }
        } else if (code == 40) { //下
            if ($this.next().find(".w-search-result-value").hasClass("active")) {

                if (!$this.next().find(".w-search-result-value").next()) {
                    $this.next().find(".w-search-result-value").first().addClass("active");
                } else {
                    $this.next().find(".active").removeClass("active").next().addClass("active");
                }
            } else {
                $this.next().find(".w-search-result-value").first().addClass("active");
            }
        }
    });
    $('body').click(function(e) {
        if ($(e.target).closest("#w-search").length == 0) {
            self.$el.find('.js_w-search_list').hide();
        }
    });
    return this;
};

module.exports = Search;