var CategoryList = require('widget/categoryList');
var IndustryCharts = require('widget/industryCharts');
var PlatformList = require('widget/platformList');
var PieCharts = require('widget/pieCharts');
var ResultList = require('widget/resultList');
var TimeList = require('widget/timeList');
var IndicatorList = require('widget/indicatorList');

function PlatformPage() {
	this._template = _.template(__inline('./platform.html'));

	this.$el = $('<div class="platform-wrap"></div>');
	this.$el.html(this._template());

	this.$category_list = this.$el.find('.js-w-platform_category_list');
	this.$category_indicator_list = this.$el.find('.js-w-platform_category_indicator_list');
	this.$company_indicator_list = this.$el.find('.js-w-platform_company_indicator_list');
	this.$industry_charts = this.$el.find('.js-w-platform_industry_charts');
	this.$platform_list = this.$el.find('.js-w-platform_company_list');
	this.$pie_charts = this.$el.find('.js-w-platform_pie_charts');
	this.$company_resultlist = this.$el.find('.js-w-platform_company_result_list');
	this.$category_resultlist = this.$el.find('.js-w-platform_category_result_list');
	this.$company_timelist = this.$el.find('.js-w-platform_company_time_list');
	this.$category_timelist = this.$el.find('.js-w-platform_category_time_list');

	this.isFirstInitResult = false;
	this.init();
}

PlatformPage.prototype.init = function() {
	this.dataOption = {
		category: 1,
		platform: "",
		indicator: "barrage",
		timeType: "hour",
		timeValue: "1"
	};
	this.render();
	this.bindEvent();
};
PlatformPage.prototype.bindEvent = function() {
	var self = this;

	//初始化分类列表再初始化柱状图、总数据结果
	$.sub('category/getCategory', function(e, data) {
		if (self.isFirstInitResult) return;
		self.isFirstInitResult = true;
		self.dataOption.category = data.category;
		self.categoryResultList = new ResultList(data);
		self.$category_resultlist.html(self.categoryResultList.$el);
		self.renderIndustryCharts();
	});

	// 行业-频道类型
	$.sub('category/change', function(e, data) {
		self.dataOption.category = Number(data.category);
		self.industryCharts.getData(data);
		self.$industry_charts.html(self.industryCharts.$el);
		self.categoryResultList.getData(data);
	});

	// 行业-指标
	$.sub('indicator/change', function(e, data) {
		if (data.type == "category") {
			self.industryCharts.getData(data);
			self.$industry_charts.html(self.industryCharts.$el);
		} else {
			self.pieCharts.getData(data);
			self.$pie_charts.html(self.pieCharts.$el);
		}
	});

	//行业-平台类型
	$.sub('platform/change', function(e, data) {
		self.pieCharts.getData(data);
		self.$pie_charts.html(self.pieCharts.$el);
		self.companyResultList.getData(data);
	});

	// 时间选择
	$.sub('timeType/change', function(e, data) {
		if (data.type == "category") {
			self.industryCharts.getData(data);
			self.$industry_charts.html(self.industryCharts.$el);
		} else {
			self.pieCharts.getData(data);
			self.$pie_charts.html(self.pieCharts.$el);
		}
	});
};
PlatformPage.prototype.render = function() {
	this.categoryList = new CategoryList({
        dataPage :true
	});
	this.$category_list.prepend(this.categoryList.$el);

	this.platformList = new PlatformList();
	this.$platform_list.prepend(this.platformList.$el);

	// 行业-指标
	this.renderIndicator();

	this.renderPieCharts();

	this.companyResultList = new ResultList();
	this.$company_resultlist.html(this.companyResultList.$el);

	//时间组件
	this.renderTimeList();

	return this;
};

PlatformPage.prototype.renderIndustryCharts = function() {
	this.industryCharts = new IndustryCharts({
		category: this.dataOption.category,
		indicator: this.dataOption.indicator,
		timeType: this.dataOption.timeType,
		timeValue: this.dataOption.timeValue
	});
	this.$industry_charts.html(this.industryCharts.$el);
};
PlatformPage.prototype.renderPieCharts = function() {
	this.pieCharts = new PieCharts({
		platform: this.dataOption.platform,
		indicator: this.dataOption.indicator,
		timeType: this.dataOption.timeType,
		timeValue: this.dataOption.timeValue
	});
	this.$pie_charts.html(this.pieCharts.$el);
};
PlatformPage.prototype.renderTimeList = function() {
	this.categoryTimeList = new TimeList({
		'type': 'category',
        'timeType':this.dataOption.timeType,
        'timeValue':this.dataOption.timeValue
	});
	this.$category_timelist.html(this.categoryTimeList.$el);

	this.companyTimeList = new TimeList({
		'type': 'company',
        'timeType':this.dataOption.timeType,
        'timeValue':this.dataOption.timeValue
	});
	this.$company_timelist.html(this.companyTimeList.$el);
};
PlatformPage.prototype.renderIndicator = function() {
	this.category_indicator_list = new IndicatorList({
		'type': 'category'
	});
	this.$category_indicator_list.html(this.category_indicator_list.$el);

	this.company_indicator_list = new IndicatorList({
		'type': 'company'
	});
	this.$company_indicator_list.html(this.company_indicator_list.$el);
};


PlatformPage.prototype.destroy = function() {
	this.$el.remove();
	this.$el = null;
	$.unsub('category/getCategory');
	$.unsub('category/change');
	$.unsub('indicator/change');
	$.unsub('platform/change');
	$.unsub('timeType/change');
};

module.exports = function(ctx, callback) {
	callback(new PlatformPage());
};