var RankTab = require('widget/rankTab');
var PlatformList = require('widget/platformList');
var Rank = require('widget/rank');
var RankUpdateTime = require('widget/rank/rankUpdateTime.js');
var CategoryList = require('widget/categoryList');
var IndustryCharts = require('widget/industryCharts');
var IndicatorList = require('widget/indicatorList');
var ResultList = require('widget/resultList');
// var Search = require('widget/search');

function IndexPage() {
	this._template = _.template(__inline('./index.html'));

	this.$el = $('<div></div>');
	this.$el.html(this._template());

	this.$platform_list = this.$el.find('.js-w-index-platform_list');
	this.$rank_tab = this.$el.find('.js-w-index_rank_tab');
	this.$gift_rank = this.$el.find('.js-w-index_rank_gift');
	this.$barrage_rank = this.$el.find('.js-w-index_rank_barrage');
	this.$rank_update_time = this.$el.find('.js-w-index_rank_update_time');
	this.$category_list = this.$el.find('.js-w-index_category_list');
	this.$indicator_list = this.$el.find('.js-w-index_indicator_list');
	this.$industry_charts = this.$el.find('.js-w-index_industry_charts');
	this.$resultlist = this.$el.find('.js_w_resultlist');

	this.isFirstInitIndexCategory =false;
	this.init();
}

IndexPage.prototype.init = function() {
	this.render();
	this.bindEvent();
};
IndexPage.prototype.bindEvent = function() {
	var self = this;

    //初始化分类列表再初始化柱状图
    $.sub('category/getCategory', function ( e ,data ) {
        if( self.isFirstInitIndexCategory )return;
        self.isFirstInitIndexCategory = true;
        self.renderIndustryCharts( data );
    });


	// 榜单
	$.sub('rankTab/change', function(e, data) {
        //修改下部按钮的href属性
        var url = $(".more-rank").attr( "href" );
        $(".more-rank").attr( "href" , self.replaceParams( url , "userType" , data.userType ) );

		self.giftRank.getData({
			'userType': data.userType
		});

		if (data.userType == "user") {
			self.barrageRank.getData({
				'userType': data.userType,
				'rankType': 'gift',
				'timeType':'today',
				'timeValue':(new Date()).Format('yyyy/MM/dd').replace(/\//g,"").replace(/\s/g,"")
			});
		} else {
			self.barrageRank.getData({
				'userType': data.userType,
				'rankType': 'barrage',
                'timeType':'hour',
                'timeValue':1
			});

		}
	});

	$.sub('platform/change', function(e, data) {
        //修改下部按钮的href属性
        var url = $(".more-rank").attr( "href" );
        $(".more-rank").attr( "href" , self.replaceParams( url , "platform" , data.platform ) );

		self.giftRank.getData({
			'platform': data.platform
		});
		self.barrageRank.getData({
			'platform': data.platform
		});
	});

	$.sub('rank/updateEnd', function(e, data) {
		self.rankUpdateTime.update(data);
	});

	// 行业-频道类型
	$.sub('category/change', function(e, data) {
		self.industryCharts.getData(data);
	});

	// 行业-指标
	$.sub('indicator/change', function(e, data) {
		self.industryCharts.getData(data);
	});

	// 时间选择
	$.sub('timeType/change', function(e, data) {
		self.industryCharts.getData(data);
	});
};
IndexPage.prototype.render = function() {
	
	this.rankTab = new RankTab();
	this.$rank_tab.html(this.rankTab.$el);

	this.platformList = new PlatformList();
	this.$platform_list.prepend(this.platformList.$el);

	this.indicatorList = new IndicatorList();
	this.$indicator_list.html(this.indicatorList.$el);

	this.renderRank();

	this.categoryList = new CategoryList();
	this.$category_list.html(this.categoryList.$el);

	this.resultList = new ResultList({
		'pageType': 'index',
		'anim': true
	});
	this.$resultlist.html(this.resultList.$el);
    this.getValue(true, 60000*3);

	return this;
};


IndexPage.prototype.renderRank = function(data) {
	this.giftRank = new Rank({
		rankType: 'gift',
		limit: 5,
		timeType: 'hour',
		timeValue: 1
	});
	this.$gift_rank.html(this.giftRank.$el);

	this.barrageRank = new Rank({
		rankType: 'barrage',
		limit: 5,
		timeType: 'hour',
		timeValue: 1
	});
	this.$barrage_rank.html(this.barrageRank.$el);

	this.rankUpdateTime = new RankUpdateTime({
		timeType: 'hour',
		timeValue: 1
	});
	this.$rank_update_time.html(this.rankUpdateTime.$el);
};
IndexPage.prototype.renderIndustryCharts = function(data) {
	var $dom = this.$indicator_list.find('li').eq(0);

	this.industryCharts = new IndustryCharts({
		indicator: $dom.data('indicator'),
		timeType: 'hour',
		timeValue: 1,
		category:data.category
	});
	this.$industry_charts.html(this.industryCharts.$el);
};

IndexPage.prototype.replaceParams = function( url , arg ,arg_val ) {
	var pattern=arg+'=([^&]*)';
	var replaceText=arg+'='+arg_val;
	if(url.match(pattern)){
		var tmp='/('+ arg+'=)([^&]*)/gi';
		tmp=url.replace(eval(tmp),replaceText);
		return tmp;
	}else{
		if(url.match('[\?]')){
			return url+'&'+replaceText;
		}else{
			return url+'?'+replaceText;
		}
	}
};

IndexPage.prototype.getValue = function(isTrue, cycleTime) {
    cycleTime || (cycleTime = 60000);
	var self = this ;
    if( isTrue ){
        window.count_timer = setInterval(function () {
            self.resultList.getData();
        }, cycleTime);
	}else{
        clearInterval(window.count_timer);
	}


};

IndexPage.prototype.destroy = function() {
	this.$el.remove();
	this.$el = null;
	this.getValue(false);
	$.unsub('category/getCategory');
	$.unsub('rankTab/change');
	$.unsub('platform/change');
	$.unsub('rank/updateEnd');
	$.unsub('category/change');
	$.unsub('indicator/change');
	$.unsub('timeType/change');
};

module.exports = function(ctx, callback) {
	callback(new IndexPage());
};