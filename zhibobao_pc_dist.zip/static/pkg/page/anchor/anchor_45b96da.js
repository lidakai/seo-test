define('common/apiExpire', function(require, exports, module){
	function localSign() {
		var key = 'GapV#&2%b';
		var timestamp = new Date().getTime();
		var val = md5(timestamp + key);
		return {
			'sign': val,
			'timestamp': timestamp
		};
	}
	
	module.exports = localSign;
});;
define('common/api', function(require, exports, module){
	var LocalSign = require('common/apiExpire');
	
	var REQUEST_TIMEOUT = 20000;
	
	var API_PREFIX = '/api/';
	
	
	function getApiUrl(path) {
		if (/\.\.*\//.test(path) || /http/.test(path)) {
			return path;
		} else {
			return API_PREFIX + path;
		}
	    console.log(path);
	}
	var API = {
		get: function(path, data, callback) {
			var localSign = LocalSign();
			data = $.extend({}, data, {
				'_timestamp': localSign.timestamp,
				'source': 0
			});
			var $defer = $.Deferred();
	
			$.ajax({
				type: 'get',
				url: getApiUrl(path),
				data: data,
				dataType: 'json',
				headers: {
					'T-code': localSign.sign
				},
				crossDomain: true,
				xhrFields: {
					withCredentials: true
				},
				timeout: REQUEST_TIMEOUT,
				success: function(data) {
					typeof(callback) == 'function' && callback(data);
	                if (data) {
						$defer.resolve(data);
					} else {
						$defer.reject();
					}
				},
				error: function(xhr, state) {
	                console.log(state);
					typeof(callback) == 'function' && callback(state);
					$defer.reject(state);
				}
			});
			return $defer;
		},
		post: function(path, data, callback) {
			var timestamp = LocalSign();
			data = $.extend({}, data, {
				'_timestamp': localSign.timestamp,
				'source': 0
			});
			var $defer = $.Deferred();
	
			$.ajax({
				type: 'post',
				url: getApiUrl(path),
				data: data,
				dataType: 'json',
				headers: {
					'T-code': localSign.sign
				},
				crossDomain: true,
				xhrFields: {
					withCredentials: true
				},
				timeout: REQUEST_TIMEOUT,
				success: function(data) {
					typeof(callback) == 'function' && callback(data);
	
					if (data) {
						$defer.resolve(data);
					} else {
						$defer.reject();
					}
				},
				error: function(xhr, state) {
					typeof(callback) == 'function' && callback(state);
					$defer.reject(state);
				}
			});
	
			return $defer;
		}
	};
	
	module.exports = API;
});;
define('widget/search', function(require, exports, module){
	var api = require('common/api');
	
	/**
	 * @param {String} [searchVal] [搜索关键词]
	 */
	function Search(opts) {
	    this.opts = opts || {};
	    
	    // this.template = _.template(__inline('./search.html'));
	    this.templateSearchList = _.template("<% if( data.length ) {%>\r\n<ul class=\"w-search-result\">\r\n    <% _.each(data, function(obj, index) { %>\r\n    <li class=\"w-search-result-value\" data-value=\"<%= obj.item %>\">\r\n    \t<% if( obj.plat ) { %>\r\n    \t<img src=\"<%= ZBB.platformDefaultAvatar[obj.plat] %>\">\r\n    \t<% } %>\r\n    \t<a href=\"javascript:;\"><%= obj.replaceItem %></a>\r\n    </li>\r\n    <% }) %>\r\n</ul>\r\n<% } %>");
	
	    // this.$el = $('<div class="w-search" id="w-search"></div>');
	    if (this.opts.$dom && this.opts.$dom.length) {
	        this.$el = this.opts.$dom.find('.w-search');
	    } else {
	        this.$el = $('.w-search');
	    }
	    this.params = {
	        'isPagination': false,
	        search: this.opts.search,
	        size: 10
	    };
	    this.init();
	}
	Search.prototype.render = function() {
	    // var self = this;
	    // this.$el.html(self.template());
	};
	Search.prototype.init = function() {
	    this.render();
	    this.bindEvent();
	};
	Search.prototype.getData = function(data) {
	    $.extend(this.params, data);
	    var self = this,
	        path = 'search';
	    api.get(path, this.params).done(function(data) {
	        if (data.code == 0) {
	            var arr = [];
	            $.each(data.data.list, function(index, item) {
	                // 同时替换大小写
	                var arrMatch = item.nickname.match(eval('/' + self.params.search + '/gi'));
	                var replaceItem = item.nickname;
	                $.each(arrMatch, function(i, n) {
	                    replaceItem = replaceItem.replace(eval('/' + n + '/g'), '<i class="replaceItem">' + n + '</i>');
	                });
	
	                arr.push({
	                    item: item.nickname,
	                    replaceItem: replaceItem,
	                    plat: item.plat
	                });
	            });
	            self.$el.find('.js_w-search_list').html(self.templateSearchList({
	                'data': arr
	            }));
	        }
	    });
	};
	
	Search.prototype.bindEvent = function() {
	    var self = this;
	    //搜索点击
	    this.$el.find(".w-icon_search").on("click", function() {
	        self.params.search = $(this).next().val();
	        if (!self.params.search) return;
	        self.$el.find("input").val("");
	        if (self.opts.flag == 'search') {
	
	            self.$el.find('.js_w-search_list').hide();
	            $.pub('search/getResult', [{
	                isPagination: false,
	                page: 1,
	                search: self.params.search
	            }]);
	        } else {
	            window.open("/search?search=" + self.params.search)
	        }
	
	    });
	
	    //搜索结果点击
	    self.$el.find('.js_w-search_list').on("click", ".w-search-result-value", function() {
	        self.params.search = $(this).data('value');
	        if (self.opts.flag == 'search') {
	            self.$el.find("input").val("");
	            self.$el.find('.js_w-search_list').hide();
	            $.pub('search/getResult', [{
	                isPagination: false,
	                page: 1,
	                search: self.params.search
	            }]);
	        } else {
	            // location.href = "/search?search=" + self.params.search;
	            window.open("/search?search=" + self.params.search)
	        }
	    });
	    // 输入框请求
	    this.$el.find("input").on("keyup",
	        _.debounce(function(event) {
	            var code = event.which || event.keyCode,
	                val = $(this).val();
	            if (!val) {
	                self.$el.find('.js_w-search_list').hide();
	                return;
	            }
	            if (code == 37 || code == 38 || code == 39 || code == 40) return;
	            self.$el.find('.js_w-search_list').show();
	            self.params.search = $(this).val();
	            if (code == 13) {
	                self.$el.find("input").val("");
	                self.$el.find('.js_w-search_list').hide();
	                if (self.$el.find(".w-search-result-value").hasClass("active")) {
	                    self.params.search = self.$el.find(".active").data("value");
	                }
	                if (self.opts.flag == 'search') {
	                    self.$el.find('.js_w-search_list').hide();
	                    $.pub('search/getResult', [{
	                        isPagination: false,
	                        page: 1,
	                        search: self.params.search
	                    }]);
	                } else {
	                    window.open("/search?search=" + self.params.search)
	                }
	            } else {
	                self.getData({
	                    search: self.params.search
	                });
	            }
	        }, 300));
	    this.$el.find("input").on("keydown", function(event) {
	        var $this = $(this);
	        var code = event.which || event.keyCode;
	        if (code == 38) { //上
	            if ($this.next().find(".w-search-result-value").hasClass("active")) {
	                if (!$this.next().find(".w-search-result-value").prev()) {
	                    $this.next().find(".w-search-result-value").first().addClass("active");
	                } else {
	                    $this.next().find(".active").removeClass("active").prev().addClass("active");
	                }
	            } else {
	                $this.next().find(".w-search-result-value").first().addClass("active");
	            }
	        } else if (code == 40) { //下
	            if ($this.next().find(".w-search-result-value").hasClass("active")) {
	
	                if (!$this.next().find(".w-search-result-value").next()) {
	                    $this.next().find(".w-search-result-value").first().addClass("active");
	                } else {
	                    $this.next().find(".active").removeClass("active").next().addClass("active");
	                }
	            } else {
	                $this.next().find(".w-search-result-value").first().addClass("active");
	            }
	        }
	    });
	    $('body').click(function(e) {
	        if ($(e.target).closest("#w-search").length == 0) {
	            self.$el.find('.js_w-search_list').hide();
	        }
	    });
	    return this;
	};
	
	module.exports = Search;
});;
define('widget/header', function(require, exports, module){
	var Search = require("widget/search");
	
	function Header(pageType) {
		// if (window.location.hostname == 'www.zhibobao.com') {
		// 	this.template = _.template(__inline('./header.html'));
		// } else {
		// 	this.template = _.template(__inline('./header_tv.html'));
		// }
	
		this.pageType = pageType;
		// if (pageType == 'index') {
		// 	this.$el = $('<div class="w-header w-header-index"></div>');
		// } else {
		// 	this.$el = $('<div class="w-header"></div>');
		// }
		
		this.init();
	};
	
	Header.prototype.init = function() {
		this.render();
		this.bindEvent();
	};
	Header.prototype.render = function() {
		// this.$el.html(this.template());
	
		// var $head_nav = this.$el.find('.w-header_nav');
	
		// var pathname = location.pathname;
	
		// if (window.location.hostname == 'www.zhibobao.com') {
		// 	if (pathname == '/static/boot/main/main.html' || pathname == '/') {
		// 		$head_nav.find('[data-page="home"]').addClass('active');
		// 	} else if (pathname == '/static/boot/rank/rank.html' || pathname == '/rank') {
		// 		$head_nav.find('[data-page="rank"]').addClass('active');
		// 	} else if (pathname == '/static/boot/platform/platform.html' || pathname == '/platform') {
		// 		$head_nav.find('[data-page="platform"]').addClass('active');
		// 	} else if (pathname == '/static/boot/tool/tool.html' || pathname == '/tool') {
		// 		$head_nav.find('[data-page="tool"]').addClass('active');
		// 	}
		// } else {
		// 	if (pathname == '/static/boot/main/main.html' || pathname == '/data') {
		// 		$head_nav.find('[data-page="home"]').addClass('active');
		// 	} else if (pathname == '/static/boot/rank/rank.html' || pathname == '/rank') {
		// 		$head_nav.find('[data-page="rank"]').addClass('active');
		// 	} else if (pathname == '/static/boot/platform/platform.html' || pathname == '/platform') {
		// 		$head_nav.find('[data-page="platform"]').addClass('active');
		// 	} else if (pathname == '/static/boot/tool/tool.html' || pathname == '/') {
		// 		$head_nav.find('[data-page="tool"]').addClass('active');
		// 	}
		// }
		
		this.$el = $('.w-header');
		if (this.pageType == 'search') {
	
		} else {
			this.search = new Search();
			// this.$el.find('.js-w-header_search').html(this.search.$el);
		}
	
		return this;
	};
	Header.prototype.bindEvent = function() {
		var self = this;
	
		$(document).scroll(function() {
			var h = $(this).scrollTop();
			if (h > 0) {
				self.$el.addClass('w-header-scroll');
			} else {
				self.$el.removeClass('w-header-scroll');
			}
		});
	
		this.$el.find(".w-header_nav_link_warp a").on("click", function() {
			if($(this).attr('target') == '_blank') {
				return;
			}
	
			$(this).parent().addClass("active").siblings().removeClass('active');
			if ($(this).data('page') == "tool") {
				self.$el.parent().addClass('w-header-new');
			} else {
				self.$el.parent().removeClass('w-header-new');
			}
		});
		return this;
	};
	
	Header.prototype.activeNav = function(index) {
		var $list = this.$el.find('.w-header_nav_link_warp');
		$list.removeClass('active');
		$list.eq(index).addClass('active');
	
		if (index === 0) {
			this.$el.addClass('w-header-index');
		} else {
			this.$el.removeClass('w-header-index');
		}
	};
	
	module.exports = Header;
});;
define('widget/footer', function(require, exports, module){
	function Footer() {
	
	    // if( window.location.hostname == 'www.zhibobao.com' ){
	    //     this.template = _.template(__inline('./footer.html'));
	    // }else{
	    //     this.template = _.template(__inline('./footer_tv.html'));
	    // }
	    // this.$el = $('<div class="w-footer"></div>');
	
	    // this.init();
	};
	
	// Footer.prototype.init = function() {
	//     this.render();
	//     this.bindEvent();
	// };
	// Footer.prototype.render = function() {
	//     this.$el.html(this.template());
	
	//     return this;
	// };
	// Footer.prototype.bindEvent = function() {
	//     var self = this;
	
	//     return this;
	// };
	
	module.exports = Footer;
});;
define('widget/lieCharts', function(require, exports, module){
	// 使用该模块的页面需引入echarts
	
	var api = require('common/api');
	
	/**
	 * @param {Number} [company] [平台类型]
	 * @param {String} [indicator] [指标：开播数anchor，礼物价值gift，弹幕数barrage，新增主播new_anchor]
	 * @param {String} [timeType]	[时间类型：5分钟为minute、1小时为hour，今日为today；历史时间单日的为day；历史时间范围的为dayRange；]
	 * @param {Number | String | Array} [timeValue] [对应时间类型的值：5分钟为5；1小时为1；历史单日如2017-08-10；历史范围为“[2017-07-01,2017-07-30]”]
	 */
	// 发送参数
	// type参数：barrage弹幕量，发言人数chatPerson，barrageAvg人均弹幕
	//             gift礼物价值，giftPerson送礼人数，giftAvg人均送礼，
	//             liveTime直播时长，online在线人数
	// dateRange: 7为7日，30为30日,
	// platform: douyu,
	// roomid: 12345
	//
	//
	// {
	//      type：['barrage', 'gift'],
	//      dateRange: 7,
	//      platform: 'douyu',
	//      roomid: 12345
	// }
	function LieCharts(data) {
	    this.data = data.value;
	    switch ( data.type ){
	        case "barrage":
	        case "barrageAvg":
	            this.unit = "条";
	            break;
	        case "chatPerson":
	        case "giftPerson":
	        case "online":
	            this.unit = "人";
	            break;
	        case "liveTime":
	            this.unit = "h";
	            break;
	        case "gift":
	        case "giftAvg":
	            this.unit = "元";
	            break;
	        default:
	            this.unit = "人";
	            break;
	    }
	    this.$el = $('<div class="w-lie-charts"></div>');
	};
	
	LieCharts.prototype.init = function() {
	    var xAxisData = [];
	    var seriesData = [];
	    var self = this;
	    $.each(self.data, function(i, n) {
	        xAxisData.push(i);
	        seriesData.push(Number(n));
	    });
	    var unit  = ZBB.IsBeyond( seriesData );
	    if( unit ){
	        ZBB.dataChange( seriesData );
	        self.unit = "万"+self.unit;
	    }
	    self.render({
	        xAxisData: xAxisData,
	        seriesData: seriesData,
	        unit:this.unit
	    });
	};
	LieCharts.prototype.render = function(chartParams) {
	    echarts.init(this.$el[0]).clear();
	    this.myChart = echarts.init(this.$el[0]);
	
	    this.myChartOption = {
	        backgroundColor: {
	            type: 'pattern',
	            image: ZBB.canvasWaterMark(),
	            repeat: 'repeat'
	        },
	        title: {
	            show: false
	        },
	        tooltip: {
	            trigger: 'axis',
	            axisPointer: { // 坐标轴指示器，坐标轴触发有效
	                type: 'shadow', // 默认为直线，可选为：'line' | 'shadow'
	                shadowStyle: {
	                    color: {
	                        type: 'linear',
	                        x: 0,
	                        y: 0,
	                        x2: 0,
	                        y2: 1,
	                        colorStops: [{
	                            offset: 0,
	                            color: 'rgba(48, 131, 255, 0)' // 0% 处的颜色
	                        }, {
	                            offset: 1,
	                            color: 'rgba(48, 131, 255, 0.1)' // 100% 处的颜色
	                        }],
	                        globalCoord: false // 缺省为 false
	                    }
	                }
	            }
	        },
	        legend: {},
	        toolbox: {
	            show: false
	        },
	        xAxis: [{
	            type: 'category',
	            axisLabel: {
	                textStyle: {
	                    color: '#8492af'
	                },
	            },
	            axisLine: {
	                lineStyle: {
	                    type: 'dotted',
	                    color: '#8492af'
	                }
	            },
	            boundaryGap: false,
	            data: chartParams.xAxisData
	        }],
	        yAxis: [{
	            type: 'value',
	            axisLabel: {
	                textStyle: {
	                    color: '#8492af'
	                },
	                formatter: '{value}' + chartParams.unit
	            },
	            axisLine: {
	                lineStyle: {
	                    type: 'dotted',
	                    color: '#8492af'
	                }
	            },
	            axisTick: {
	                show: false
	            },
	            splitLine: {
	                lineStyle: {
	                    type: 'dotted',
	                    color: '#8492af',
	                    opacity: 0.55
	                }
	            }
	        }],
	        animation:false,
	        // animationDuration:500,
	        series: [{
	            name: '',
	            type: 'line',
	            data: chartParams.seriesData,
	            itemStyle: {
	                normal: {
	                    color: "#6796ff",
	                    areaStyle: {
	                        type: 'default',
	                        color: {
	                            type: 'linear',
	                            x: 0,
	                            y: 0,
	                            x2: 0,
	                            y2: 1,
	                            colorStops: [{
	                                offset: 0,
	                                color: 'rgba(48, 131, 255, 1)' // 0% 处的颜色
	                            }, {
	                                offset: 1,
	                                color: 'rgba(48, 131, 255, 0.2)' // 100% 处的颜色
	                            }],
	                            globalCoord: false // 缺省为 false
	                        }
	
	                    },
	                    lineStyle: {
	                        color: "#6796ff"
	                    }
	                }
	            }
	
	        }]
	    };
	    this.myChart.setOption(this.myChartOption);
	
	    return this;
	};
	
	module.exports = LieCharts;
});;
define('widget/liveDensity', function(require, exports, module){
	var api = require('common/api');
	
	var DayList = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
	
	// 直播密度
	// 返回最近30天的直播
	// day表示周1-周日的，该日有过直播就加1；
	// time表示一天24小时的，1表示0-1点，24表示23-24点，在该范围内有在直播的就加1
	function LiveDensity( opts ) {
	
	    this.opts = opts || {};
	    this.params = {
	        platform:this.opts.platform,
	        roomId:this.opts.roomId
	    };
	
	    this.template = _.template("<div class=\"w-live-density-div fl\">\r\n    <p class=\"w-live-density-div-title\">\r\n        周直播频次\r\n        <span class=\"w-live-density_tips tooltips-top\" data-tooltips=\"主播近30天的周直播频次，颜色越深表示主播直播的几率越高\"></span>\r\n    </p>\r\n    <div class=\"w-live-density-content w-live-density-week clearfix\">\r\n        <% _.each(data.dayDensity, function(item, index) { %>\r\n        <span title=\"\" class=\"tooltips-top <%= item.week_level %>\" data-tooltips = \"<%= ZBB.getAnchorWeekInfo( index , item.value ) %>\"></span>\r\n        <% }) %>\r\n    </div>\r\n    <div class=\"w-live-density-content w-live-density-week w-live-density-desc clearfix\">\r\n        <% _.each(data.dayList, function(item, index) { %>\r\n        <span><%= item %></span>\r\n        <% }) %>\r\n    </div>\r\n</div>\r\n<div class=\"w-live-density-div fl\">\r\n    <p class=\"w-live-density-div-title\">\r\n        24小时直播频次\r\n        <span class=\"w-live-density_tips tooltips-top\" data-tooltips=\"主播近30天的24小时直播频次，颜色越深表示主播直播的几率越高\"></span>\r\n    </p>\r\n    <div class=\"w-live-density-content w-live-density-hour clearfix\">\r\n        <% _.each(data.timeDensity, function(item, index) { %>\r\n        <span title=\"\" class=\"tooltips-top <%= item.hour_level %>\" data-tooltips = \"<%= ZBB.getAnchorHourInfo( index , item.value ) %>\"></span>\r\n        <% }) %>\r\n        <i class=\"w-live-density-div-fl w-live-density-div-fl-0\">00:00</i>\r\n        <i class=\"w-live-density-div-fl w-live-density-div-fl-6\">06:00</i>\r\n        <i class=\"w-live-density-div-fl w-live-density-div-fl-12\">12:00</i>\r\n        <i class=\"w-live-density-div-fl w-live-density-div-fl-18\">18:00</i>\r\n        <i class=\"w-live-density-div-fl w-live-density-div-fl-24\">24:00</i>\r\n    </div>\r\n</div>");
	    this.$el = $('<div class="w-live-density clearfix"></div>');
	    this.getData();
	};
	
	LiveDensity.prototype.init = function() {
	    var self = this;
	    var dayDensity = [];
	    var timeDensity = [];
	    $.each(self.data.day, function(i, n) {
	        dayDensity.push({
	            name: i,
	            value: Number(n),
	            week_level: self.getWeekColor(n)
	        });
	    });
	    $.each(self.data.time, function(i, n) {
	        timeDensity.push({
	            name: i,
	            value: Number(n),
	            hour_level: self.getHourColor(n)
	        });
	    });
	    self.render({
	        dayList: DayList,
	        dayDensity: dayDensity,
	        timeDensity: timeDensity
	    });
	};
	LiveDensity.prototype.render = function(data) {
	    this.$el.html(this.template({
	        'data': data
	    }));
	    return this;
	};
	
	LiveDensity.prototype.getData = function(data) {
	    $.extend( this.params , data );
	    var self = this;
	    var path = "anchor/live";
	
	    api.get(path, this.params).done(function(data) {
	        if ( data.code == 0 ) {
	            self.data = data.data.live;
	            self.init()
	        }
	    })
	};
	
	LiveDensity.prototype.getWeekColor = function(val) {
	    var week_level ="";
	    switch  ( val ){
	        case 0 :
	            week_level = "week_level1";
	            break;
	        case 1 :
	            week_level = "week_level2";
	            break;
	        case 2 :
	            week_level = "week_level3";
	            break;
	        case 3 :
	            week_level = "week_level4";
	            break;
	        case 4 :
	            week_level = "week_level5";
	            break;
	        case 5 :
	            week_level = "week_level6";
	            break;
	        default:
	            week_level = "week_level6";
	    }
	    return week_level;
	};
	
	LiveDensity.prototype.getHourColor = function(val) {
	    var hour_level ="";
	    switch  ( true ){
	        case val == 0 :
	            hour_level = "hour_level1";
	            break;
	        case val<=5:
	            hour_level = "hour_level2";
	            break;
	        case val<=10 :
	            hour_level = "hour_level3";
	            break;
	        case val<=18 :
	            hour_level = "hour_level4";
	            break;
	        case val<=24 :
	            hour_level = "hour_level5";
	            break;
	        case val<=28 :
	            hour_level = "hour_level6";
	            break;
	        case val<=30 :
	            hour_level = "hour_level7";
	            break;
	        case val<=31 :
	            hour_level = "hour_level8";
	            break;
	        default:
	            return "hour_level8";
	    }
	    return  hour_level;
	};
	
	module.exports = LiveDensity;
});;
define('widget/anchorRank', function(require, exports, module){
	
	var api = require('common/api');
	// 直播密度
	// 返回最近30天的直播
	// day表示周1-周日的，该日有过直播就加1；
	// time表示一天24小时的，1表示0-1点，24表示23-24点，在该范围内有在直播的就加1
	function anchorRank( data ) {
		this.template = _.template("<p class=\"anchor-rank-title\">最近一个月主播排名</p>\r\n<section class=\"anchor-rank-content text-able-select\">\r\n    <div class=\"add-after-content fl\">\r\n        <p class=\"anchor-rank-content-title\"><span class=\"gift-bg\">礼物</span></p>\r\n\r\n        <div class=\"fl\">\r\n            <p class=\"anchor-rank-content-value\"><%= anchorRank.gift.all %></p>\r\n            <p class=\"anchor-rank-content-platform\">全网排名\r\n                <span class=\"anchor-rank_tips tooltips-top\" data-tooltips=\"全网排名：以最近30天的礼物数据进行计算，得出全部直播平台中，主播所在分类的排名\"></span>\r\n            </p>\r\n        </div>\r\n        <div class=\"fl\">\r\n            <p class=\"anchor-rank-content-value\"><%= anchorRank.gift.platform %></p>\r\n            <p class=\"anchor-rank-content-platform\"><%= anchorRank.platformName %>排名\r\n                <span class=\"anchor-rank_tips tooltips-top\" data-tooltips=\"<%= anchorRank.platformName %>排名：以最近30天的礼物数据进行计算，得出主播所在的直播平台所在分类的排名\"></span>\r\n            </p>\r\n        </div>\r\n    </div>\r\n    <div class=\"fr\">\r\n        <p class=\"anchor-rank-content-title\"><span class=\"barrage-bg\">弹幕</span></p>\r\n        <div class=\"fl\">\r\n            <p class=\"anchor-rank-content-value\"><%= anchorRank.barrage.all %></p>\r\n            <p class=\"anchor-rank-content-platform\">全网排名\r\n                <span class=\"anchor-rank_tips tooltips-top\" data-tooltips=\"全网排名：以最近30天的弹幕数据进行计算，得出全部直播平台中，主播所在分类的排名\"></span>\r\n            </p>\r\n        </div>\r\n        <div class=\"fl\">\r\n            <p class=\"anchor-rank-content-value\"><%= anchorRank.barrage.platform %></p>\r\n            <p class=\"anchor-rank-content-platform\"><%= anchorRank.platformName %>排名\r\n                <span class=\"anchor-rank_tips tooltips-top\" data-tooltips=\"<%= anchorRank.platformName %>排名：以最近30天的弹幕数据进行计算，得出主播所在的直播平台所在分类的排名\"></span>\r\n            </p>\r\n        </div>\r\n    </div>\r\n</section>");
	
	    this.data =data;
		this.$el = $('<div></div>');
	};
	
	anchorRank.prototype.init = function() {
	    var self = this;
	    this.render({
	        data:self.data
	    })
	};
	anchorRank.prototype.render = function(data) {
		this.$el.html( this.template({
	        'anchorRank':data.data
		}));
		return this;
	};
	module.exports = anchorRank;
});;
define('widget/anchorInfo', function(require, exports, module){
	
	var api = require('common/api');
	// 直播密度
	// 返回最近30天的直播
	// day表示周1-周日的，该日有过直播就加1；
	// time表示一天24小时的，1表示0-1点，24表示23-24点，在该范围内有在直播的就加1
	function anchorInfo( data ) {
		this.template = _.template("<img class=\"w-anchor-avatar\" src=\"<%= ZBB.parseAvatar(anchorInfo.avatar) %>\" alt=\"\">\r\n<p class=\"anchor-name text-able-select\"><%= anchorInfo.nickname %></p>\r\n<div>\r\n\t<span class=\"anchor-platform\"><%= ZBB.platformName[anchorInfo.platform] %></span>\r\n\t<% if(anchorInfo.cateName) { %>\r\n\t<span class=\"anchor-category\"><%= anchorInfo.cateName %></span>\r\n\t<% } %>\r\n</div>\r\n<a class=\"js_anchor_enter\" href=\"<%= anchorInfo.url %>\" target=\"_blank\">进入直播间</a>");
	
	    this.data =data;
		this.$el = $('<div class="w-anchor-info"></div>');
	
	};
	
	anchorInfo.prototype.init = function() {
	    var self = this;
	    this.render(self.data);
	};
	anchorInfo.prototype.render = function(data) {
		this.$el.html( this.template({
	        'anchorInfo':data
		}));
		return this;
	};
	module.exports = anchorInfo;
});;
define(function(require) {
    // 302
    var MOBILE_UA_REGEXP = /(iPhone|iPod|Android|ios|iOS|iPad|Backerry|WebOS|Symbian|Windows Phone|Phone|Prerender|MicroMessenger)/i;
    if (MOBILE_UA_REGEXP.test(navigator.userAgent)) {
        var urlParams = ZBB.urlRequestParams();
        if (urlParams['isPc']) {

        } else {
            var pathname = location.pathname;
            var search = location.search;
            window.location.replace(ZBB.mDomain + pathname + search);
            return;
        }
    }

    var api = require('common/api');
    var Header = require('widget/header');
    var Footer = require('widget/footer');
    var LieCharts = require('widget/lieCharts');
    var LiveDensity = require('widget/liveDensity');
    var AnchorRank = require('widget/anchorRank');
    var AnchorInfo = require('widget/anchorInfo');

    var $body = $('body');
    var $action_line_charts = $body.find('.js_w_action_line_charts');
    var $gift_line_charts = $body.find('.js_w_gift_line_charts');
    var $time_line_charts = $body.find('.js_w_time_line_charts');
    var $people_line_charts = $body.find('.js_w_people_line_charts');
    var $action_list = $body.find('.js_action_list');
    var $gift_list = $body.find('.js_gift_list');
    var $liveDensity = $body.find('.js_w_liveDensity');
    var $anchorRank = $body.find('.js_w_anchorRank');

    var oPage = {
        init: function() {
            var self = this;
            var urlRequestParams = ZBB.urlRequestParams();
            if (urlRequestParams['roomId']) {
                self.roomId = urlRequestParams['roomId'];
            }
            if (urlRequestParams['platform']) {
                self.platform = urlRequestParams['platform'];
            }
            this.params = {
                offset: 7,
                platform: self.platform,
                roomId: self.roomId
            };
            this.option = {
                type: "",
                key: ""
            }
            this.dataObject = {}
            this.getData(this.option);
            this.render();
            this.bindEvent();
        },
        render: function(data) {
            var header = new Header();

            var liveDensity = new LiveDensity(this.params);
            $liveDensity.append(liveDensity.$el);

        },
        renderLieCharts: function(obj) {
            var self = this;
            $.each(obj.data, function(key, val) {
                switch (key) {
                    case 'barrage':
                        self.action_line_charts = new LieCharts({
                            value: val,
                            type: self.option.key || "barrage"

                        });
                        $action_line_charts.html(self.action_line_charts.$el);
                        self.action_line_charts.init();
                        break;
                    case 'gift':
                        self.gift_line_charts = new LieCharts({
                            value: val,
                            type: self.option.key || "gift"

                        });
                        $gift_line_charts.html(self.gift_line_charts.$el);
                        self.gift_line_charts.init();
                        break;
                    case 'liveTime':
                        $.each(val, function(index, item) {
                            val[index] = Number(item).toFixed(1)
                        });
                        self.time_line_charts = new LieCharts({
                            value: val,
                            type: "liveTime"

                        });
                        $time_line_charts.html(self.time_line_charts.$el);
                        self.time_line_charts.init();
                        break;
                    case 'online':
                        self.people_line_charts = new LieCharts({
                            value: val,
                            type: "online"

                        });
                        $people_line_charts.html(self.people_line_charts.$el);
                        self.people_line_charts.init();
                        break;
                    default:
                        break
                }
            });
        },
        bindEvent: function() {
            var self = this;
            //用户弹幕相关
            $action_list.on('click', 'li', function() {
                var $this = $(this);
                var action = $this.data('action');
                if (!$this.hasClass('active')) {
                    $this.addClass('active').siblings().removeClass('active');
                    self.option = {
                        type: "barrage",
                        key: $this.data('action')
                    };
                    self.getData(self.option);

                    if( action != 'barrage' ){
                        $(".all_barrage_week,.all_barrage_month").css('display','none');
                    }else{
                        if( self.params.offset==7 ){
                            $(".all_barrage_week").css('display','block');
                        }else{
                            $(".all_barrage_month").css('display','block');
                        }
                    }

                }
            });

            //用户礼物相关
            $gift_list.on('click', 'li', function() {
                var $this = $(this);
                var gift = $this.data('gift');
                if (!$this.hasClass('active')) {
                    $this.addClass('active').siblings().removeClass('active');
                    self.option = {
                        type: "gift",
                        key: $this.data('gift')
                    };
                    self.getData(self.option);

                    if( gift != 'gift' ){
                        $(".all_gift_week,.all_gift_month").css('display','none');
                    }else{
                        if( self.params.offset==7 ){
                            $(".all_gift_week").css('display','block');
                        }else{
                            $(".all_gift_month").css('display','block');
                        }
                    }
                }
            });

            //时间段选择
            $(".anchor-title-time").on('click', 'span', function() {
                var $this = $(this);
                if (!$this.hasClass('active')) {
                    $this.addClass('active').siblings().removeClass('active');
                    self.params.offset = $this.data('time');
                    self.getData({});
                    if (!self.dataObject[self.params.offset]) {
                        return;
                    }
                    if( $this.data('type') == 'week' ){
                        $(".all_live_time_week").css('display','block');
                        $(".all_live_time_month").css('display','none');
                        if( $(".js_action_list").find('.active').data('action')=='barrage' ){
                            $(".all_barrage_week").css('display','block');
                            $(".all_barrage_month").css('display','none');
                        }
                        if( $(".js_gift_list").find('.active').data('gift')=='gift' ){
                            $(".all_gift_week").css('display','block');
                            $(".all_gift_month").css('display','none');
                        }
                    }else{
                        $(".all_live_time_week").css('display','none');
                        $(".all_live_time_month").css('display','block');
                        if( $(".js_action_list").find('.active').data('action')=='barrage' ){
                            $(".all_barrage_week").css('display','none');
                            $(".all_barrage_month").css('display','block');
                        }
                        if( $(".js_gift_list").find('.active').data('gift')=='gift' ){
                            $(".all_gift_week").css('display','none');
                            $(".all_gift_month").css('display','block');
                        }
                    }
                }
            })
        },
        getData: function(option) {
            var self = this;
            var path = 'anchor/trends';

            if (this.dataObject[self.params.offset]) {

                if (option.type == 'gift') {
                    self.gift_line_charts = new LieCharts({
                        value: this.dataObject[self.params.offset][option.key],
                        type: option.key
                    });
                    $gift_line_charts.html(self.gift_line_charts.$el);
                    self.gift_line_charts.init();
                } else if (option.type == 'barrage') {
                    self.action_line_charts = new LieCharts({
                        value: this.dataObject[self.params.offset][option.key],
                        type: option.key
                    });
                    $action_line_charts.html(self.action_line_charts.$el);
                    self.action_line_charts.init();
                } else {
                    self.renderLieCharts({
                        data: this.dataObject[self.params.offset]
                    });
                }
                return;
            }

            api.get(path, this.params).done(function(data) {
                if (data.code == 0) {
                    if (option.type == 'gift') {
                        self.gift_line_charts = new LieCharts({
                            value: data.data.info[option.key],
                            type: option.key
                        });
                        $gift_line_charts.html(self.gift_line_charts.$el);
                        self.gift_line_charts.init();
                    } else if (option.type == 'barrage') {
                        self.action_line_charts = new LieCharts({
                            value: data.data.info[option.key],
                            type: option.key
                        });
                        $action_line_charts.html(self.action_line_charts.$el);
                        self.action_line_charts.init();
                    } else {
                        var barrage_all = 0,gift_all = 0,liveTime_all=0;
                        $.each(data.data.info,function (item,obj) {

                            if( item == 'barrage' ){
                                $.each(obj,function (index,num) {
                                    barrage_all += Number( num );
                                })
                            }

                            if( item == 'gift' ){
                                $.each(obj,function (index,num) {
                                    gift_all += Number( num );
                                })
                            }

                            if( item == 'liveTime' ){
                                $.each(obj,function (index,num) {
                                    data.data.info[item][index] = Number( num / 3600 );
                                    liveTime_all += Number( num / 3600 );
                                })
                            }

                        });
                        if( self.params.offset == 7 ){
                            $(".all_barrage_week").css('display','block').find('i').html( barrage_all.toLocaleString() );
                            $(".all_gift_week").css('display','block').find('i').html( gift_all.toLocaleString() );
                            $(".all_live_time_week").css('display','block').find('i').html( (liveTime_all).toFixed(1) );
                        }else{
                            $(".all_barrage_week").css('display','none');
                            $(".all_gift_week").css('display','none');
                            $(".all_live_time_week").css('display','none');
                            $(".all_barrage_month").css('display','block').find('i').html( barrage_all.toLocaleString() );
                            $(".all_gift_month").css('display','block').find('i').html( gift_all.toLocaleString() );
                            $(".all_live_time_month").css('display','block').find('i').html( (liveTime_all).toFixed(1) );
                        }
                        self.renderLieCharts({
                            data: data.data.info
                        });
                    }
                    self.dataObject[self.params.offset] = data.data.info;
                }
            });
        }
    };

    oPage.init();
});