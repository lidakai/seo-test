define('common/apiExpire', function(require, exports, module){
	function localSign() {
		var key = 'GapV#&2%b';
		var timestamp = new Date().getTime();
		var val = md5(timestamp + key);
		return {
			'sign': val,
			'timestamp': timestamp
		};
	}
	
	module.exports = localSign;
});;
define('common/api', function(require, exports, module){
	var LocalSign = require('common/apiExpire');
	
	var REQUEST_TIMEOUT = 20000;
	
	var API_PREFIX = '/api/';
	
	
	function getApiUrl(path) {
		if (/\.\.*\//.test(path) || /http/.test(path)) {
			return path;
		} else {
			return API_PREFIX + path;
		}
	    console.log(path);
	}
	var API = {
		get: function(path, data, callback) {
			var localSign = LocalSign();
			data = $.extend({}, data, {
				'_timestamp': localSign.timestamp,
				'source': 0
			});
			var $defer = $.Deferred();
	
			$.ajax({
				type: 'get',
				url: getApiUrl(path),
				data: data,
				dataType: 'json',
				headers: {
					'T-code': localSign.sign
				},
				crossDomain: true,
				xhrFields: {
					withCredentials: true
				},
				timeout: REQUEST_TIMEOUT,
				success: function(data) {
					typeof(callback) == 'function' && callback(data);
	                if (data) {
						$defer.resolve(data);
					} else {
						$defer.reject();
					}
				},
				error: function(xhr, state) {
	                console.log(state);
					typeof(callback) == 'function' && callback(state);
					$defer.reject(state);
				}
			});
			return $defer;
		},
		post: function(path, data, callback) {
			var timestamp = LocalSign();
			data = $.extend({}, data, {
				'_timestamp': localSign.timestamp,
				'source': 0
			});
			var $defer = $.Deferred();
	
			$.ajax({
				type: 'post',
				url: getApiUrl(path),
				data: data,
				dataType: 'json',
				headers: {
					'T-code': localSign.sign
				},
				crossDomain: true,
				xhrFields: {
					withCredentials: true
				},
				timeout: REQUEST_TIMEOUT,
				success: function(data) {
					typeof(callback) == 'function' && callback(data);
	
					if (data) {
						$defer.resolve(data);
					} else {
						$defer.reject();
					}
				},
				error: function(xhr, state) {
					typeof(callback) == 'function' && callback(state);
					$defer.reject(state);
				}
			});
	
			return $defer;
		}
	};
	
	module.exports = API;
});;
define('widget/search', function(require, exports, module){
	var api = require('common/api');
	
	/**
	 * @param {String} [searchVal] [搜索关键词]
	 */
	function Search(opts) {
	    this.opts = opts || {};
	    
	    // this.template = _.template(__inline('./search.html'));
	    this.templateSearchList = _.template("<% if( data.length ) {%>\r\n<ul class=\"w-search-result\">\r\n    <% _.each(data, function(obj, index) { %>\r\n    <li class=\"w-search-result-value\" data-value=\"<%= obj.item %>\">\r\n    \t<% if( obj.plat ) { %>\r\n    \t<img src=\"<%= ZBB.platformDefaultAvatar[obj.plat] %>\">\r\n    \t<% } %>\r\n    \t<a href=\"javascript:;\"><%= obj.replaceItem %></a>\r\n    </li>\r\n    <% }) %>\r\n</ul>\r\n<% } %>");
	
	    // this.$el = $('<div class="w-search" id="w-search"></div>');
	    if (this.opts.$dom && this.opts.$dom.length) {
	        this.$el = this.opts.$dom.find('.w-search');
	    } else {
	        this.$el = $('.w-search');
	    }
	    this.params = {
	        'isPagination': false,
	        search: this.opts.search,
	        size: 10
	    };
	    this.init();
	}
	Search.prototype.render = function() {
	    // var self = this;
	    // this.$el.html(self.template());
	};
	Search.prototype.init = function() {
	    this.render();
	    this.bindEvent();
	};
	Search.prototype.getData = function(data) {
	    $.extend(this.params, data);
	    var self = this,
	        path = 'search';
	    api.get(path, this.params).done(function(data) {
	        if (data.code == 0) {
	            var arr = [];
	            $.each(data.data.list, function(index, item) {
	                // 同时替换大小写
	                var arrMatch = item.nickname.match(eval('/' + self.params.search + '/gi'));
	                var replaceItem = item.nickname;
	                $.each(arrMatch, function(i, n) {
	                    replaceItem = replaceItem.replace(eval('/' + n + '/g'), '<i class="replaceItem">' + n + '</i>');
	                });
	
	                arr.push({
	                    item: item.nickname,
	                    replaceItem: replaceItem,
	                    plat: item.plat
	                });
	            });
	            self.$el.find('.js_w-search_list').html(self.templateSearchList({
	                'data': arr
	            }));
	        }
	    });
	};
	
	Search.prototype.bindEvent = function() {
	    var self = this;
	    //搜索点击
	    this.$el.find(".w-icon_search").on("click", function() {
	        self.params.search = $(this).next().val();
	        if (!self.params.search) return;
	        self.$el.find("input").val("");
	        if (self.opts.flag == 'search') {
	
	            self.$el.find('.js_w-search_list').hide();
	            $.pub('search/getResult', [{
	                isPagination: false,
	                page: 1,
	                search: self.params.search
	            }]);
	        } else {
	            window.open("/search?search=" + self.params.search)
	        }
	
	    });
	
	    //搜索结果点击
	    self.$el.find('.js_w-search_list').on("click", ".w-search-result-value", function() {
	        self.params.search = $(this).data('value');
	        if (self.opts.flag == 'search') {
	            self.$el.find("input").val("");
	            self.$el.find('.js_w-search_list').hide();
	            $.pub('search/getResult', [{
	                isPagination: false,
	                page: 1,
	                search: self.params.search
	            }]);
	        } else {
	            // location.href = "/search?search=" + self.params.search;
	            window.open("/search?search=" + self.params.search)
	        }
	    });
	    // 输入框请求
	    this.$el.find("input").on("keyup",
	        _.debounce(function(event) {
	            var code = event.which || event.keyCode,
	                val = $(this).val();
	            if (!val) {
	                self.$el.find('.js_w-search_list').hide();
	                return;
	            }
	            if (code == 37 || code == 38 || code == 39 || code == 40) return;
	            self.$el.find('.js_w-search_list').show();
	            self.params.search = $(this).val();
	            if (code == 13) {
	                self.$el.find("input").val("");
	                self.$el.find('.js_w-search_list').hide();
	                if (self.$el.find(".w-search-result-value").hasClass("active")) {
	                    self.params.search = self.$el.find(".active").data("value");
	                }
	                if (self.opts.flag == 'search') {
	                    self.$el.find('.js_w-search_list').hide();
	                    $.pub('search/getResult', [{
	                        isPagination: false,
	                        page: 1,
	                        search: self.params.search
	                    }]);
	                } else {
	                    window.open("/search?search=" + self.params.search)
	                }
	            } else {
	                self.getData({
	                    search: self.params.search
	                });
	            }
	        }, 300));
	    this.$el.find("input").on("keydown", function(event) {
	        var $this = $(this);
	        var code = event.which || event.keyCode;
	        if (code == 38) { //上
	            if ($this.next().find(".w-search-result-value").hasClass("active")) {
	                if (!$this.next().find(".w-search-result-value").prev()) {
	                    $this.next().find(".w-search-result-value").first().addClass("active");
	                } else {
	                    $this.next().find(".active").removeClass("active").prev().addClass("active");
	                }
	            } else {
	                $this.next().find(".w-search-result-value").first().addClass("active");
	            }
	        } else if (code == 40) { //下
	            if ($this.next().find(".w-search-result-value").hasClass("active")) {
	
	                if (!$this.next().find(".w-search-result-value").next()) {
	                    $this.next().find(".w-search-result-value").first().addClass("active");
	                } else {
	                    $this.next().find(".active").removeClass("active").next().addClass("active");
	                }
	            } else {
	                $this.next().find(".w-search-result-value").first().addClass("active");
	            }
	        }
	    });
	    $('body').click(function(e) {
	        if ($(e.target).closest("#w-search").length == 0) {
	            self.$el.find('.js_w-search_list').hide();
	        }
	    });
	    return this;
	};
	
	module.exports = Search;
});;
define('widget/header', function(require, exports, module){
	var Search = require("widget/search");
	
	function Header(pageType) {
		// if (window.location.hostname == 'www.zhibobao.com') {
		// 	this.template = _.template(__inline('./header.html'));
		// } else {
		// 	this.template = _.template(__inline('./header_tv.html'));
		// }
	
		this.pageType = pageType;
		// if (pageType == 'index') {
		// 	this.$el = $('<div class="w-header w-header-index"></div>');
		// } else {
		// 	this.$el = $('<div class="w-header"></div>');
		// }
		
		this.init();
	};
	
	Header.prototype.init = function() {
		this.render();
		this.bindEvent();
	};
	Header.prototype.render = function() {
		// this.$el.html(this.template());
	
		// var $head_nav = this.$el.find('.w-header_nav');
	
		// var pathname = location.pathname;
	
		// if (window.location.hostname == 'www.zhibobao.com') {
		// 	if (pathname == '/static/boot/main/main.html' || pathname == '/') {
		// 		$head_nav.find('[data-page="home"]').addClass('active');
		// 	} else if (pathname == '/static/boot/rank/rank.html' || pathname == '/rank') {
		// 		$head_nav.find('[data-page="rank"]').addClass('active');
		// 	} else if (pathname == '/static/boot/platform/platform.html' || pathname == '/platform') {
		// 		$head_nav.find('[data-page="platform"]').addClass('active');
		// 	} else if (pathname == '/static/boot/tool/tool.html' || pathname == '/tool') {
		// 		$head_nav.find('[data-page="tool"]').addClass('active');
		// 	}
		// } else {
		// 	if (pathname == '/static/boot/main/main.html' || pathname == '/data') {
		// 		$head_nav.find('[data-page="home"]').addClass('active');
		// 	} else if (pathname == '/static/boot/rank/rank.html' || pathname == '/rank') {
		// 		$head_nav.find('[data-page="rank"]').addClass('active');
		// 	} else if (pathname == '/static/boot/platform/platform.html' || pathname == '/platform') {
		// 		$head_nav.find('[data-page="platform"]').addClass('active');
		// 	} else if (pathname == '/static/boot/tool/tool.html' || pathname == '/') {
		// 		$head_nav.find('[data-page="tool"]').addClass('active');
		// 	}
		// }
		
		this.$el = $('.w-header');
		if (this.pageType == 'search') {
	
		} else {
			this.search = new Search();
			// this.$el.find('.js-w-header_search').html(this.search.$el);
		}
	
		return this;
	};
	Header.prototype.bindEvent = function() {
		var self = this;
	
		$(document).scroll(function() {
			var h = $(this).scrollTop();
			if (h > 0) {
				self.$el.addClass('w-header-scroll');
			} else {
				self.$el.removeClass('w-header-scroll');
			}
		});
	
		this.$el.find(".w-header_nav_link_warp a").on("click", function() {
			if($(this).attr('target') == '_blank') {
				return;
			}
	
			$(this).parent().addClass("active").siblings().removeClass('active');
			if ($(this).data('page') == "tool") {
				self.$el.parent().addClass('w-header-new');
			} else {
				self.$el.parent().removeClass('w-header-new');
			}
		});
		return this;
	};
	
	Header.prototype.activeNav = function(index) {
		var $list = this.$el.find('.w-header_nav_link_warp');
		$list.removeClass('active');
		$list.eq(index).addClass('active');
	
		if (index === 0) {
			this.$el.addClass('w-header-index');
		} else {
			this.$el.removeClass('w-header-index');
		}
	};
	
	module.exports = Header;
});;
define('widget/footer', function(require, exports, module){
	function Footer() {
	
	    // if( window.location.hostname == 'www.zhibobao.com' ){
	    //     this.template = _.template(__inline('./footer.html'));
	    // }else{
	    //     this.template = _.template(__inline('./footer_tv.html'));
	    // }
	    // this.$el = $('<div class="w-footer"></div>');
	
	    // this.init();
	};
	
	// Footer.prototype.init = function() {
	//     this.render();
	//     this.bindEvent();
	// };
	// Footer.prototype.render = function() {
	//     this.$el.html(this.template());
	
	//     return this;
	// };
	// Footer.prototype.bindEvent = function() {
	//     var self = this;
	
	//     return this;
	// };
	
	module.exports = Footer;
});;
define('widget/resultList', function(require, exports, module){
	var api = require('common/api');
	
	function ResultList(opts) {
	    this.template = _.template("<div class=\"w-result-list_col w-result-list_col_1\">\r\n    <p><label class=\"text-able-select js_gift_value\"><%= data.gift_value %></label><span class=\"w-result-list_unit\">元</span></p>\r\n    <p class=\"w-result-list_col_title\">礼物收入</p>\r\n</div>\r\n<div class=\"w-result-list_col w-result-list_col_2\">\r\n    <p><label class=\"text-able-select js_barrage_value\"><%= data.barrage_value %></label><span class=\"w-result-list_unit\">条</span></p>\r\n    <p class=\"w-result-list_col_title\">弹幕量</p>\r\n</div>\r\n<div class=\"w-result-list_col w-result-list_col_3\">\r\n    <p><label class=\"text-able-select js_anchor\"><%= data.anchor %></label><span class=\"w-result-list_unit\">人</span></p>\r\n    <p class=\"w-result-list_col_title\">开播数</p>\r\n</div>\r\n<div class=\"w-result-list_col w-result-list_col_4\">\r\n    <p><label class=\"text-able-select js_new_anchor\"><%= data.new_anchor %></label><span class=\"w-result-list_unit\">人</span></p>\r\n    <p class=\"w-result-list_col_title\">新增主播</p>\r\n</div>");
	    this.opts = opts || {};
	    this.isAnimate = this.opts.anim || false;
	    this.isFirstRender = true;
	    this.params = {
	        category: this.opts.category,
	        platform: this.opts.platform
	    };
	
	    if (this.opts.pageType == 'index') {
	        this.$el = $('<div class="w-result-list w-result-list-big"></div>');
	    } else {
	        this.$el = $('<div class="w-result-list"></div>');
	    }
	    this.getData();
	}
	
	ResultList.prototype.render = function(data) {
	    if (this.isAnimate) {
	        if (this.isFirstRender) {
	            this.$el.html(this.template({
	                'data': {}
	            }));
	        }
	
	        this.numAnimStart(data.data);
	    } else {
	        for (var key in data.data) {
	            data.data[key] = Number(data.data[key]).toLocaleString();
	        }
	        this.$el.html(this.template({
	            'data': data.data
	        }));
	    }
	
	    return this;
	};
	ResultList.prototype.numAnimStart = function(data) {
	    var options = {
	        useEasing: false,
	        useGrouping: true,
	        separator: ',',
	        decimal: '.'
	    };
	
	    var per = 24 * 60;
	    var timeDis = 3; // 3分钟请求间隔
	    var delayDetect = 1; // 延迟1秒钟执行
	
	    if (this.isFirstRender) {
	        var self = this;
	
	        var anim_gift_value = new CountUp(this.$el.find('.js_gift_value')[0], 0, parseInt(Number(data.gift_value) * (per - timeDis) / per), 0, delayDetect, options);
	        anim_gift_value.start();
	        setTimeout(function() {
	            anim_gift_value = new CountUp(self.$el.find('.js_gift_value')[0], parseInt(Number(data.gift_value) * (per - timeDis) / per), Number(data.gift_value), 0, timeDis * 60 - delayDetect, options);
	            anim_gift_value.start();
	        }, delayDetect * 1000);
	
	        var anim_barrage_value = new CountUp(this.$el.find('.js_barrage_value')[0], 0, parseInt(Number(data.barrage_value) * (per - timeDis) / per), 0, delayDetect, options);
	        anim_barrage_value.start();
	        setTimeout(function() {
	            anim_barrage_value = new CountUp(self.$el.find('.js_barrage_value')[0], parseInt(Number(data.barrage_value) * (per - timeDis) / per), Number(data.barrage_value), 0, timeDis * 60 - delayDetect, options);
	            anim_barrage_value.start();
	        }, delayDetect * 1000);
	
	        var anim_anchor = new CountUp(this.$el.find('.js_anchor')[0], 0, parseInt(Number(data.anchor) * (per - timeDis) / per), 0, delayDetect, options);
	        anim_anchor.start();
	        setTimeout(function() {
	            anim_anchor = new CountUp(self.$el.find('.js_anchor')[0], parseInt(Number(data.anchor) * (per - timeDis) / per), Number(data.anchor), 0, timeDis * 60 - delayDetect, options);
	            anim_anchor.start();
	        }, delayDetect * 1000);
	
	        var anim_new_anchor = new CountUp(this.$el.find('.js_new_anchor')[0], 0, parseInt(Number(data.new_anchor) * (per - timeDis) / per), 0, delayDetect, options);
	        anim_new_anchor.start();
	        setTimeout(function() {
	            anim_new_anchor = new CountUp(self.$el.find('.js_new_anchor')[0], parseInt(Number(data.new_anchor) * (per - timeDis) / per), Number(data.new_anchor), 0, timeDis * 60 - delayDetect, options);
	            anim_new_anchor.start();
	        }, delayDetect * 1000);
	
	        this.isFirstRender = false;
	    } else {
	        if (Number(this.lastData.gift_value) < Number(data.gift_value)) {
	            if (!this.anim_gift_value) {
	                this.anim_gift_value = new CountUp(this.$el.find('.js_gift_value')[0], Number(this.lastData.gift_value), Number(data.gift_value), 0, timeDis * 60, options);
	                this.anim_gift_value.start();
	            } else {
	                this.anim_gift_value.update(Number(data.gift_value));
	            }
	        }
	
	        if (Number(this.lastData.barrage_value) < Number(data.barrage_value)) {
	            if (!this.anim_barrage_value) {
	                this.anim_barrage_value = new CountUp(this.$el.find('.js_barrage_value')[0], Number(this.lastData.barrage_value), Number(data.barrage_value), 0, timeDis * 60, options);
	                this.anim_barrage_value.start();
	            } else {
	                this.anim_barrage_value.update(Number(data.barrage_value));
	            }
	        }
	
	        if (Number(this.lastData.anchor) < Number(data.anchor)) {
	            if (!this.anim_anchor) {
	                this.anim_anchor = new CountUp(this.$el.find('.js_anchor')[0], Number(this.lastData.anchor), Number(data.anchor), 0, timeDis * 60, options);
	                this.anim_anchor.start();
	            } else {
	                this.anim_anchor.update(Number(data.anchor));
	            }
	        }
	
	        if (Number(this.lastData.new_anchor) < Number(data.new_anchor)) {
	            if (!this.anim_new_anchor) {
	                this.anim_new_anchor = new CountUp(this.$el.find('.js_new_anchor')[0], Number(this.lastData.new_anchor), Number(data.new_anchor), 0, timeDis * 60, options);
	                this.anim_new_anchor.start();
	            } else {
	                this.anim_new_anchor.update(Number(data.new_anchor));
	            }
	        }
	    }
	
	    this.lastData = data;
	};
	
	ResultList.prototype.getData = function(data) {
	    $.extend(this.params, data);
	    var self = this;
	    var path = "indust/all";
	    api.get(path, this.params).done(function(data) {
	        if (data.code == 0) {
	            self.render({
	                data: data.data
	            });
	        }
	    });
	};
	module.exports = ResultList;
});;
define('widget/rankTab', function(require, exports, module){
	var RANKTAB_List = [{
		'name': '主播榜单',
		'val': 'anchor'
	}, {
		'name': '新晋主播',
		'val': 'new_anchor'
	}, {
		'name': '土豪榜单',
		'val': 'user'
	}];
	
	function RankTab(opts) {
		// this.template = _.template(__inline('./rankTab.html'));
	
		this.opts = opts || {};
	
		// this.$el = $('<div class="w-rank-tab"></div>');
		if (this.opts.$dom && this.opts.$dom.length) {
	        this.$el = this.opts.$dom.find('.w-rank-tab');
	    } else {
	        this.$el = $('.w-rank-tab');
	    }
	
		this.init();
	}
	
	RankTab.prototype.init = function() {
		this.render();
		this.bindEvent();
	};
	RankTab.prototype.render = function() {
		// this.$el.html(this.template({
		// 	list: RANKTAB_List,
		// 	userType:this.opts.userType
		// }));
	
		return this;
	};
	RankTab.prototype.bindEvent = function() {
		this.$el.on('click', 'li', function() {
			var $this = $(this);
			var type = $this.data("type");
			if (!$this.hasClass("active")) {
				$this.addClass('active').siblings().removeClass('active');
				$.pub('rankTab/change', [{
					'userType': type
				}]);
			}
		});
	
		return this;
	};
	
	module.exports = RankTab;
});;
define('widget/platformList', function(require, exports, module){
	var PLATFORM_LIST = [{
		'name': '全平台',
		'val': ''
	}, {
		'name': '斗鱼',
		'val': 'douyu'
	}, {
		'name': '虎牙',
		'val': 'huya'
	}, {
		'name': '全民',
		'val': 'quanmin'
	}, {
		'name': '熊猫',
		'val': 'panda'
	}, {
		'name': '战旗',
		'val': 'zhanqi'
	}, {
		'name': '龙珠',
		'val': 'longzhu'
	}, {
		'name': '触手',
		'val': 'chushou'
	}];
	
	function PlatformList(opts) {
		// this.template = _.template(__inline('./platformList.html'));
	
		this.opts = opts || {};
	
		// this.$el = $('.js-w-rank_platform_list').find('.w-platform-list');
		if (this.opts.$dom && this.opts.$dom.length) {
			this.$el = this.opts.$dom.find('.w-platform-list');
		} else {
			this.$el = $('.w-platform-list');
		}
	
		this.init();
	};
	
	PlatformList.prototype.init = function() {
		this.render();
		this.bindEvent();
	};
	PlatformList.prototype.render = function() {
		// this.$el.html(this.template({
		// 	'list': PLATFORM_LIST,
		// 	'platform': this.opts.platform
		// }));
	
		return this;
	};
	PlatformList.prototype.bindEvent = function() {
		var self = this;
	
		this.$el.on('click', 'li', function() {
			var $this = $(this);
			var platform = $this.data('platform');
			if (platform != undefined) {
				if (!$this.hasClass('active')) {
					$this.addClass('active').siblings().removeClass('active');
					// self.curPlatform = platform;
					$.pub('platform/change', [{
						'platform': platform
					}]);
				}
			}
		});
		return this;
	};
	
	module.exports = PlatformList;
});;
define('widget/rank', function(require, exports, module){
	var api = require('common/api');
	
	/**
	 * @param {String} [userType] [用户类型，主播'anchor', 新晋主播'new_anchor', 土豪'user']
	 * @param {String} [platform]	[douyu，huya，quanmin，平台名拼音,没有的话则为全平台]
	 * @param {Number} [category]	[类型，不传为全部]
	 * @param {String} [timeType]	[时间类型：5分钟为minute、1小时为hour，今日为today；历史时间单日的为day；历史时间范围的为dayRange；]
	 * @param {Number | String | Array} [timeValue] [对应时间类型的值：5分钟为5；1小时为1；历史单日如2017-08-10；历史范围为“[2017-07-01,2017-07-30]”]
	 * @param {String | Array } [rankType] [榜单类型，'gift', 'barrage']
	 * @param {Number} [limit] [限制展示的数量，默认不限制]
	 */
	function Rank(opts) {
		this.template = _.template("<% if ( userType == 'user'){ %>\r\n        <!--用户列表展示-->\r\n        <div class=\"w-rank_title w-rank-<%= timeType %>_title\">\r\n            <i></i>\r\n            <span><%= title %></span>\r\n            <span class=\"w-rank_tips_icon tooltips-top\" data-tooltips=\"主播收到的礼物根据平台比例换算后的数值，单位：元\"></span>\r\n        </div>\r\n        <% if ( list.length ){ %>\r\n        <ul class=\"w-rank-body-<%= rankType %>\">\r\n            <% _.each(list, function(item, index) { %>\r\n            <li data-usertype=\"<%- userType %>\" data-roomid=\"<%- item.roomid %>\" data-platform=\"<%- item.platform %>\" class=\"clearfix\">\r\n                <a href=\"javascript:;\">\r\n                    <% if ( index > 2 ) { %>\r\n                    <div class=\"w-rank_ranking\">NO.<%= index+1 %></div>\r\n                    <% }else { %>\r\n                    <div class=\"w-rank_ranking more-than-three\"><i><%= index+1 %></i></div>\r\n                    <% } %>\r\n                    <div class=\"rank-content\">\r\n                        <img src=\"<%= ZBB.platformDefaultAvatar[item.platform] %>\" class=\"w-rank_avatar\">\r\n                        <div class=\"w-rank_anchor_info js_anchor_info\">\r\n                            <p class=\"w-rank_anchor_info_user_nickname text-able-select\"><%- item.nickname %></p>\r\n                        </div>\r\n                    </div>\r\n                    <% if ( item.value ) { %>\r\n                    <div class=\"w-rank_value text-able-select\"><%= '￥' + item.value %></div>\r\n                    <% } %>\r\n                </a>\r\n            </li>\r\n            <% }) %>\r\n        </ul>\r\n        <% } %>\r\n<% } else{ %>\r\n        <!--主播列表展示-->\r\n        <div class=\"w-rank_title w-rank-<%= rankType %>_title\">\r\n            <i></i>\r\n            <span><%= title %></span>\r\n            <% if ( rankType == 'gift' ){ %>\r\n            <span class=\"w-rank_tips_icon tooltips-top\" data-tooltips=\"主播收到的礼物根据平台比例换算后的数值，单位：元\"></span>\r\n            <% } else { %>\r\n            <span class=\"w-rank_tips_icon tooltips-top\" data-tooltips=\"直播间观众累计发送的弹幕条数，单位：条\"></span>\r\n            <% } %>\r\n        </div>\r\n        <% if ( list.length ){ %>\r\n        <ul class=\"w-rank-body-<%= rankType %>\">\r\n            <% _.each(list, function(item, index) { %>\r\n            <li data-usertype=\"<%- userType %>\" data-roomid=\"<%- item.roomid %>\" data-platform=\"<%- item.platform %>\" class=\"clearfix\">\r\n                    <a href=\"/anchor?roomId=<%- item.roomid %>&platform=<%- item.platform %>\" target=\"_blank\">\r\n                        <% if ( index > 2 ) { %>\r\n                        <div class=\"w-rank_ranking\">NO.<%= index+1 %></div>\r\n                        <% }else { %>\r\n                        <div class=\"w-rank_ranking more-than-three\"><i><%= index+1 %></i></div>\r\n                        <% } %>\r\n                        <div class=\"rank-content\">\r\n                            <img src=\"<%= ZBB.platformDefaultAvatar['default'] %>\" data-original =\"<%= ZBB.parseAvatar(item.avatar) %>\" class=\"w-rank_avatar lazy\">\r\n                            <div class=\"w-rank_anchor_info js_anchor_info\">\r\n                                <p class=\"w-rank_anchor_info_nickname text-able-select\">\r\n                                    <%- item.nickname %>\r\n                                </p>\r\n                                <p>\r\n                                    <span class=\"w-rank_anchor_info_platform fl\"><%= ZBB.platformName[item.platform] %></span>\r\n                                    <% if ( item.categoryName ) { %>\r\n                                    <i class=\"fl\">-</i>\r\n                                    <span class=\"w-rank_anchor_info_category fl\"><%= item.categoryName%></span>\r\n                                    <% } %>\r\n                                </p>\r\n                            </div>\r\n                        </div>\r\n                        <% if ( item.value ) { %>\r\n                        <div class=\"w-rank_value text-able-select\"><%= (rankType == 'gift' ? '￥' : '') + item.value %></div>\r\n                        <% } %>\r\n                    </a>\r\n            </li>\r\n            <% }) %>\r\n        </ul>\r\n        <% } %>\r\n<% } %>\r\n\r\n\r\n\r\n");
		this.opts = opts || {};
		this.limit = this.opts.limit || -1;
		this.params = {
			userType: this.opts.userType || 'anchor',
			platform: this.opts.platform,
			category: this.opts.category,
			timeType: this.opts.timeType || 'hour',
			timeValue: this.opts.timeValue || 1,
			rankType: this.opts.rankType || 'gift',
			limit: this.opts.limit || 5
		};
		this.rankData = {};
		if (this.opts.$dom && this.opts.$dom.length) {
			this.$el = this.opts.$dom.find('.w-rank');
		} else {
			this.$el = $('<div class="w-rank clearfix"></div>');
		}
		this.init();
	};
	
	Rank.prototype.init = function() {
	
	};
	Rank.prototype.render = function() {
		if (this.rankData) {
			if (this.opts.limit && this.rankData.list) {
				this.rankData.list = this.rankData.list.slice(0, this.opts.limit);
				if (this.params.rankType == 'gift') {
					for (var i = 0, len = this.rankData.list.length; i < len; i++) {
						this.rankData.list[i].value = this.rankData.list[i].value.toFixed(2);
					}
				}
			}
			this.$el.html(this.template(this.rankData));
		}
		this.$el.find(".lazy").lazyload();
		return this;
	};
	Rank.prototype.getData = function(data) {
		$.extend(this.params, data);
		var self = this;
		var path = "rank/list";
	
		api.get(path, this.params).done(function(data) {
			if (data.code == 0) {
				self.rankData = data.data;
				self.rankData.userType = self.params.userType;
				self.rankData.rankType = self.params.rankType;
				self.rankData.timeType = self.params.timeType;
				self.render();
				$.pub('rank/updateEnd', [{
					timestamp: data.data.timestamp,
					timeType: self.params.timeType,
					userType: self.params.userType,
					timeValue: self.params.timeValue
				}]);
			}
		}).fail(function() {
			self.rankData.list = [];
			self.render();
		});
	};
	
	
	module.exports = Rank;
});;
define('widget/rank/rankUpdateTime.js', function(require, exports, module){
	/**
	 * @param {String} [timeType] [时间类型：5分钟为minute、1小时为hour，今日为today；历史时间单日的为day；历史时间范围的为dayRange；]
	 * @param {Number | String | Array} [timeValue] [对应时间类型的值：5分钟为5；1小时为1；历史单日如2017-08-10；历史范围为“[2017-07-01,2017-07-30]”]
	 */
	function RankUpdateTime(opts) {
		this.template = _.template("<span class=\"js_time_type\">最近<span class=\"w-rank-update-time_time\"> 1小时 </span></span>排行榜，更新时间\r\n<span class=\"w-rank-update-time_time js_lasttime\"></span>");
	
		this.opts = opts || {};
		// this.timeType = this.opts.timeType;
		// this.userType = this.opts.userType;
		// this.timeValue = this.opts.timeValue;
		// this.timestamp = this.opts.timestamp;
	
		// this.$el = $('<div class="w-rank-update-time" style="visibility: hidden"></div>');
		// this.$el = $('.w-rank-update-time');
		if (this.opts.$dom && this.opts.$dom.length) {
			this.$el = this.opts.$dom.find('.w-rank-update-time');
		} else {
			this.$el = $('.w-rank-update-time');
		}
		// this.init(this.opts.timestamp);
		// this.$el.html(this.template());
	}
	
	// RankUpdateTime.prototype.init = function() {
	// 	this.render();
	// };
	// RankUpdateTime.prototype.render = function() {
	// 	this.$el.html(this.template());
	// 	this.update({
	// 		timestamp: this.timestamp
	// 	});
	//
	// 	return this;
	// };
	RankUpdateTime.prototype.update = function(data) {
		// this.$el.css('visibility', 'visible');
		var timeType = data.timeType || this.timeType;
		var timeValue = data.timeValue || this.timeValue;
		var userType = data.userType || this.userType;
		var t = new Date(Number(data.timestamp) * 1000);
		var str = [];
	
		if (timeType == 'day' || timeType == 'dayRange') {
			this.$el.html("");
			return;
	
		} else {
			this.$el.html(this.template());
		}
		if (timeType == 'minute') {
	
			str.push('最近<span class="w-rank-update-time_time"> ' + timeValue + '分钟 </span>');
	
		}
		if (timeType == 'hour') {
	
			str.push('最近<span class="w-rank-update-time_time"> ' + timeValue + '小时 </span>');
	
		}
	
		if (timeType == 'today') {
	
			str.push('<span class="w-rank-update-time_time"> 今日 </span>');
	
		}
	
	
		if (userType == "user") {
			str = ["礼物价值"];
		}
	
		this.$el.find('.js_time_type').html(str.join(''));
		this.$el.find('.js_lasttime').text(t.Format('hh:mm'));
	
		//
	};
	
	module.exports = RankUpdateTime;
});;
define('widget/categoryList_new', function(require, exports, module){
	// var api = require('common/api');
	
	function CategoryList(opts) {
	    // this.template = _.template(__inline('./categoryList.html'));
	
	    this.opts = opts || {};
	    // this.params = {
	    // 	platform: this.opts.platform || "",
	    // 	category: this.opts.category || ""
	    // };
	    // this.hasAllCate = this.opts.hasAllCate || false;
	    // this.dataPage = this.opts.dataPage || false;
	    // this.categoryList = [];
	    // this.$el = $('<ul class="w-category-list clearfix"></ul>');
	    // this.$el = $('.w-category-list');
	    if (this.opts.$dom && this.opts.$dom.length) {
	        this.$el = this.opts.$dom.find('.w-category-list').prevObject;
	    } else {
	        this.$el = $('.w-category-list');
	    }
	    this.init();
	}
	
	CategoryList.prototype.init = function() {
	    this.bindEvent();
	};
	
	CategoryList.prototype.bindEvent = function() {
	    var self = this;
	
	    this.$el.on('click', 'div.swiper-slide', function() {
	        var $this = $(this);
	        var category = $this.data('category');
	        if (category != undefined) {
	            if (!$this.hasClass("active")) {
	                $this.addClass('active').siblings().removeClass('active');
	                $.pub('category/change', [{
	                    'category': category
	                }]);
	            }
	        }
	
	        /*if (self.hasAllCate) {
	            $.pub('category/change', [{
	                'category': category
	            }]);
	            return;
	        }
	        if (category != undefined) {
	            if (!$this.hasClass("active")) {
	                if (self.dataPage) {
	                    localStorage.category = category;
	                }
	                $this.addClass('active').siblings().removeClass('active');
	                $.pub('category/change', [{
	                    'category': category
	                }]);
	            }
	        }*/
	    });
	
	    return this;
	};
	
	module.exports = CategoryList;
});;
define('widget/industryCharts', function(require, exports, module){
	// 使用该模块的页面需引入echarts
	var api = require('common/api');
	
	/**
	 * @param {Number} [category] [频道类型]
	 * @param {String} [indicator] [指标：开播数anchor，礼物价值gift，弹幕数barrage，新增主播new_anchor]
	 * @param {String} [timeType]	[时间类型：5分钟为minute、1小时为hour，今日为today；历史时间单日的为day；历史时间范围的为dayRange；]
	 * @param {Number | String | Array} [timeValue] [对应时间类型的值：5分钟为5；1小时为1；历史单日如2017-08-10；历史范围为“[2017-07-01,2017-07-30]”]
	 */
	function IndustryCharts(opts) {
		this.opts = opts || {};
	
		this.params = {
			category: this.opts.category || 1,
			indicator: this.opts.indicator || 'barrage',
			timeType: this.opts.timeType || 'hour',
			timeValue: this.opts.timeValue || 1
		};
		this.unit = "人";
		this.$el = $('<div class="w-industry-charts"></div>');
		this.init();
	};
	
	IndustryCharts.prototype.init = function() {
		this.getData();
		this.bindEvent();
	};
	
	IndustryCharts.prototype.render = function(chartParams) {
		// echarts.init(this.$el[0]).clear();
		this.myChart = echarts.init(this.$el[0]);
	
		// 指定图表的配置项和数据
		this.myChartOption = {
			backgroundColor: {
				type: 'pattern',
				image: ZBB.canvasWaterMark(),
				repeat: 'repeat'
			},
			title: {
				show: false
			},
			tooltip: {
				trigger: 'axis',
				axisPointer: { // 坐标轴指示器，坐标轴触发有效
					type: 'shadow', // 默认为直线，可选为：'line' | 'shadow'
					shadowStyle: {
						color: {
							type: 'linear',
							x: 0,
							y: 0,
							x2: 0,
							y2: 1,
							colorStops: [{
								offset: 0,
								color: 'rgba(0, 192, 255, 0.2)' // 0% 处的颜色
							}, {
								offset: 1,
								color: 'rgba(0, 192, 255, 0.05)' // 100% 处的颜色
							}],
							globalCoord: false // 缺省为 false
						}
					}
				},
				formatter: function(params) {
					var sHtml = params[0].name,
						value = "",
						oldValue = "";
					if (chartParams.sign) {
						value = Number(params[0].value).toFixed(1)
					} else {
						value = Number(params[0].value)
					}
					if (params.length == 1) {
						var marker0 = '<span style="display:inline-block;margin-right:5px;border-radius:10px;width:9px;height:9px;background-color:' + params[0].color.colorStops[0].color + ';"></span>';
						sHtml += '<br/>' + marker0 + value.toLocaleString();
					} else {
						if (chartParams.sign) {
							oldValue = Number(params[1].value).toFixed(1);
						} else {
							oldValue = Number(params[1].value)
						}
						var marker0 = '<span style="display:inline-block;margin-right:5px;border-radius:10px;width:9px;height:9px;background-color:' + params[0].color.colorStops[0].color + ';"></span>';
						var marker1 = '<span style="display:inline-block;margin-right:5px;border-radius:10px;width:9px;height:9px;background-color:' + params[1].color.colorStops[0].color + ';"></span>';
						sHtml += '<p style="text-align: right;">' + marker0 + chartParams.time + '：' + value.toLocaleString() + '</p><p style="text-align: right;">' + marker1 + '上周期：' + oldValue.toLocaleString() + '</p>';
					}
					return sHtml;
				}
			},
			legend: {
				data: chartParams.xAxisData
			},
			grid: {
				top: 20,
				left: 10,
				right: 10,
				bottom: 0,
				containLabel: true
			},
			xAxis: {
				type: 'category',
				axisLabel: {
					textStyle: {
						color: '#8492af'
					}
				},
				axisTick: {
					show: false
				},
				axisLine: {
					show: false
				},
				data: chartParams.xAxisData
			},
			yAxis: {
				type: 'value',
				axisLabel: {
					formatter: '{value} ' + chartParams.unit,
					textStyle: {
						color: '#8492af'
					}
				},
				axisLine: {
					show: false
				},
				axisTick: {
					show: false
				},
				splitLine: {
					lineStyle: {
						type: 'dotted',
						color: '#8492af',
						opacity: 0.55
					}
				}
			}
		};
	
		if (this.params.timeType == 'dayRange') {
			this.myChartOption.series = [{
				// name:chartParams.time,
				type: 'bar',
				itemStyle: {
					normal: {
						color: {
							type: 'linear',
							x: 0,
							y: 0,
							x2: 0,
							y2: 1,
							colorStops: [{
								offset: 0,
								color: '#44dee8' // 0% 处的颜色
							}, {
								offset: 1,
								color: '#319df0' // 100% 处的颜色
							}],
							globalCoord: false // 缺省为 false
						}
					}
				},
				data: chartParams.seriesData_one
			}, {
				// name:chartParams.time,
				type: 'bar',
				itemStyle: {
					normal: {
						color: {
							type: 'linear',
							x: 0,
							y: 0,
							x2: 0,
							y2: 1,
							colorStops: [{
								offset: 0,
								color: '#2cc1ff' // 0% 处的颜色
							}, {
								offset: 1,
								color: '#2875e8' // 100% 处的颜色
							}],
							globalCoord: false // 缺省为 false
						}
					}
				},
				data: chartParams.seriesData_two
			}];
		} else {
			this.myChartOption.series = [{
				type: 'bar',
				barCategoryGap: '50%',
				itemStyle: {
					normal: {
						color: {
							type: 'linear',
							x: 0,
							y: 0,
							x2: 0,
							y2: 1,
							colorStops: [{
								offset: 0,
								color: '#44dee8' // 0% 处的颜色
							}, {
								offset: 1,
								color: '#319df0' // 100% 处的颜色
							}],
							globalCoord: false // 缺省为 false
						}
					}
				},
				data: chartParams.seriesData_one
			}];
		};
	
		// 使用刚指定的配置项和数据显示图表。
		this.myChart.setOption(this.myChartOption);
	
		return this;
	};
	IndustryCharts.prototype.bindEvent = function() {
		var self = this;
	
		return this;
	};
	IndustryCharts.prototype.getData = function(data) {
		$.extend(this.params, data);
		var self = this;
		var path = 'indust/cate';
		var unit = false;
		switch (self.params.indicator) {
			case "anchor":
			case "new_anchor":
				self.unit = "人";
				break;
			case "gift":
				self.unit = "元";
				break;
			case "barrage":
				self.unit = "条";
				break;
			default:
				self.unit = "人";
				break;
		}
		this.myChart && this.myChart.clear();
		api.get(path, this.params).done(function(data) {
			if (data.code == 0) {
				var arr = [];
				var xAxisData = [];
				var seriesData_one = [];
				var seriesData_two = [];
				if (self.params.timeType == 'dayRange') {
					$.each(ZBB.platformName, function(i, n) {
						arr.push({
							name: n,
							current: Number(data.data.current[n]),
							lastValue: data.data.last[n]
						});
					});
					unit = ZBB.IsBeyond(arr);
					if (unit) {
						ZBB.dataChange(arr, ['current', 'lastValue']);
						self.unit = "万" + self.unit;
					}
				} else {
					$.each(ZBB.platformName, function(i, n) {
						arr.push({
							name: n,
							current: Number(data.data.current[n])
						});
					});
					unit = ZBB.IsBeyond(arr);
					if (unit) {
						ZBB.dataChange(arr, ['current']);
						self.unit = "万" + self.unit;
					}
				}
				arr = arr.sort(ZBB.compare('current'));
				$.each(arr, function(i, obj) {
					xAxisData.push(obj.name);
					seriesData_one.push(Number(obj.current));
					seriesData_two.push(Number(obj.lastValue));
				});
				self.render({
					xAxisData: xAxisData,
					seriesData_one: seriesData_one,
					seriesData_two: seriesData_two,
					time: self.params.timeValue,
					unit: self.unit,
					sign: unit
				});
			}
		});
	};
	
	module.exports = IndustryCharts;
});;
define('widget/indicatorList', function(require, exports, module){
	function IndicatorList(opts) {
	    // this.template = _.template(__inline('./indicatorList.html'));
	
	    this.opts = opts || {};
	
	    // this.$el = $('<ul class="w-indicator-list js_indicator_list clearfix"></ul>');
	    if (this.opts.$dom && this.opts.$dom.length) {
	        this.$el = this.opts.$dom.find('.w-indicator-list');
	    } else {
	        this.$el = $('.w-indicator-list');
	    }
	
	    this.init();
	};
	
	IndicatorList.prototype.init = function() {
	    this.render();
	    this.bindEvent();
	};
	IndicatorList.prototype.render = function() {
	    // this.$el.html(this.template());
	    return this;
	};
	IndicatorList.prototype.bindEvent = function() {
	    var self = this;
	    this.$el.on('click', 'li', function() {
	        var $this = $(this);
	        var indicator = $(this).data('indicator');
	        if (indicator != undefined) {
	            if (!$this.hasClass("active")) {
	                $this.addClass('active').siblings().removeClass('active');
	                $.pub('indicator/change', [{
	                    'indicator': indicator,
	                    'type': self.opts.type
	                }]);
	            }
	        }
	    });
	    return this;
	};
	
	module.exports = IndicatorList;
});;
define(function(require) {
    // 302
    var MOBILE_UA_REGEXP = /(iPhone|iPod|Android|ios|iOS|iPad|Backerry|WebOS|Symbian|Windows Phone|Phone|Prerender|MicroMessenger)/i;
    if (MOBILE_UA_REGEXP.test(navigator.userAgent)) {
        var urlParams = ZBB.urlRequestParams();
        if (urlParams['isPc']) {

        } else {
            var pathname = location.pathname;
            var search = location.search;
            window.location.replace(ZBB.mDomain + pathname + search);
            return;
        }
    }

    var Header = require('widget/header');
    var Footer = require('widget/footer');

    var ResultList = require('widget/resultList');
    var RankTab = require('widget/rankTab');
    var PlatformList = require('widget/platformList');
    var Rank = require('widget/rank');
    var RankUpdateTime = require('widget/rank/rankUpdateTime.js');
    var CategoryList = require('widget/categoryList_new');
    var IndustryCharts = require('widget/industryCharts');
    var IndicatorList = require('widget/indicatorList');

    var oPage = {
        init: function() {
            this.render();
            this.bindEvent();
        },
        render: function() {
            this.header = new Header('index');
        },
        bindEvent: function() {
            var self = this;
            var height = window.innerHeight;
            $(document).scroll(
                _.debounce(function() {
                    var h = $(this).scrollTop();
                    if (h > height) {
                        $(".back_top").show();
                    } else {
                        $(".back_top").hide();
                    }

                }, 100)
            );

            $(".back_top").on('click', function() {
                $('html,body').animate({
                    scrollTop: 0
                }, 500, 'swing');
            })
        }
    };


    function MainPage() {
        this.$el = $('.main-body');

        this.$rank_tab = this.$el.find('.js-w-index_rank_tab');
        this.$platform_list = this.$el.find('.js-w-index-platform_list');
        this.$gift_rank = this.$el.find('.js-w-index_rank_gift');
        this.$barrage_rank = this.$el.find('.js-w-index_rank_barrage');
        this.$rank_update_time = this.$el.find('.js-w-index_rank_update_time');
        this.$category_list = this.$el.find('.js-w-index_category_list');
        this.$indicator_list = this.$el.find('.js-w-index_indicator_list');
        this.$industry_charts = this.$el.find('.js-w-index_industry_charts');

        this.init();
    }

    MainPage.prototype.init = function() {
        this.render();
        this.bindEvent();
    };

    MainPage.prototype.render = function() {
        this.rankTab = new RankTab({
            '$dom': this.$rank_tab
        });

        this.platformList = new PlatformList({
            '$dom': this.$platform_list
        });

        this.indicatorList = new IndicatorList({
            '$dom': this.$indicator_list
        });

        this.categoryList = new CategoryList({
            '$dom': this.$category_list
        });

        this.renderRank();

        this.renderIndustryCharts();

        return this;
    };

    MainPage.prototype.bindEvent = function() {
        var self = this;

        $.sub('categoryList/change',function (e,data) {
            console.log(e)
        });

        // 榜单
        $.sub('rankTab/change', function(e, data) {
            //修改下部按钮的href属性
            var url = $(".more-rank").attr("href");
            $(".more-rank").attr("href", self.replaceParams(url, "userType", data.userType));

            self.giftRank.getData({
                'userType': data.userType
            });

            if (data.userType == "user") {
                self.barrageRank.getData({
                    'userType': data.userType,
                    'rankType': 'gift',
                    'timeType': 'today',
                    'timeValue': (new Date()).Format('yyyy/MM/dd').replace(/\//g, "").replace(/\s/g, "")
                });
            } else {
                self.barrageRank.getData({
                    'userType': data.userType,
                    'rankType': 'barrage',
                    'timeType': 'hour',
                    'timeValue': 1
                });

            }
        });

        $.sub('platform/change', function(e, data) {
            //修改下部按钮的href属性
            var url = $(".more-rank").attr("href");
            $(".more-rank").attr("href", self.replaceParams(url, "platform", data.platform));

            self.giftRank.getData({
                'platform': data.platform
            });
            self.barrageRank.getData({
                'platform': data.platform
            });
        });

        $.sub('rank/updateEnd', function(e, data) {
            self.rankUpdateTime.update(data);
        });

        // 行业-频道类型
        $.sub('category/change', function(e, data) {
            self.industryCharts.getData(data);
        });

        // 行业-指标
        $.sub('indicator/change', function(e, data) {
            self.industryCharts.getData(data);
        });

        // 时间选择
        $.sub('timeType/change', function(e, data) {
            self.industryCharts.getData(data);
        });
    };


    MainPage.prototype.renderRank = function(data) {
        this.giftRank = new Rank({
            $dom: this.$gift_rank,
            rankType: 'gift',
            limit: 5,
            timeType: 'hour',
            timeValue: 1
        });

        this.barrageRank = new Rank({
            $dom: this.$barrage_rank,
            rankType: 'barrage',
            limit: 5,
            timeType: 'hour',
            timeValue: 1
        });

        this.rankUpdateTime = new RankUpdateTime({
            timeType: 'hour',
            timeValue: 1
        });
        this.$rank_update_time.html(this.rankUpdateTime.$el);
    };
    MainPage.prototype.renderIndustryCharts = function() {
        var $domCategory = this.$category_list.find('[data-category]').eq(0);
        var curCategory = $domCategory.data('data-category');
        var $dom = this.$indicator_list.find('li').eq(0);
        $domCategory.addClass('active');
        console.log($dom.data('indicator'),curCategory)
        this.industryCharts = new IndustryCharts({
            indicator: $dom.data('indicator'),
            timeType: 'hour',
            timeValue: 1,
            category: curCategory
        });
        this.$industry_charts.html(this.industryCharts.$el);
    };

    MainPage.prototype.replaceParams = function(url, arg, arg_val) {
        var pattern = arg + '=([^&]*)';
        var replaceText = arg + '=' + arg_val;
        if (url.match(pattern)) {
            var tmp = '/(' + arg + '=)([^&]*)/gi';
            tmp = url.replace(eval(tmp), replaceText);
            return tmp;
        } else {
            if (url.match('[\?]')) {
                return url + '&' + replaceText;
            } else {
                return url + '?' + replaceText;
            }
        }
    };

    oPage.init();
    var oRankPage = new MainPage();

});