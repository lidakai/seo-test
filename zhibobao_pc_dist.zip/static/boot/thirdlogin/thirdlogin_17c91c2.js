function dd() {
    var bridge = function() {
        var STATES = {
            'uninitialized': 0,
            'success': 1
        };
        var curState = STATES.uninitialized;
        var waitDoneFunc = [];

        window.zbb = {
            ready: function(callback) {
                if (typeof callback == 'function') {
                    if (curState == STATES.success) {
                        callback(true);
                    } else {
                        waitDoneFunc.push(callback);
                    }
                }
            },
            _doneReady: function(result) {
                for (var i in waitDoneFunc) {
                    waitDoneFunc[i](result);
                }
            },
            _detect: function() {

                var count = 0;

                var loop = function() {
                    count++;
                    if (zbb.isReady) {
                        zbb._doneReady(true);
                    } else {
                        setTimeout(function() {
                            loop();
                        }, 300);
                    }
                };

                loop();
            },
            qWebInit:function () {
                var QWebCallback = function(channel) {
                    var nativeWawa = channel.objects.zbb;
                    zbb.loginStatus = nativeWawa.loginStatus;
                    zbb.isReady = true;
                    curState = STATES.success;
                };
                new QWebChannel(qt.webChannelTransport, function(channel) {
                    QWebCallback(channel);
                });
            }
        };
        zbb.qWebInit();
        zbb._detect();
        return zbb;
    };
    bridge();
    zbb.ready(function () {
        function getUrlParams() {
            var url = location.search; //获取url中"?"符后的字串
            var theRequest = new Object();
            if (url.indexOf("?") != -1) {
                var str = url.substr(1);
                strs = str.split("&");
                for (var i = 0; i < strs.length; i++) {
                    theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
                }
            }
            return theRequest;
        };

        var urlObj = getUrlParams();
        if(urlObj["sid"]){
            zbb.loginStatus("sid",urlObj["sid"])
        }else if(urlObj["cacheId"]){
            zbb.loginStatus("cacheId",urlObj["cacheId"])
        }else{
            zbb.loginStatus("errorCode",encodeUnicode(urlObj["errorCode"]));
            document.getElementById("div").innerHTML = urlObj["errorCode"];
            document.getElementById("div1").innerHTML = decodeURIComponent(urlObj["errorCode"]);
            document.getElementById("div2").innerHTML = encodeUnicode(urlObj["errorCode"]);
        }

    });

    function encodeUnicode(str) {
        var res = [];
        for ( var i=0; i<str.length; i++ ) {
            res[i] = ( "00" + str.charCodeAt(i).toString(16) ).slice(-4);
        }
        return "\\u" + res.join("\\u");
    }
};


function encodeUnicode(str) {
    var res = [];
    for ( var i=0; i<str.length; i++ ) {
        res[i] = ( "00" + str.charCodeAt(i).toString(16) ).slice(-4);
    }
    return "\\u" + res.join("\\u");
}


function getUrlParams() {
    var url = location.search; //获取url中"?"符后的字串
    var theRequest = new Object();
    if (url.indexOf("?") != -1) {
        var str = url.substr(1);
        strs = str.split("&");
        for (var i = 0; i < strs.length; i++) {
            theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
        }
    }
    return theRequest;
};

var urlObj = getUrlParams();
if(urlObj["sid"]){
    document.getElementById("div").innerHTML = urlObj["errorCode"];
    document.getElementById("div1").innerHTML = decodeURIComponent(urlObj["errorCode"]);
    document.getElementById("div2").innerHTML = encodeUnicode(urlObj["errorCode"]);
}