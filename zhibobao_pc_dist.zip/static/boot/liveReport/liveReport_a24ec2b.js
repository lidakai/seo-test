define('common/apiExpire', function(require, exports, module){
	function localSign() {
		var key = 'GapV#&2%b';
		var timestamp = new Date().getTime();
		var val = md5(timestamp + key);
		return {
			'sign': val,
			'timestamp': timestamp
		};
	}
	
	module.exports = localSign;
});;
define('common/api', function(require, exports, module){
	var LocalSign = require('common/apiExpire');
	
	var REQUEST_TIMEOUT = 20000;
	
	var API_PREFIX = '/api/';
	
	
	function getApiUrl(path) {
		if (/\.\.*\//.test(path) || /http/.test(path)) {
			return path;
		} else {
			return API_PREFIX + path;
		}
	    console.log(path);
	}
	var API = {
		get: function(path, data, callback) {
			var localSign = LocalSign();
			data = $.extend({}, data, {
				'_timestamp': localSign.timestamp,
				'source': 0
			});
			var $defer = $.Deferred();
	
			$.ajax({
				type: 'get',
				url: getApiUrl(path),
				data: data,
				dataType: 'json',
				headers: {
					'T-code': localSign.sign
				},
				crossDomain: true,
				xhrFields: {
					withCredentials: true
				},
				timeout: REQUEST_TIMEOUT,
				success: function(data) {
					typeof(callback) == 'function' && callback(data);
	                if (data) {
						$defer.resolve(data);
					} else {
						$defer.reject();
					}
				},
				error: function(xhr, state) {
	                console.log(state);
					typeof(callback) == 'function' && callback(state);
					$defer.reject(state);
				}
			});
			return $defer;
		},
		post: function(path, data, callback) {
			var timestamp = LocalSign();
			data = $.extend({}, data, {
				'_timestamp': localSign.timestamp,
				'source': 0
			});
			var $defer = $.Deferred();
	
			$.ajax({
				type: 'post',
				url: getApiUrl(path),
				data: data,
				dataType: 'json',
				headers: {
					'T-code': localSign.sign
				},
				crossDomain: true,
				xhrFields: {
					withCredentials: true
				},
				timeout: REQUEST_TIMEOUT,
				success: function(data) {
					typeof(callback) == 'function' && callback(data);
	
					if (data) {
						$defer.resolve(data);
					} else {
						$defer.reject();
					}
				},
				error: function(xhr, state) {
					typeof(callback) == 'function' && callback(state);
					$defer.reject(state);
				}
			});
	
			return $defer;
		}
	};
	
	module.exports = API;
});;
define('widget/search', function(require, exports, module){
	var api = require('common/api');
	
	/**
	 * @param {String} [searchVal] [搜索关键词]
	 */
	function Search(opts) {
	    this.opts = opts || {};
	    
	    // this.template = _.template(__inline('./search.html'));
	    this.templateSearchList = _.template("<% if( data.length ) {%>\r\n<ul class=\"w-search-result\">\r\n    <% _.each(data, function(obj, index) { %>\r\n    <li class=\"w-search-result-value\" data-value=\"<%= obj.item %>\">\r\n    \t<% if( obj.plat ) { %>\r\n    \t<img src=\"<%= ZBB.platformDefaultAvatar[obj.plat] %>\">\r\n    \t<% } %>\r\n    \t<a href=\"javascript:;\"><%= obj.replaceItem %></a>\r\n    </li>\r\n    <% }) %>\r\n</ul>\r\n<% } %>");
	
	    // this.$el = $('<div class="w-search" id="w-search"></div>');
	    if (this.opts.$dom && this.opts.$dom.length) {
	        this.$el = this.opts.$dom.find('.w-search');
	    } else {
	        this.$el = $('.w-search');
	    }
	    this.params = {
	        'isPagination': false,
	        search: this.opts.search,
	        size: 10
	    };
	    this.init();
	}
	Search.prototype.render = function() {
	    // var self = this;
	    // this.$el.html(self.template());
	};
	Search.prototype.init = function() {
	    this.render();
	    this.bindEvent();
	};
	Search.prototype.getData = function(data) {
	    $.extend(this.params, data);
	    var self = this,
	        path = 'search';
	    api.get(path, this.params).done(function(data) {
	        if (data.code == 0) {
	            var arr = [];
	            $.each(data.data.list, function(index, item) {
	                // 同时替换大小写
	                var arrMatch = item.nickname.match(eval('/' + self.params.search + '/gi'));
	                var replaceItem = item.nickname;
	                $.each(arrMatch, function(i, n) {
	                    replaceItem = replaceItem.replace(eval('/' + n + '/g'), '<i class="replaceItem">' + n + '</i>');
	                });
	
	                arr.push({
	                    item: item.nickname,
	                    replaceItem: replaceItem,
	                    plat: item.plat
	                });
	            });
	            self.$el.find('.js_w-search_list').html(self.templateSearchList({
	                'data': arr
	            }));
	        }
	    });
	};
	
	Search.prototype.bindEvent = function() {
	    var self = this;
	    //搜索点击
	    this.$el.find(".w-icon_search").on("click", function() {
	        self.params.search = $(this).next().val();
	        if (!self.params.search) return;
	        self.$el.find("input").val("");
	        if (self.opts.flag == 'search') {
	
	            self.$el.find('.js_w-search_list').hide();
	            $.pub('search/getResult', [{
	                isPagination: false,
	                page: 1,
	                search: self.params.search
	            }]);
	        } else {
	            window.open("/search?search=" + self.params.search)
	        }
	
	    });
	
	    //搜索结果点击
	    self.$el.find('.js_w-search_list').on("click", ".w-search-result-value", function() {
	        self.params.search = $(this).data('value');
	        if (self.opts.flag == 'search') {
	            self.$el.find("input").val("");
	            self.$el.find('.js_w-search_list').hide();
	            $.pub('search/getResult', [{
	                isPagination: false,
	                page: 1,
	                search: self.params.search
	            }]);
	        } else {
	            // location.href = "/search?search=" + self.params.search;
	            window.open("/search?search=" + self.params.search)
	        }
	    });
	    // 输入框请求
	    this.$el.find("input").on("keyup",
	        _.debounce(function(event) {
	            var code = event.which || event.keyCode,
	                val = $(this).val();
	            if (!val) {
	                self.$el.find('.js_w-search_list').hide();
	                return;
	            }
	            if (code == 37 || code == 38 || code == 39 || code == 40) return;
	            self.$el.find('.js_w-search_list').show();
	            self.params.search = $(this).val();
	            if (code == 13) {
	                self.$el.find("input").val("");
	                self.$el.find('.js_w-search_list').hide();
	                if (self.$el.find(".w-search-result-value").hasClass("active")) {
	                    self.params.search = self.$el.find(".active").data("value");
	                }
	                if (self.opts.flag == 'search') {
	                    self.$el.find('.js_w-search_list').hide();
	                    $.pub('search/getResult', [{
	                        isPagination: false,
	                        page: 1,
	                        search: self.params.search
	                    }]);
	                } else {
	                    window.open("/search?search=" + self.params.search)
	                }
	            } else {
	                self.getData({
	                    search: self.params.search
	                });
	            }
	        }, 300));
	    this.$el.find("input").on("keydown", function(event) {
	        var $this = $(this);
	        var code = event.which || event.keyCode;
	        if (code == 38) { //上
	            if ($this.next().find(".w-search-result-value").hasClass("active")) {
	                if (!$this.next().find(".w-search-result-value").prev()) {
	                    $this.next().find(".w-search-result-value").first().addClass("active");
	                } else {
	                    $this.next().find(".active").removeClass("active").prev().addClass("active");
	                }
	            } else {
	                $this.next().find(".w-search-result-value").first().addClass("active");
	            }
	        } else if (code == 40) { //下
	            if ($this.next().find(".w-search-result-value").hasClass("active")) {
	
	                if (!$this.next().find(".w-search-result-value").next()) {
	                    $this.next().find(".w-search-result-value").first().addClass("active");
	                } else {
	                    $this.next().find(".active").removeClass("active").next().addClass("active");
	                }
	            } else {
	                $this.next().find(".w-search-result-value").first().addClass("active");
	            }
	        }
	    });
	    $('body').click(function(e) {
	        if ($(e.target).closest("#w-search").length == 0) {
	            self.$el.find('.js_w-search_list').hide();
	        }
	    });
	    return this;
	};
	
	module.exports = Search;
});;
define('widget/header', function(require, exports, module){
	var Search = require("widget/search");
	
	function Header(pageType) {
		// if (window.location.hostname == 'www.zhibobao.com') {
		// 	this.template = _.template(__inline('./header.html'));
		// } else {
		// 	this.template = _.template(__inline('./header_tv.html'));
		// }
	
		this.pageType = pageType;
		// if (pageType == 'index') {
		// 	this.$el = $('<div class="w-header w-header-index"></div>');
		// } else {
		// 	this.$el = $('<div class="w-header"></div>');
		// }
		
		this.init();
	};
	
	Header.prototype.init = function() {
		this.render();
		this.bindEvent();
	};
	Header.prototype.render = function() {
		// this.$el.html(this.template());
	
		// var $head_nav = this.$el.find('.w-header_nav');
	
		// var pathname = location.pathname;
	
		// if (window.location.hostname == 'www.zhibobao.com') {
		// 	if (pathname == '/static/boot/main/main.html' || pathname == '/') {
		// 		$head_nav.find('[data-page="home"]').addClass('active');
		// 	} else if (pathname == '/static/boot/rank/rank.html' || pathname == '/rank') {
		// 		$head_nav.find('[data-page="rank"]').addClass('active');
		// 	} else if (pathname == '/static/boot/platform/platform.html' || pathname == '/platform') {
		// 		$head_nav.find('[data-page="platform"]').addClass('active');
		// 	} else if (pathname == '/static/boot/tool/tool.html' || pathname == '/tool') {
		// 		$head_nav.find('[data-page="tool"]').addClass('active');
		// 	}
		// } else {
		// 	if (pathname == '/static/boot/main/main.html' || pathname == '/data') {
		// 		$head_nav.find('[data-page="home"]').addClass('active');
		// 	} else if (pathname == '/static/boot/rank/rank.html' || pathname == '/rank') {
		// 		$head_nav.find('[data-page="rank"]').addClass('active');
		// 	} else if (pathname == '/static/boot/platform/platform.html' || pathname == '/platform') {
		// 		$head_nav.find('[data-page="platform"]').addClass('active');
		// 	} else if (pathname == '/static/boot/tool/tool.html' || pathname == '/') {
		// 		$head_nav.find('[data-page="tool"]').addClass('active');
		// 	}
		// }
		
		this.$el = $('.w-header');
		if (this.pageType == 'search') {
	
		} else {
			this.search = new Search();
			// this.$el.find('.js-w-header_search').html(this.search.$el);
		}
	
		return this;
	};
	Header.prototype.bindEvent = function() {
		var self = this;
	
		$(document).scroll(function() {
			var h = $(this).scrollTop();
			if (h > 0) {
				self.$el.addClass('w-header-scroll');
			} else {
				self.$el.removeClass('w-header-scroll');
			}
		});
	
		this.$el.find(".w-header_nav_link_warp a").on("click", function() {
			if($(this).attr('target') == '_blank') {
				return;
			}
	
			$(this).parent().addClass("active").siblings().removeClass('active');
			if ($(this).data('page') == "tool") {
				self.$el.parent().addClass('w-header-new');
			} else {
				self.$el.parent().removeClass('w-header-new');
			}
		});
		return this;
	};
	
	Header.prototype.activeNav = function(index) {
		var $list = this.$el.find('.w-header_nav_link_warp');
		$list.removeClass('active');
		$list.eq(index).addClass('active');
	
		if (index === 0) {
			this.$el.addClass('w-header-index');
		} else {
			this.$el.removeClass('w-header-index');
		}
	};
	
	module.exports = Header;
});;
define('widget/footer', function(require, exports, module){
	function Footer() {
	
	    // if( window.location.hostname == 'www.zhibobao.com' ){
	    //     this.template = _.template(__inline('./footer.html'));
	    // }else{
	    //     this.template = _.template(__inline('./footer_tv.html'));
	    // }
	    // this.$el = $('<div class="w-footer"></div>');
	
	    // this.init();
	};
	
	// Footer.prototype.init = function() {
	//     this.render();
	//     this.bindEvent();
	// };
	// Footer.prototype.render = function() {
	//     this.$el.html(this.template());
	
	//     return this;
	// };
	// Footer.prototype.bindEvent = function() {
	//     var self = this;
	
	//     return this;
	// };
	
	module.exports = Footer;
});;
define(function(require) {
    // // 302
    // var MOBILE_UA_REGEXP = /(iPhone|iPod|Android|ios|iOS|iPad|Backerry|WebOS|Symbian|Windows Phone|Phone|Prerender|MicroMessenger)/i;
    // if (MOBILE_UA_REGEXP.test(navigator.userAgent)) {
    //     var pathname = location.pathname;
    //     var search = location.search;
    //     window.location.replace(ZBB.mDomain + pathname + search);
    //     return;
    // }

    var API = require('common/api');
    var Header = require('widget/header');
    var Footer = require('widget/footer');

    var oPage = {
        data: {
            maxLoopCount: 30,
            loopCount: 0
        },
        init: function() {
            var urlParams = ZBB.urlRequestParams();

            this.template = _.template("            <div class=\"report_wrap\">\r\n                <div class=\"report_wrap_content giftReport\"></div>\r\n                <div class=\"report_wrap_content rewardReport  clearfix\">\r\n                    <div class=\"rewardReport-richer-content fl\">\r\n                        <p class=\"rewardReport-richer-content-title rewardReport-title\">土豪</p>\r\n                        <% if(data.rich.richTopList.length > 0) { %>\r\n                        <ul class=\"rewardReport-richer-list\" >\r\n                            <% _.each(data.rich.richTopList, function(item, index) { %>\r\n                            <li class=\"rewardReport-richer-list-unit clearfix\">\r\n                                <% if( index < 3 ) {%>\r\n                                    <i class=\"fl ranking_<%= (index+1) %>\"></i>\r\n                                <% }else{ %>\r\n                                <i class=\"fl\">No.<%= (index+1) %></i>\r\n                                <% } %>\r\n                                <!-- <img class=\"rewardReport-richer-portrait fl\" src=\"./img/1.png\" alt=\"\"> -->\r\n                                <p class=\"rewardReport-richer-describe fl\"><i><%= item.nickname %></i> 送出 <i><%= item.value %>个<%= ZBB.platformUnit[data.plat] || '' %></i></p>\r\n                            </li>\r\n                            <% }) %>\r\n                        </ul>\r\n                        <% } else { %>\r\n                        <p class=\"rewardReport-richer_nolist\">这一次直播没有土豪出没哦 &gt;_&lt; </p>\r\n                        <% } %>\r\n                    </div>\r\n                    <div class=\"rewardReport-common-content fl\">\r\n                        <p class=\"rewardReport-common-content-title rewardReport-title\">打赏观众</p>\r\n\r\n                        <ul class=\"rewardReport-common-list\" >\r\n                            <% _.each(data.rich.viewerTopList, function(item, index) { %>\r\n                            <li class=\"rewardReport-common-list-unit\"><i class=\"rewardReport-common-portrait\"><%= item.nickname %></i> 送出 <i> <%= item.value %>个<%= ZBB.platformUnit[data.plat] || '' %></i></li>\r\n                            <% }) %>\r\n                        </ul>\r\n\r\n                    </div>\r\n                    <div class=\"rewardReport-chart fl\"></div>\r\n                </div>\r\n                <div class=\"report_wrap_content barrageReport\">\r\n                    <p class=\"barrageReport-describe\">\r\n                        <% if(data.barrage.compare !== false) { %>\r\n                        <% if( data.barrage.compare <= 0 ) {%>\r\n                        <span class=\"barrageReport-change fl\"><i class=\"down anchor-info_follow_change\"></i>比上次下跌了<i class=\"peopleReport-describe-change-num down\"><%= data.barrage.compare.toFixed(1) + '%' %></i></span>\r\n                        <% }else{ %>\r\n                        <span class=\"barrageReport-change fl\"><i class=\"anchor-info_follow_change\"></i>比上次上涨了<i class=\"peopleReport-describe-change-num\"><%= data.barrage.compare.toFixed(1) + '%' %></i></span>\r\n                        <% } %>\r\n                        <% } %>\r\n                        <span class=\"fl barrageReport-describe-peakTimes\">出现了<i><%= data.barrage.peakTimes %></i>次弹幕高峰</span>\r\n                        <span class=\"fl barrageReport-describe-peakBar\">最高峰值<i><%= data.barrage.peakBar %>条/分钟</i></span>\r\n                        <span class=\"fl barrageReport-describe-avgBar\">平均<i><%= data.barrage.avgBar %>条/分钟</i></span>\r\n                        <% if( data.barrage.compare <= 0 ) {%>\r\n                        <span class=\"fr barrageReport-describe-advise\">建议适时购买弹幕服务，对提升更有帮助哦</span>\r\n                        <% } %>\r\n\r\n                    </p>\r\n                    <div class=\"barrageReport-chart\"></div>\r\n                </div>\r\n                <div class=\"report_wrap_content peopleReport\">\r\n                    <p class=\"peopleReport-describe\">\r\n                        <% if( data.online.compare <= 0 ) {%>\r\n                        <span class=\"peopleReport-describe-change fl\"><i class=\"down anchor-info_follow_change\"></i>比上次直播下跌了<i class=\"peopleReport-describe-change-num down\"><%= data.online.compare %></i></span>\r\n                        <% }else{ %>\r\n                        <span class=\"peopleReport-describe-change fl\"><i class=\"anchor-info_follow_change\"></i>比上次直播上涨了<i class=\"peopleReport-describe-change-num\"><%= data.online.compare %></i></span>\r\n                        <% } %>\r\n                        <span class=\"fl w-peopleReport-describe-time\">开播 <i class=\"peopleReport-describe-change-timeWait\"><%= afterTime %>分钟</i>后<i class=\"peopleReport-describe-change-time\"><%=new Date(data.online.peakTime).Format('hh:mm')%></i>达到人气最高峰</span>\r\n                    </p>\r\n                    <div class=\"peopleReport-chart\"></div>\r\n                </div>\r\n            </div>");

            this.render();
            this.bindEvent();

            if (urlParams['roomId'] && urlParams['platform']) {
                this.getAnchorInfo(urlParams);
                if (urlParams['start'] && urlParams['stop']) {
                    this.getData(urlParams);
                }
            } else {
                console.log('参数不正确');
            }
        },
        render: function() {
            this.header = new Header();
            $('.main-header').append(this.header.$el);

            var footer = new Footer();
            $('.main-footer').append(footer.$el);

        },
        renderPeopleReportChart: function(data) {
            var xAxisData = [],
                seriesData = [];
            $.each(data, function(i, obj) {
                xAxisData.push(new Date(obj.timestamp).Format('hh:mm'));
                seriesData.push(Number(obj.value));
            });
            this.initLiechart({
                xAxisData: xAxisData,
                seriesData: seriesData,
                peopleMarkPoint: true,
                el: $(".main-body").find(".peopleReport-chart")
            });
        },
        renderRewardReportChart: function(data) {
            var nameData = ["土豪", "打赏观众"];
            var seriesData = [{
                value: data.richTotal.toFixed(1),
                name: "土豪"
            }, {
                value: data.viewerTotal.toFixed(1),
                name: "打赏观众"
            }];
            var legendObj = {
                "土豪": "土豪：" + data.richTotal.toFixed(1) + "元\r\n\n占比：" + (data.richTotal / (data.richTotal + data.viewerTotal) * 100).toFixed() + "%",
                "打赏观众": "打赏观众：" + data.viewerTotal.toFixed(1) + "元\r\n\n占比：" + (data.viewerTotal / (data.richTotal + data.viewerTotal) * 100).toFixed() + "%"
            }
            this.initPieChart({
                nameData: nameData,
                seriesData: seriesData,
                legendObj: legendObj,
                el: $(".main-body").find(".rewardReport-chart")
            });
        },
        renderGiftReportChart: function(data) {
            var nameData = [],
                seriesData = [],
                count = [],
                legendObj = {};
            $.each(data.list, function(i, obj) {
                nameData.push(obj.giftName);
                seriesData.push({
                    value: Number(obj.value),
                    name: obj.giftName,
                    count: Number(obj.count),
                    total: data.total
                });
                legendObj[obj.giftName] = obj.count;
                count.push(Number(obj.count));
            });
            this.initGiftPieChart({
                nameData: nameData,
                seriesData: seriesData,
                legendObj: legendObj,
                el: $(".main-body").find(".giftReport")
            });
        },
        renderBarrageReportChart: function(data, arrBarragePeak) {
            var xAxisData = [],
                seriesData = [];
            $.each(data, function(i, obj) {
                xAxisData.push(new Date(obj.timestamp).Format('hh:mm'));
                seriesData.push(Number(obj.value));
            });
            this.initLiechart({
                xAxisData: xAxisData,
                seriesData: seriesData,
                arrBarragePeak: arrBarragePeak,
                el: $(".main-body").find(".barrageReport-chart")
            });
        },
        initLiechart: function(data) {
            var arrMarkPoint = [];
            // 弹幕标注点
            if (data.arrBarragePeak) {
                for (var i = 0, len = data.arrBarragePeak.length; i < len; i++) {
                    arrMarkPoint.push({
                        'coord': [data.arrBarragePeak[i].index, data.arrBarragePeak[i].value]
                    });
                }
            }
            // 人气标注点
            if (data.peopleMarkPoint) {
                arrMarkPoint.push({
                    type: 'max',
                    label: {
                        normal: {
                            formatter: function(param) {
                                return 'max';
                            }
                        }
                    }
                });
            }

            this.$el = $('<div class="w-lie-charts"></div>');
            data.el.html(this.$el);
            echarts.init(this.$el[0]).clear();
            var myChart = echarts.init(this.$el[0]);
            var myChartOption = {
                backgroundColor: {
                    type: 'pattern',
                    image: ZBB.canvasWaterMark(),
                    repeat: 'repeat'
                },
                title: {
                    show: false
                },
                tooltip: {
                    trigger: 'axis',
                    axisPointer: { // 坐标轴指示器，坐标轴触发有效
                        type: 'shadow', // 默认为直线，可选为：'line' | 'shadow'
                        shadowStyle: {
                            color: {
                                type: 'linear',
                                x: 0,
                                y: 0,
                                x2: 0,
                                y2: 1,
                                colorStops: [{
                                    offset: 0,
                                    color: 'rgba(48, 131, 255, 0)' // 0% 处的颜色
                                }, {
                                    offset: 1,
                                    color: 'rgba(48, 131, 255, 0.1)' // 100% 处的颜色
                                }],
                                globalCoord: false // 缺省为 false
                            }
                        }
                    }
                },
                legend: {},
                toolbox: {
                    show: false
                },
                xAxis: [{
                    type: 'category',
                    axisLabel: {
                        textStyle: {
                            color: '#8492af'
                        },
                    },
                    axisLine: {
                        lineStyle: {
                            type: 'dotted',
                            color: '#8492af'
                        }
                    },
                    boundaryGap: false,
                    data: data.xAxisData
                }],
                yAxis: [{
                    type: 'value',
                    axisLabel: {
                        textStyle: {
                            color: '#8492af'
                        },
                        formatter: '{value}'
                    },
                    axisLine: {
                        lineStyle: {
                            type: 'dotted',
                            color: '#8492af'
                        }
                    },
                    axisTick: {
                        show: false
                    },
                    splitLine: {
                        lineStyle: {
                            type: 'dotted',
                            color: '#8492af',
                            opacity: 0.55
                        }
                    }
                }],
                animation: false,
                // animationDuration:500,
                series: [{
                    name: '',
                    type: 'line',
                    data: data.seriesData,
                    showSymbol: false,
                    itemStyle: {
                        normal: {
                            color: "#6796ff",
                            areaStyle: {
                                type: 'default',
                                color: {
                                    type: 'linear',
                                    x: 0,
                                    y: 0,
                                    x2: 0,
                                    y2: 1,
                                    colorStops: [{
                                        offset: 0,
                                        color: 'rgba(48, 131, 255, 1)' // 0% 处的颜色
                                    }, {
                                        offset: 1,
                                        color: 'rgba(48, 131, 255, 0.2)' // 100% 处的颜色
                                    }],
                                    globalCoord: false // 缺省为 false
                                }

                            },
                            lineStyle: {
                                color: "#6796ff"
                            }
                        }
                    },
                    markPoint: {
                        data: arrMarkPoint
                    }
                }]
            };
            myChart.setOption(myChartOption);
            return this;
        },
        initGiftPieChart: function(chartParams) {
            this.$el = $('<div class="w-pie-charts"></div>');
            chartParams.el.html(this.$el);
            echarts.init(this.$el[0]).clear();
            var myChart = echarts.init(this.$el[0]);
            var chartColors = [{
                type: 'linear',
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [{
                    offset: 0,
                    color: '#5549f4' // 0% 处的颜色
                }, {
                    offset: 1,
                    color: '#4788ff' // 100% 处的颜色
                }],
                globalCoord: false // 缺省为 false
            }, {
                type: 'linear',
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [{
                    offset: 0,
                    color: '#3477ff' // 0% 处的颜色
                }, {
                    offset: 1,
                    color: '#43bfff' // 100% 处的颜色
                }],
                globalCoord: false // 缺省为 false
            }, {
                type: 'linear',
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [{
                    offset: 0,
                    color: '#3aaeff' // 0% 处的颜色
                }, {
                    offset: 1,
                    color: '#56edff' // 100% 处的颜色
                }],
                globalCoord: false // 缺省为 false
            }, {
                type: 'linear',
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [{
                    offset: 0,
                    color: '#fe9131' // 0% 处的颜色
                }, {
                    offset: 1,
                    color: '#ffd541' // 100% 处的颜色
                }],
                globalCoord: false // 缺省为 false
            }, {
                type: 'linear',
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [{
                    offset: 0,
                    color: '#ff4f4f' // 0% 处的颜色
                }, {
                    offset: 1,
                    color: '#ff8c3f' // 100% 处的颜色
                }],
                globalCoord: false // 缺省为 false
            }, {
                type: 'linear',
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [{
                    offset: 0,
                    color: '#ff5172' // 0% 处的颜色
                }, {
                    offset: 1,
                    color: '#fe927a' // 100% 处的颜色
                }],
                globalCoord: false // 缺省为 false
            }, {
                type: 'linear',
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [{
                    offset: 0,
                    color: '#0ec7f5' // 0% 处的颜色
                }, {
                    offset: 1,
                    color: '#26f0c3' // 100% 处的颜色
                }],
                globalCoord: false // 缺省为 false
            }, {
                type: 'linear',
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [{
                    offset: 0,
                    color: '#16cf69' // 0% 处的颜色
                }, {
                    offset: 1,
                    color: '#6ef3bc' // 100% 处的颜色
                }],
                globalCoord: false // 缺省为 false
            }];
            var chartColorsLength = chartColors.length;
            // 指定图表的配置项和数据
            var myChartOption = {
                backgroundColor: {
                    type: 'pattern',
                    image: ZBB.canvasWaterMark(),
                    repeat: 'repeat'
                },
                tooltip: {
                    trigger: 'item'
                },
                legend: {
                    orient: 'vertical',
                    left: '10%',
                    top: 'center',
                    itemGap: 15,
                    itemWidth: 15,
                    itemHeight: 15,
                    textStyle: {
                        color: '#8492af'
                    },
                    icon: 'circle',
                    data: chartParams.nameData,
                    formatter: function(name) {
                        if (!chartParams.legendObj) return name;
                        return chartParams.legendObj[name] + "个" + name;

                    }
                },
                toolbox: {
                    show: false
                },
                series: {
                    center: ['60%', '52%'],
                    color: chartColors,
                    type: 'pie',
                    selectedMode: 'single',
                    radius: [0, 130],
                    legendHoverLink: true,
                    label: {
                        normal: {
                            position: 'outside',
                            textStyle: {
                                color: '#8492af'
                            },
                            fontSize: 16,
                            formatter: function(params) {
                                return params.name + "：" + params.data.value + "元    " + params.percent + "%"
                            }
                        }
                    },
                    labelLine: {
                        normal: {
                            lineStyle: {
                                color: '#8492af'
                            },
                            length: 60,
                            length2: 30
                        }
                    },
                    itemStyle: {
                        normal: {
                            color: function(params) {
                                return chartColors[params.dataIndex % chartColorsLength];
                            }
                        },
                        emphasis: {
                            shadowBlur: 20,
                            shadowColor: 'rgba(0, 0, 0, 0.5)'
                        }
                    },
                    data: chartParams.seriesData
                }
            };

            // 使用刚指定的配置项和数据显示图表。
            myChart.setOption(myChartOption);

            return this;
        },
        initPieChart: function(chartParams) {
            this.$el = $('<div class="w-pie-charts"></div>');
            chartParams.el.html(this.$el);
            echarts.init(this.$el[0]).clear();
            var myChart = echarts.init(this.$el[0]);

            var chartColors = [
                "#5258f7", "#1ee8d3"
            ];
            // 指定图表的配置项和数据
            var myChartOption = {
                backgroundColor: {
                    type: 'pattern',
                    image: ZBB.canvasWaterMark(),
                    repeat: 'repeat'
                },
                tooltip: {
                    trigger: 'item'
                },
                legend: {
                    orient: 'horizontal',
                    left: 'center',
                    bottom: '10%',
                    itemGap: 25,
                    itemWidth: 15,
                    itemHeight: 15,
                    textStyle: {
                        color: '#8492af',
                        height: 50,
                        lineHeight: 50
                    },
                    icon: 'circle',
                    data: chartParams.nameData,
                    formatter: function(name) {
                        return chartParams.legendObj[name];
                    }
                },
                toolbox: {
                    show: false
                },
                series: {
                    center: ['50%', '40%'],
                    color: chartColors,
                    type: 'pie',
                    selectedMode: 'single',
                    radius: [0, 100],
                    legendHoverLink: true,
                    label: {
                        normal: {
                            position: 'outside',
                            textStyle: {
                                color: '#8492af'
                            },
                            fontSize: 16,
                            formatter: function(params) {
                                return params.name + "：共 " + params.data.value + "元\r\n占比：" + params.percent + "%";
                            }
                        }
                    },
                    labelLine: {
                        normal: {
                            lineStyle: {
                                color: '#8492af'
                            },
                            length: 20,
                            length2: 10
                        }
                    },
                    itemStyle: {
                        normal: {
                            color: function(params) {
                                return chartColors[params.dataIndex % chartColors.length];
                            }
                        },
                        emphasis: {
                            shadowBlur: 20,
                            shadowColor: 'rgba(0, 0, 0, 0.5)'
                        }
                    },
                    data: chartParams.seriesData
                }
            };

            // 使用刚指定的配置项和数据显示图表。
            myChart.setOption(myChartOption);

            return this;
        },
        getData: function(opts) {
            var self = this;
            var path = 'anchor/live/report';
            var options = {
                roomId: opts['roomId'],
                platform: opts['platform'],
                start: opts['start'],
                stop: opts['stop']
            };
            this.data.loopCount++;

            API.get(path, options, function(data) {
                if (data.code == 0) {
                    API.get(data.data.url, {}, function(response) {
                        var afterTime = response.online.peakTime - parseInt(options.start) * 1000;
                        afterTime = parseInt(afterTime / 60000);

                        var arrBarragePeak = self.barragePeakTimes(response.barrage);
                        response.barrage.peakTimes = arrBarragePeak.length;

                        $(".report-block-two").html(self.template({
                            'data': response,
                            'afterTime': afterTime
                        }));
                        $("#gift_num").text(response.gift.total);
                        $("#reward_num").text(response.rich.total);
                        $("#barrage_num").text(response.barrage.total);
                        $("#online_num").text(response.online.peak);
                        if (response.roomInfo.follow.value >= 0) {
                            $(".follow").html("关注：" + response.roomInfo.follow.value);
                            if (response.roomInfo.follow.up < 0) {
                                $("#follow_change").addClass("down");
                            }
                            $("#follow_change").html(response.roomInfo.follow.up);
                            $('.anchor-info_follow').show();
                        }

                        self.renderGiftReportChart(response.gift);
                        self.renderRewardReportChart({
                            richTotal: response.rich.richTotal,
                            viewerTotal: response.rich.viewerTotal
                        });
                        self.renderBarrageReportChart(response.barrage.list, arrBarragePeak);
                        self.renderPeopleReportChart(response.online.list);
                    });
                } else if (data.code == 1234) {
                    if (self.data.loopCount < self.data.maxLoopCount) {
                        setTimeout(function() {
                            self.getData(opts);
                        }, 2000);
                    }
                }
            });
        },
        barragePeakTimes: function(barrageSource) {
            var arrList = [];
            var minPearVal = Math.max(barrageSource.avgBar * 2, 10);

            for (var i = 0, len = barrageSource.list.length; i < len; i++) {
                if (barrageSource.list[i].value > minPearVal) {
                    barrageSource.list[i].index = i;
                    arrList.push(barrageSource.list[i]);
                }
            }
            var timeStep = 1000 * 60 * 5; // 时间间隔内部重复计算峰值点
            for (var i = 0, len = arrList.length; i < len; i++) {
                for (var j = i + 1; j < len; j++) {
                    if (arrList[j].timestamp - arrList[i].timestamp < timeStep) {
                        if (arrList[j].value > arrList[i].value) {
                            arrList.splice(i, 1);
                            i--;
                            len--;
                            break;
                        } else {
                            arrList.splice(j, 1);
                            j--;
                            len--;
                        }
                    }
                }
            }
            return arrList;
        },
        getAnchorInfo: function(opts) {
            var self = this;
            var path = 'anchor/info';
            API.get(path, {
                'platform': opts.platform,
                'roomId': opts.roomId
            }).then(function(data) {
                if (data.code == 0) {
                    self.renderAnchorInfo(data.data.info, opts);
                }
            });
        },
        renderAnchorInfo: function(data, options) {
            if (data) {
                $('#avatar').attr('src', ZBB.parseAvatar(data.avatar));
                $('#nickname').text(data.nickname);
                $('#roomid').text(data.roomId);
                $('#platform').text(ZBB.platformName[data.platform]).show();
                $('#category').text(data.cateName).show();
                // 开播时间，持续时间
                var startTime = new Date(parseInt(options.start) * 1000).Format('yyyy/MM/dd hh:mm');
                var duration = parseInt(options.stop) - parseInt(options.start);
                var strHtml = startTime + ' 开播，共播了<span class="special-text">' + this.durationString(duration) + '</span>';
                $('#start_time').html(strHtml);
            }
        },
        durationString: function(duration) {
            var str = '';
            if (duration >= 3600) {
                var hour = parseInt(duration / 3600);
                var min = parseInt((duration - hour * 3600) / 60);
                str = hour + '小时' + min + '分钟';
            } else {
                var min = parseInt(duration / 60);
                str = min + '分钟';
            }
            return str;
        },
        bindEvent: function() {
            $(".report-tab_tab").on("click", function() {
                var $this = $(this);
                if ($this.hasClass("report-tab_tab_active")) return;
                $this.addClass("report-tab_tab_active").siblings().removeClass("report-tab_tab_active");
                $(".report-block-two").find(".report_wrap_content").hide();
                $("." + $this.data("type")).show();
            });
        }
    };



    oPage.init();


});