define('common/apiExpire', function(require, exports, module){
	function localSign() {
		var key = 'GapV#&2%b';
		var timestamp = new Date().getTime();
		var val = md5(timestamp + key);
		return {
			'sign': val,
			'timestamp': timestamp
		};
	}
	
	module.exports = localSign;
});;
define('common/api', function(require, exports, module){
	var LocalSign = require('common/apiExpire');
	
	var REQUEST_TIMEOUT = 20000;
	
	var API_PREFIX = '/api/';
	
	
	function getApiUrl(path) {
		if (/\.\.*\//.test(path) || /http/.test(path)) {
			return path;
		} else {
			return API_PREFIX + path;
		}
	    console.log(path);
	}
	var API = {
		get: function(path, data, callback) {
			var localSign = LocalSign();
			data = $.extend({}, data, {
				'_timestamp': localSign.timestamp,
				'source': 0
			});
			var $defer = $.Deferred();
	
			$.ajax({
				type: 'get',
				url: getApiUrl(path),
				data: data,
				dataType: 'json',
				headers: {
					'T-code': localSign.sign
				},
				crossDomain: true,
				xhrFields: {
					withCredentials: true
				},
				timeout: REQUEST_TIMEOUT,
				success: function(data) {
					typeof(callback) == 'function' && callback(data);
	                if (data) {
						$defer.resolve(data);
					} else {
						$defer.reject();
					}
				},
				error: function(xhr, state) {
	                console.log(state);
					typeof(callback) == 'function' && callback(state);
					$defer.reject(state);
				}
			});
			return $defer;
		},
		post: function(path, data, callback) {
			var timestamp = LocalSign();
			data = $.extend({}, data, {
				'_timestamp': localSign.timestamp,
				'source': 0
			});
			var $defer = $.Deferred();
	
			$.ajax({
				type: 'post',
				url: getApiUrl(path),
				data: data,
				dataType: 'json',
				headers: {
					'T-code': localSign.sign
				},
				crossDomain: true,
				xhrFields: {
					withCredentials: true
				},
				timeout: REQUEST_TIMEOUT,
				success: function(data) {
					typeof(callback) == 'function' && callback(data);
	
					if (data) {
						$defer.resolve(data);
					} else {
						$defer.reject();
					}
				},
				error: function(xhr, state) {
					typeof(callback) == 'function' && callback(state);
					$defer.reject(state);
				}
			});
	
			return $defer;
		}
	};
	
	module.exports = API;
});;
define('widget/search', function(require, exports, module){
	var api = require('common/api');
	
	/**
	 * @param {String} [searchVal] [搜索关键词]
	 */
	function Search(opts) {
	    this.opts = opts || {};
	    
	    // this.template = _.template(__inline('./search.html'));
	    this.templateSearchList = _.template("<% if( data.length ) {%>\r\n<ul class=\"w-search-result\">\r\n    <% _.each(data, function(obj, index) { %>\r\n    <li class=\"w-search-result-value\" data-value=\"<%= obj.item %>\">\r\n    \t<% if( obj.plat ) { %>\r\n    \t<img src=\"<%= ZBB.platformDefaultAvatar[obj.plat] %>\">\r\n    \t<% } %>\r\n    \t<a href=\"javascript:;\"><%= obj.replaceItem %></a>\r\n    </li>\r\n    <% }) %>\r\n</ul>\r\n<% } %>");
	
	    // this.$el = $('<div class="w-search" id="w-search"></div>');
	    if (this.opts.$dom && this.opts.$dom.length) {
	        this.$el = this.opts.$dom.find('.w-search');
	    } else {
	        this.$el = $('.w-search');
	    }
	    this.params = {
	        'isPagination': false,
	        search: this.opts.search,
	        size: 10
	    };
	    this.init();
	}
	Search.prototype.render = function() {
	    // var self = this;
	    // this.$el.html(self.template());
	};
	Search.prototype.init = function() {
	    this.render();
	    this.bindEvent();
	};
	Search.prototype.getData = function(data) {
	    $.extend(this.params, data);
	    var self = this,
	        path = 'search';
	    api.get(path, this.params).done(function(data) {
	        if (data.code == 0) {
	            var arr = [];
	            $.each(data.data.list, function(index, item) {
	                // 同时替换大小写
	                var arrMatch = item.nickname.match(eval('/' + self.params.search + '/gi'));
	                var replaceItem = item.nickname;
	                $.each(arrMatch, function(i, n) {
	                    replaceItem = replaceItem.replace(eval('/' + n + '/g'), '<i class="replaceItem">' + n + '</i>');
	                });
	
	                arr.push({
	                    item: item.nickname,
	                    replaceItem: replaceItem,
	                    plat: item.plat
	                });
	            });
	            self.$el.find('.js_w-search_list').html(self.templateSearchList({
	                'data': arr
	            }));
	        }
	    });
	};
	
	Search.prototype.bindEvent = function() {
	    var self = this;
	    //搜索点击
	    this.$el.find(".w-icon_search").on("click", function() {
	        self.params.search = $(this).next().val();
	        if (!self.params.search) return;
	        self.$el.find("input").val("");
	        if (self.opts.flag == 'search') {
	
	            self.$el.find('.js_w-search_list').hide();
	            $.pub('search/getResult', [{
	                isPagination: false,
	                page: 1,
	                search: self.params.search
	            }]);
	        } else {
	            window.open("/search?search=" + self.params.search)
	        }
	
	    });
	
	    //搜索结果点击
	    self.$el.find('.js_w-search_list').on("click", ".w-search-result-value", function() {
	        self.params.search = $(this).data('value');
	        if (self.opts.flag == 'search') {
	            self.$el.find("input").val("");
	            self.$el.find('.js_w-search_list').hide();
	            $.pub('search/getResult', [{
	                isPagination: false,
	                page: 1,
	                search: self.params.search
	            }]);
	        } else {
	            // location.href = "/search?search=" + self.params.search;
	            window.open("/search?search=" + self.params.search)
	        }
	    });
	    // 输入框请求
	    this.$el.find("input").on("keyup",
	        _.debounce(function(event) {
	            var code = event.which || event.keyCode,
	                val = $(this).val();
	            if (!val) {
	                self.$el.find('.js_w-search_list').hide();
	                return;
	            }
	            if (code == 37 || code == 38 || code == 39 || code == 40) return;
	            self.$el.find('.js_w-search_list').show();
	            self.params.search = $(this).val();
	            if (code == 13) {
	                self.$el.find("input").val("");
	                self.$el.find('.js_w-search_list').hide();
	                if (self.$el.find(".w-search-result-value").hasClass("active")) {
	                    self.params.search = self.$el.find(".active").data("value");
	                }
	                if (self.opts.flag == 'search') {
	                    self.$el.find('.js_w-search_list').hide();
	                    $.pub('search/getResult', [{
	                        isPagination: false,
	                        page: 1,
	                        search: self.params.search
	                    }]);
	                } else {
	                    window.open("/search?search=" + self.params.search)
	                }
	            } else {
	                self.getData({
	                    search: self.params.search
	                });
	            }
	        }, 300));
	    this.$el.find("input").on("keydown", function(event) {
	        var $this = $(this);
	        var code = event.which || event.keyCode;
	        if (code == 38) { //上
	            if ($this.next().find(".w-search-result-value").hasClass("active")) {
	                if (!$this.next().find(".w-search-result-value").prev()) {
	                    $this.next().find(".w-search-result-value").first().addClass("active");
	                } else {
	                    $this.next().find(".active").removeClass("active").prev().addClass("active");
	                }
	            } else {
	                $this.next().find(".w-search-result-value").first().addClass("active");
	            }
	        } else if (code == 40) { //下
	            if ($this.next().find(".w-search-result-value").hasClass("active")) {
	
	                if (!$this.next().find(".w-search-result-value").next()) {
	                    $this.next().find(".w-search-result-value").first().addClass("active");
	                } else {
	                    $this.next().find(".active").removeClass("active").next().addClass("active");
	                }
	            } else {
	                $this.next().find(".w-search-result-value").first().addClass("active");
	            }
	        }
	    });
	    $('body').click(function(e) {
	        if ($(e.target).closest("#w-search").length == 0) {
	            self.$el.find('.js_w-search_list').hide();
	        }
	    });
	    return this;
	};
	
	module.exports = Search;
});;
define('widget/header', function(require, exports, module){
	var Search = require("widget/search");
	
	function Header(pageType) {
		// if (window.location.hostname == 'www.zhibobao.com') {
		// 	this.template = _.template(__inline('./header.html'));
		// } else {
		// 	this.template = _.template(__inline('./header_tv.html'));
		// }
	
		this.pageType = pageType;
		// if (pageType == 'index') {
		// 	this.$el = $('<div class="w-header w-header-index"></div>');
		// } else {
		// 	this.$el = $('<div class="w-header"></div>');
		// }
		
		this.init();
	};
	
	Header.prototype.init = function() {
		this.render();
		this.bindEvent();
	};
	Header.prototype.render = function() {
		// this.$el.html(this.template());
	
		// var $head_nav = this.$el.find('.w-header_nav');
	
		// var pathname = location.pathname;
	
		// if (window.location.hostname == 'www.zhibobao.com') {
		// 	if (pathname == '/static/boot/main/main.html' || pathname == '/') {
		// 		$head_nav.find('[data-page="home"]').addClass('active');
		// 	} else if (pathname == '/static/boot/rank/rank.html' || pathname == '/rank') {
		// 		$head_nav.find('[data-page="rank"]').addClass('active');
		// 	} else if (pathname == '/static/boot/platform/platform.html' || pathname == '/platform') {
		// 		$head_nav.find('[data-page="platform"]').addClass('active');
		// 	} else if (pathname == '/static/boot/tool/tool.html' || pathname == '/tool') {
		// 		$head_nav.find('[data-page="tool"]').addClass('active');
		// 	}
		// } else {
		// 	if (pathname == '/static/boot/main/main.html' || pathname == '/data') {
		// 		$head_nav.find('[data-page="home"]').addClass('active');
		// 	} else if (pathname == '/static/boot/rank/rank.html' || pathname == '/rank') {
		// 		$head_nav.find('[data-page="rank"]').addClass('active');
		// 	} else if (pathname == '/static/boot/platform/platform.html' || pathname == '/platform') {
		// 		$head_nav.find('[data-page="platform"]').addClass('active');
		// 	} else if (pathname == '/static/boot/tool/tool.html' || pathname == '/') {
		// 		$head_nav.find('[data-page="tool"]').addClass('active');
		// 	}
		// }
		
		this.$el = $('.w-header');
		if (this.pageType == 'search') {
	
		} else {
			this.search = new Search();
			// this.$el.find('.js-w-header_search').html(this.search.$el);
		}
	
		return this;
	};
	Header.prototype.bindEvent = function() {
		var self = this;
	
		$(document).scroll(function() {
			var h = $(this).scrollTop();
			if (h > 0) {
				self.$el.addClass('w-header-scroll');
			} else {
				self.$el.removeClass('w-header-scroll');
			}
		});
	
		this.$el.find(".w-header_nav_link_warp a").on("click", function() {
			if($(this).attr('target') == '_blank') {
				return;
			}
	
			$(this).parent().addClass("active").siblings().removeClass('active');
			if ($(this).data('page') == "tool") {
				self.$el.parent().addClass('w-header-new');
			} else {
				self.$el.parent().removeClass('w-header-new');
			}
		});
		return this;
	};
	
	Header.prototype.activeNav = function(index) {
		var $list = this.$el.find('.w-header_nav_link_warp');
		$list.removeClass('active');
		$list.eq(index).addClass('active');
	
		if (index === 0) {
			this.$el.addClass('w-header-index');
		} else {
			this.$el.removeClass('w-header-index');
		}
	};
	
	module.exports = Header;
});;
define('widget/footer', function(require, exports, module){
	function Footer() {
	
	    // if( window.location.hostname == 'www.zhibobao.com' ){
	    //     this.template = _.template(__inline('./footer.html'));
	    // }else{
	    //     this.template = _.template(__inline('./footer_tv.html'));
	    // }
	    // this.$el = $('<div class="w-footer"></div>');
	
	    // this.init();
	};
	
	// Footer.prototype.init = function() {
	//     this.render();
	//     this.bindEvent();
	// };
	// Footer.prototype.render = function() {
	//     this.$el.html(this.template());
	
	//     return this;
	// };
	// Footer.prototype.bindEvent = function() {
	//     var self = this;
	
	//     return this;
	// };
	
	module.exports = Footer;
});;
define('widget/searchResult', function(require, exports, module){
	var api = require('common/api');
	
	/**
	 * @param {String} [searchVal] [搜索关键词]
	 * @param {Number} [page_num] [搜索的页数]
	 */
	function SearchResult(opts) {
	    this.template = _.template("<div class=\"search-result-title\">搜索结果 <span>总共为您搜索到关于“ <i class=\"search-name text-able-select\"><%=obj.search %></i> ”的 <i class=\"search-result-num\"><%=obj.total %></i> 个结果</span> </div>\r\n\r\n<ul class=\"w-searchResult clearfix\">\r\n    <% _.each(obj.list, function(item, index) { %>\r\n    <li class=\"w-searchResult-list\">\r\n        <div calss=\"w-searchResult-avatar fl\">\r\n            <img src=\"<%= ZBB.parseAvatar(item.avatar) %>\" onerror=\"this.src='<%= ZBB.platformDefaultAvatar.default %>';\">\r\n        </div>\r\n        <div class=\"w-searchResult-info fl\">\r\n            <p class=\"w-searchResult-info_nickname text-able-select\"><%=item.nickname %></p>\r\n            <p>\r\n                <span class=\"w-searchResult-info_platform fl\"><%= ZBB.platformName[item.plat] %></span>\r\n                <% if( item.cateName ) {%>\r\n                <span class=\"w-searchResult-info_category fl\"><%=item.cateName %></span>\r\n                <% } %>\r\n            </p>\r\n            <% if( item.follow > -1 ) {%>\r\n            <p class=\"text-able-select\">\r\n                粉丝数: <span><%=item.follow %></span>\r\n            </p>\r\n            <% } %>\r\n        </div>\r\n        <div class=\"w-searchResult-btn fr\">\r\n            <a href=\"/anchor?roomId=<%=item.roomId %>&platform=<%=item.plat %>\" target=\"_blank\">查看</a>\r\n        </div>\r\n    </li>\r\n    <% }) %>\r\n</ul>");
	    this.$el = $('<div id="container"></div>');
	    this.opts = opts || {};
	    this.params = {
	        page: this.opts.page || 1,
	        search: this.opts.search,
	        size:this.opts.size || 15
	    };
	    this.init();
	
	}
	SearchResult.prototype.render = function(data) {
	    this.$el.html(this.template({
	        'obj': data.data
	    }));
	};
	SearchResult.prototype.init = function() {
	    this.getData();
	};
	SearchResult.prototype.getData = function(data) {
	    $.extend(this.params, data);
	    if (!this.params.search) {
	        this.$el.html( '<p class="default">(｢･ω･)｢嘿，请按套路来</p>' );
	        return;
	    }
	    var self = this,
	        path = 'search';
	    api.get(path, this.params).done(function(data) {
	
	        if (data.code == 0) {
	            data.data.search= self.params.search;
	            self.render({
	                data: data.data
	            });
	            if( self.params.isPagination )return;
	            $.pub('page/change', [{
	                "page": Math.ceil( Number( data.data.total / self.params.size  ) ),
	                "search": self.params.search,
	                "current_page":1
	            }]);
	        }else{
	            self.$el.html( '<p class="default">服务繁忙，请稍后重试</p>' );
	            $.pub('page/change', [{"page": 0}]);
	        }
	    }).fail(function(data) {
	        self.$el.html( '<p class="default">服务繁忙，请稍后重试</p>' );
	        $.pub('page/change', [{"page": 0}]);
	    });
	};
	
	module.exports = SearchResult;
});;
define('widget/pagination', function(require, exports, module){
	function Pagination(opts) {
		this.template = _.template("<% if( page_obj.page > 1 ) { %>\r\n     <span class=\"w-searchResult-first <%= page_obj.current_page == 1 ? 'disable' : '' %>\">首页</span>\r\n     <span class=\"w-searchResult-prev <%= page_obj.current_page == 1 ? 'disable' : '' %>\">上一页</span>\r\n     <% if( page_obj.limit > 5 ) { %>\r\n     <span class=\"w-searchResult-prev-ellipsis\">...</span>\r\n     <% } %>\r\n     <% _.each(page_obj.page_arr, function(item, index) { %>\r\n     <i data-value=\"<%=item %>\" class=\"<%= item == page_obj.current_page ? 'active' : '' %>\" ><%=item %></i>\r\n     <% }) %>\r\n     <% if( page_obj.page > 5 && page_obj.page > page_obj.limit ) { %>\r\n     <span class=\"w-searchResult-next-ellipsis\">...</span>\r\n     <% } %>\r\n     <span class=\"w-searchResult-next  <%= page_obj.current_page == page_obj.page_num ? 'disable' : '' %>\">下一页</span>\r\n     <span class=\"w-searchResult-last  <%= page_obj.current_page == page_obj.page_num ? 'disable' : '' %>\">末页</span>\r\n<% } %>");
		this.$el = $( "<div class='w-pagination'></div>" );
		this.opts = opts || {};
		this.params = {
	        page : this.opts.page || 1,
	        current_page:this.opts.current_page||1,
	        search:this.opts.search
		};
	    this.limit = 0;
		this.init({});
		this.bindEvent();
	};
	
	Pagination.prototype.init = function(data) {
	    var self =this;
	    // if( self.params.search == data.search && self.params.page == data.page )return;//换页时不更新分页
		$.extend( this.params , data );
	    var obj = {},page_arr = [];
	    self.limit = this.params.page > 5 ? (this.params.current_page > 1 ? (  this.params.page - this.params.current_page > 5 ? (this.params.current_page + 4) : this.params.page) : 5) : this.params.page;
	    for( var i =this.params.current_page; i <= self.limit ; i++ ){
	        page_arr.push( i );
	    }
	    if( data.special ){
	        var active = this.limit;
	        $.pub('search/getResult', [{
	            'isPagination':true,
	            "page":active
	        }])
	    }else{
	        var active = this.params.current_page
	    }
	    this.render(({
	        page_arr:page_arr,
	        page:this.params.page,
	        limit:this.limit,
	        current_page:active
	    }));
	};
	Pagination.prototype.render = function(obj) {
		this.$el.html(this.template({
			"page_obj":obj
		}));
		return this;
	};
	Pagination.prototype.bindEvent = function() {
		var self = this;
		self.$el.on('click','i',function () {
			var $this = $(this);
			if( $this.hasClass("active") )return;
			// 前后非数字按钮显示、隐藏
			if( $this.data("value") == "1" ){
	            $(".w-searchResult-first,.w-searchResult-prev").addClass("disable");
	            $(".w-searchResult-last,.w-searchResult-next").removeClass("disable");
			}else if( $this.data("value") == self.params.page  ){
	            $(".w-searchResult-last,.w-searchResult-next").addClass("disable");
	            $(".w-searchResult-first,.w-searchResult-prev").removeClass("disable");
	        }else{
	            $(".w-searchResult-last,.w-searchResult-next,.w-searchResult-first,.w-searchResult-prev").removeClass("disable");
			}
	        $this.addClass("active").siblings().removeClass("active");
	        $.pub('search/getResult', [{
	            'isPagination':true,
	        	"page":$this.data("value")
			}])
	    });
	    //首页点击
	    self.$el.on('click','.w-searchResult-first',function () {
	        if( $(this).hasClass("disable") )return;
	        if( self.limit > 5 ){
	            //    重新渲染
	            self.init({current_page:1});
	            $.pub('search/getResult', [{
	                'isPagination':true,
	                "page":1
	            }]);
	            return;
	        }
	        $(".w-searchResult-first,.w-searchResult-prev").addClass("disable");
	        $(".w-searchResult-last,.w-searchResult-next").removeClass("disable");
	        $(".w-searchResult-prev-ellipsis").css("display","none");
	        self.$el.find('[data-value="1"]').addClass("active").siblings().removeClass("active");
	        $.pub('search/getResult', [{
	            'isPagination':true,
	            "page":1
	        }])
	    });
	    //末页点击
	    self.$el.on('click','.w-searchResult-last',function () {
	        if( $(this).hasClass("disable") )return;
	        if( self.limit < self.params.page ){
	        //    重新渲染
	            var mod = self.params.page % 5;
	            if( mod ){
	                self.init({current_page:self.params.page - mod + 1,special:"lastpage"});
	            }else{
	                self.init({current_page:self.params.page - 4 ,special:"lastpage"});
	            }
	            return;
	        }
	        $(".w-searchResult-last,.w-searchResult-next").addClass("disable");
	        $(".w-searchResult-first,.w-searchResult-prev").removeClass("disable");
	        self.$el.find('[data-value="' + self.limit + '"]').addClass("active").siblings().removeClass("active");
	        $.pub('search/getResult', [{
	            'isPagination':true,
	            "page":self.limit
	        }])
	    });
	
	    //上一页点击
	    self.$el.on('click','.w-searchResult-prev',function () {
	        if( $(this).hasClass("disable") )return;
	        var val = self.$el.find(".active").data( "value" );
	        if( val == "2" ){
	            self.$el.find('[data-value="1"]').addClass("active").siblings().removeClass("active");
	            $(".w-searchResult-first,.w-searchResult-prev").addClass("disable");
	            $(".w-searchResult-prev-ellipsis").css("display","none");
	        }else if( val == self.params.current_page && val != '1'){
	            //重新渲染
	            self.init({current_page:self.params.current_page-5,special:"lastpage"});
	            return;
	        }else{
	            $(".w-searchResult-last,.w-searchResult-next").removeClass("disable");
	            self.$el.find('.active').prev().addClass("active").siblings().removeClass("active");
	        }
	        $.pub('search/getResult', [{
	            'isPagination':true,
	            "page":self.$el.find('.active').data("value")
	        }])
	    });
	
	    //下一页点击
	    self.$el.on('click','.w-searchResult-next',function () {
	        if( $(this).hasClass("disable") )return;
	        var val = self.$el.find(".active").data( "value" );
	        if( val == self.params.page - 1 ){
	            $(".w-searchResult-last,.w-searchResult-next").addClass("disable");
	            self.$el.find('[data-value="' + self.limit + '"]').addClass("active").siblings().removeClass("active");
	            $(".w-searchResult-next-ellipsis").css("display","none");
	        }else if( val == self.limit && self.limit < self.params.page ){
	            // 重新渲染
	            self.init({current_page:self.params.current_page+5});
	            $.pub('search/getResult', [{
	                "page":self.params.current_page
	            }])
	            return;
	        }else{
	            $(".w-searchResult-first,.w-searchResult-prev").removeClass("disable");
	            self.$el.find('.active').next().addClass("active").siblings().removeClass("active");
	        }
	        $.pub('search/getResult', [{
	            'isPagination':true,
	            "page":self.$el.find('.active').data("value")
	        }])
	    });
	
	    //上一页省略点击
	    self.$el.on('click','.w-searchResult-prev-ellipsis',function () {
	        self.init({current_page:self.params.current_page-5,special:"lastpage"});
	    });
	
	    //下一页省略点击
	    self.$el.on('click','.w-searchResult-next-ellipsis',function () {
	        self.init({current_page:self.params.current_page+5});
	        $.pub('search/getResult', [{
	            'isPagination':true,
	            "page":self.params.current_page
	        }])
	    });
		return this;
	};
	module.exports = Pagination;
});;
define(function(require) {
    // 302
    var MOBILE_UA_REGEXP = /(iPhone|iPod|Android|ios|iOS|iPad|Backerry|WebOS|Symbian|Windows Phone|Phone|Prerender|MicroMessenger)/i;
    if (MOBILE_UA_REGEXP.test(navigator.userAgent)) {
        var pathname = location.pathname;
        var search = location.search;
        window.location.replace(ZBB.mDomain + pathname + search);
        return;
    }

    var Header = require('widget/header');
    var Footer = require('widget/footer');
    var Search = require("widget/search");
    var SearchResult = require("widget/searchResult");
    var Pagination = require("widget/pagination");

    var $body = $('body');
    var $main_search = $body.find('.main-search');
    var $main_body = $body.find('.main-body');

    var oPage = {
        init: function() {
            var urlRequestParams = ZBB.urlRequestParams();
            if (urlRequestParams['search']) {
                this.search = decodeURIComponent(urlRequestParams['search']);
            }
            this.render();
            this.bindEvent();
        },
        render: function() {
            var header = new Header('search');
            header.$el.addClass("w-header-new");
            $('.main-header').append(header.$el);

            var footer = new Footer();
            $('.main-footer').append(footer.$el);

            this.searchCons = new Search({
                search: this.search,
                flag: 'search'
            });
            $main_search.html(this.searchCons.$el);

            this.searchResult = new SearchResult({
                isPagination: true,
                search: this.search
            });
            $main_body.prepend(this.searchResult.$el);

            this.pagination = new Pagination();
            $main_body.append(this.pagination.$el);
        },
        bindEvent: function() {
            var self = this;
            $.sub('page/change', function(e, data) {
                self.pagination.init(data);
            });
            $.sub('search/getResult', function(e, data) {
                self.searchResult.getData(data);
            });
        }

    };

    oPage.init();



});