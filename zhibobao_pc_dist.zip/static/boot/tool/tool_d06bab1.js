define('common/apiExpire', function(require, exports, module){
	function localSign() {
		var key = 'GapV#&2%b';
		var timestamp = new Date().getTime();
		var val = md5(timestamp + key);
		return {
			'sign': val,
			'timestamp': timestamp
		};
	}
	
	module.exports = localSign;
});;
define('common/api', function(require, exports, module){
	var LocalSign = require('common/apiExpire');
	
	var REQUEST_TIMEOUT = 20000;
	
	var API_PREFIX = '/api/';
	
	
	function getApiUrl(path) {
		if (/\.\.*\//.test(path) || /http/.test(path)) {
			return path;
		} else {
			return API_PREFIX + path;
		}
	    console.log(path);
	}
	var API = {
		get: function(path, data, callback) {
			var localSign = LocalSign();
			data = $.extend({}, data, {
				'_timestamp': localSign.timestamp,
				'source': 0
			});
			var $defer = $.Deferred();
	
			$.ajax({
				type: 'get',
				url: getApiUrl(path),
				data: data,
				dataType: 'json',
				headers: {
					'T-code': localSign.sign
				},
				crossDomain: true,
				xhrFields: {
					withCredentials: true
				},
				timeout: REQUEST_TIMEOUT,
				success: function(data) {
					typeof(callback) == 'function' && callback(data);
	                if (data) {
						$defer.resolve(data);
					} else {
						$defer.reject();
					}
				},
				error: function(xhr, state) {
	                console.log(state);
					typeof(callback) == 'function' && callback(state);
					$defer.reject(state);
				}
			});
			return $defer;
		},
		post: function(path, data, callback) {
			var timestamp = LocalSign();
			data = $.extend({}, data, {
				'_timestamp': localSign.timestamp,
				'source': 0
			});
			var $defer = $.Deferred();
	
			$.ajax({
				type: 'post',
				url: getApiUrl(path),
				data: data,
				dataType: 'json',
				headers: {
					'T-code': localSign.sign
				},
				crossDomain: true,
				xhrFields: {
					withCredentials: true
				},
				timeout: REQUEST_TIMEOUT,
				success: function(data) {
					typeof(callback) == 'function' && callback(data);
	
					if (data) {
						$defer.resolve(data);
					} else {
						$defer.reject();
					}
				},
				error: function(xhr, state) {
					typeof(callback) == 'function' && callback(state);
					$defer.reject(state);
				}
			});
	
			return $defer;
		}
	};
	
	module.exports = API;
});;
define('widget/search', function(require, exports, module){
	var api = require('common/api');
	
	/**
	 * @param {String} [searchVal] [搜索关键词]
	 */
	function Search(opts) {
	    this.opts = opts || {};
	    
	    // this.template = _.template(__inline('./search.html'));
	    this.templateSearchList = _.template("<% if( data.length ) {%>\r\n<ul class=\"w-search-result\">\r\n    <% _.each(data, function(obj, index) { %>\r\n    <li class=\"w-search-result-value\" data-value=\"<%= obj.item %>\">\r\n    \t<% if( obj.plat ) { %>\r\n    \t<img src=\"<%= ZBB.platformDefaultAvatar[obj.plat] %>\">\r\n    \t<% } %>\r\n    \t<a href=\"javascript:;\"><%= obj.replaceItem %></a>\r\n    </li>\r\n    <% }) %>\r\n</ul>\r\n<% } %>");
	
	    // this.$el = $('<div class="w-search" id="w-search"></div>');
	    if (this.opts.$dom && this.opts.$dom.length) {
	        this.$el = this.opts.$dom.find('.w-search');
	    } else {
	        this.$el = $('.w-search');
	    }
	    this.params = {
	        'isPagination': false,
	        search: this.opts.search,
	        size: 10
	    };
	    this.init();
	}
	Search.prototype.render = function() {
	    // var self = this;
	    // this.$el.html(self.template());
	};
	Search.prototype.init = function() {
	    this.render();
	    this.bindEvent();
	};
	Search.prototype.getData = function(data) {
	    $.extend(this.params, data);
	    var self = this,
	        path = 'search';
	    api.get(path, this.params).done(function(data) {
	        if (data.code == 0) {
	            var arr = [];
	            $.each(data.data.list, function(index, item) {
	                // 同时替换大小写
	                var arrMatch = item.nickname.match(eval('/' + self.params.search + '/gi'));
	                var replaceItem = item.nickname;
	                $.each(arrMatch, function(i, n) {
	                    replaceItem = replaceItem.replace(eval('/' + n + '/g'), '<i class="replaceItem">' + n + '</i>');
	                });
	
	                arr.push({
	                    item: item.nickname,
	                    replaceItem: replaceItem,
	                    plat: item.plat
	                });
	            });
	            self.$el.find('.js_w-search_list').html(self.templateSearchList({
	                'data': arr
	            }));
	        }
	    });
	};
	
	Search.prototype.bindEvent = function() {
	    var self = this;
	    //搜索点击
	    this.$el.find(".w-icon_search").on("click", function() {
	        self.params.search = $(this).next().val();
	        if (!self.params.search) return;
	        self.$el.find("input").val("");
	        if (self.opts.flag == 'search') {
	
	            self.$el.find('.js_w-search_list').hide();
	            $.pub('search/getResult', [{
	                isPagination: false,
	                page: 1,
	                search: self.params.search
	            }]);
	        } else {
	            window.open("/search?search=" + self.params.search)
	        }
	
	    });
	
	    //搜索结果点击
	    self.$el.find('.js_w-search_list').on("click", ".w-search-result-value", function() {
	        self.params.search = $(this).data('value');
	        if (self.opts.flag == 'search') {
	            self.$el.find("input").val("");
	            self.$el.find('.js_w-search_list').hide();
	            $.pub('search/getResult', [{
	                isPagination: false,
	                page: 1,
	                search: self.params.search
	            }]);
	        } else {
	            // location.href = "/search?search=" + self.params.search;
	            window.open("/search?search=" + self.params.search)
	        }
	    });
	    // 输入框请求
	    this.$el.find("input").on("keyup",
	        _.debounce(function(event) {
	            var code = event.which || event.keyCode,
	                val = $(this).val();
	            if (!val) {
	                self.$el.find('.js_w-search_list').hide();
	                return;
	            }
	            if (code == 37 || code == 38 || code == 39 || code == 40) return;
	            self.$el.find('.js_w-search_list').show();
	            self.params.search = $(this).val();
	            if (code == 13) {
	                self.$el.find("input").val("");
	                self.$el.find('.js_w-search_list').hide();
	                if (self.$el.find(".w-search-result-value").hasClass("active")) {
	                    self.params.search = self.$el.find(".active").data("value");
	                }
	                if (self.opts.flag == 'search') {
	                    self.$el.find('.js_w-search_list').hide();
	                    $.pub('search/getResult', [{
	                        isPagination: false,
	                        page: 1,
	                        search: self.params.search
	                    }]);
	                } else {
	                    window.open("/search?search=" + self.params.search)
	                }
	            } else {
	                self.getData({
	                    search: self.params.search
	                });
	            }
	        }, 300));
	    this.$el.find("input").on("keydown", function(event) {
	        var $this = $(this);
	        var code = event.which || event.keyCode;
	        if (code == 38) { //上
	            if ($this.next().find(".w-search-result-value").hasClass("active")) {
	                if (!$this.next().find(".w-search-result-value").prev()) {
	                    $this.next().find(".w-search-result-value").first().addClass("active");
	                } else {
	                    $this.next().find(".active").removeClass("active").prev().addClass("active");
	                }
	            } else {
	                $this.next().find(".w-search-result-value").first().addClass("active");
	            }
	        } else if (code == 40) { //下
	            if ($this.next().find(".w-search-result-value").hasClass("active")) {
	
	                if (!$this.next().find(".w-search-result-value").next()) {
	                    $this.next().find(".w-search-result-value").first().addClass("active");
	                } else {
	                    $this.next().find(".active").removeClass("active").next().addClass("active");
	                }
	            } else {
	                $this.next().find(".w-search-result-value").first().addClass("active");
	            }
	        }
	    });
	    $('body').click(function(e) {
	        if ($(e.target).closest("#w-search").length == 0) {
	            self.$el.find('.js_w-search_list').hide();
	        }
	    });
	    return this;
	};
	
	module.exports = Search;
});;
define('widget/header', function(require, exports, module){
	var Search = require("widget/search");
	
	function Header(pageType) {
		// if (window.location.hostname == 'www.zhibobao.com') {
		// 	this.template = _.template(__inline('./header.html'));
		// } else {
		// 	this.template = _.template(__inline('./header_tv.html'));
		// }
	
		this.pageType = pageType;
		// if (pageType == 'index') {
		// 	this.$el = $('<div class="w-header w-header-index"></div>');
		// } else {
		// 	this.$el = $('<div class="w-header"></div>');
		// }
		
		this.init();
	};
	
	Header.prototype.init = function() {
		this.render();
		this.bindEvent();
	};
	Header.prototype.render = function() {
		// this.$el.html(this.template());
	
		// var $head_nav = this.$el.find('.w-header_nav');
	
		// var pathname = location.pathname;
	
		// if (window.location.hostname == 'www.zhibobao.com') {
		// 	if (pathname == '/static/boot/main/main.html' || pathname == '/') {
		// 		$head_nav.find('[data-page="home"]').addClass('active');
		// 	} else if (pathname == '/static/boot/rank/rank.html' || pathname == '/rank') {
		// 		$head_nav.find('[data-page="rank"]').addClass('active');
		// 	} else if (pathname == '/static/boot/platform/platform.html' || pathname == '/platform') {
		// 		$head_nav.find('[data-page="platform"]').addClass('active');
		// 	} else if (pathname == '/static/boot/tool/tool.html' || pathname == '/tool') {
		// 		$head_nav.find('[data-page="tool"]').addClass('active');
		// 	}
		// } else {
		// 	if (pathname == '/static/boot/main/main.html' || pathname == '/data') {
		// 		$head_nav.find('[data-page="home"]').addClass('active');
		// 	} else if (pathname == '/static/boot/rank/rank.html' || pathname == '/rank') {
		// 		$head_nav.find('[data-page="rank"]').addClass('active');
		// 	} else if (pathname == '/static/boot/platform/platform.html' || pathname == '/platform') {
		// 		$head_nav.find('[data-page="platform"]').addClass('active');
		// 	} else if (pathname == '/static/boot/tool/tool.html' || pathname == '/') {
		// 		$head_nav.find('[data-page="tool"]').addClass('active');
		// 	}
		// }
		
		this.$el = $('.w-header');
		if (this.pageType == 'search') {
	
		} else {
			this.search = new Search();
			// this.$el.find('.js-w-header_search').html(this.search.$el);
		}
	
		return this;
	};
	Header.prototype.bindEvent = function() {
		var self = this;
	
		$(document).scroll(function() {
			var h = $(this).scrollTop();
			if (h > 0) {
				self.$el.addClass('w-header-scroll');
			} else {
				self.$el.removeClass('w-header-scroll');
			}
		});
	
		this.$el.find(".w-header_nav_link_warp a").on("click", function() {
			if($(this).attr('target') == '_blank') {
				return;
			}
	
			$(this).parent().addClass("active").siblings().removeClass('active');
			if ($(this).data('page') == "tool") {
				self.$el.parent().addClass('w-header-new');
			} else {
				self.$el.parent().removeClass('w-header-new');
			}
		});
		return this;
	};
	
	Header.prototype.activeNav = function(index) {
		var $list = this.$el.find('.w-header_nav_link_warp');
		$list.removeClass('active');
		$list.eq(index).addClass('active');
	
		if (index === 0) {
			this.$el.addClass('w-header-index');
		} else {
			this.$el.removeClass('w-header-index');
		}
	};
	
	module.exports = Header;
});;
define('widget/footer', function(require, exports, module){
	function Footer() {
	
	    // if( window.location.hostname == 'www.zhibobao.com' ){
	    //     this.template = _.template(__inline('./footer.html'));
	    // }else{
	    //     this.template = _.template(__inline('./footer_tv.html'));
	    // }
	    // this.$el = $('<div class="w-footer"></div>');
	
	    // this.init();
	};
	
	// Footer.prototype.init = function() {
	//     this.render();
	//     this.bindEvent();
	// };
	// Footer.prototype.render = function() {
	//     this.$el.html(this.template());
	
	//     return this;
	// };
	// Footer.prototype.bindEvent = function() {
	//     var self = this;
	
	//     return this;
	// };
	
	module.exports = Footer;
});;
define(function(require) {
    var api = require('common/api');
    var Header = require('widget/header');
    var Footer = require('widget/footer');


    var update_content = [
        {
            version:"V1.24.6",
            update_item:[
                {
                    title:"修复：Win7 安装兼容问题",
                },
                {
                    title:"修复：麦克风声音太小",
                },
                {
                    title:"修复：设置-设备 展示错误",
                },
                {
                    title:"修复：添加采集源时点取消后采集源仍然被保存",
                },
                {
                    title:"修复：防窥屏延迟设置不生效",
                },
                {
                    title:"新增：默认关闭 Win7 Aero 效果",
                },
                {
                    title:"优化：优化弹幕显示",
                },
            ]
        },
        {
            version:"V1.25.1",
            update_item:[
                {
                    title:"修复：添加多个游戏源直播宝无响应卡死",
                },
                {
                    title:"修复：同步录制视频有些情况下无法保存",
                },
                {
                    title:"修复：重置推流秘钥后可能导致推流失败",
                },
                {
                    title:"修复：开始直播按钮状态和文件显示错乱",
                },
                {
                    title:"新增：手机验证码登录功能（第三方登录）",
                },
                {
                    title:"优化：开始直播按钮 UI 交互",
                },
                {
                    title:"优化：同步录播开关 UI 交互",
                },
                {
                    title:"优化：设计界面 UI 交互",
                },
                {
                    title:"优化：非 Win7 系统隐藏 Aero 设置项",
                },
            ]
        },
        {
            version:"V1.26.0",
            update_item:[
                {
                    title:"新增：弹幕礼物面板",
                    des:[
                        "可以显示直播间弹幕和礼物信息","可以灵活移动弹幕面板位置和大小","可以灵活设置弹幕面板透明度","可以灵活设置贵宾弹幕等级"
                    ]
                },
                {
                    title:"新增：崩溃信息自动上报",
                },
                {
                    title:"修复：关闭赏金结算页面可能导致直播宝关闭",
                },
                {
                    title:"修复：弹幕插件热更新有几率不能下载成功",
                },
                {
                    title:"修复：一些其他异常和崩溃问题",
                },
                {
                    title:"优化：整体 UI 交互体验",
                }
            ]
        },
        {
            version:"V1.27.1",
            update_item:[
                {
                    title:"新增：直播宝模板，方便一键配置与直播",
                },
                {
                    title:"新增：新手开播引导",
                },
                {
                    title:"新增：直播环境检测与推流设置",
                },
                {
                    title:"新增：直播推流状态监控与一键优化",
                },
                {
                    title:"修复：若干异常和崩溃问题",
                },
                {
                    title:"优化：整体 UI 交互体验",
                }
            ]
        },
        {
            version:"V1.27.3",
            update_item:[
                {
                    title:"修复：少数用户模板选择界面画面为空",
                },
                {
                    title:"修复：开播环境检崩溃",
                },
                {
                    title:"修复：直播同步录制开关失效",
                },
                {
                    title:"修复：Win7 关闭 Aero（隐藏 QQ）功能失效",
                }
            ]
        },
        {
            version:"V1.28.0",
            update_item:[
                {
                    title:"直播宝终于支持万众期待的美颜功能了，效果拔群哦",
                },
                {
                    title:"麦克风最大支持增强到300%，音量小，听不到？不存在的",
                },
                {
                    title:"简化文字添加功能",
                },
                {
                    title:"优化托盘图标点击行为",
                },
                {
                    title:"删除元素新增快捷键-Delete",
                },
                {
                    title:"若干优化和问题修复",
                }
            ]
        },
        {
            version:"V1.28.3",
            update_item:[
                {
                    title:"修复崩溃问题",
                }
            ]
        },
        {
            version:"V1.29.1",
            update_item:[
                {
                    title:"更改了推流配置（兼容全民新的推流秘钥格式），旧版两周后不能直播，大家务必下载新版本更新",
                },
                {
                    title:"新增直播小结功能（直播超过半小时后，下播时自动弹出），这“播”亏不亏，一看就知道~",
                },
                {
                    title:"弹幕增加直播环境显示，实时监控直播效果",
                },
                {
                    title:"若干问题修复及细节优化",
                }
            ]
        },
        {
            version:"V2.0.1",
            update_item:[
                {
                    title:"新增直播宝独立帐号",
                },
                {
                    title:"支持斗鱼及自定义推流地址",
                },
                {
                    title:"弹幕标签样式更新",
                },
                {
                    title:"弹幕设置更加丰富（可自定义标签显示）",
                }
            ]
        }

    ];
    var oPage = {
        init: function() {
            var self = this;
            this.render();
            this.bindEvent();
        },
        render: function(data) {
            var header = new Header();
            $('.main-header').append(header.$el);

            var footer = new Footer();
            $('.main-footer').append(footer.$el);

            var str = "";
            update_content = update_content.reverse();
            console.log(update_content);
            $.each(update_content,function (index,obj) {
                var item ="";
                var des="";
                $.each(obj.update_item,function (index,obj) {
                    if(obj.des){
                        $.each(obj.des,function (i,data) {
                            des+='<span class="history_update_item_content">'+data+'</span>'
                        })
                    }
                    item+= '<p class="history_update_title">'+obj.title+'</p>'+des;
                    des="";
                });
                str+='<li class="history_update_unit">\
                        <div class="history_update_des hide">'+obj.version+'</div>\
                        <div>'+item+'</div>\
                    </li>';
            });
            $(".history_update").html(str);
        },
        bindEvent: function() {
            var self = this;
            $(".history_update_des").on("click",function () {
                var $this = $(this);
                if($this.hasClass("hide")){
                    $this.addClass("show").removeClass("hide");
                    $this.siblings().find("p").show().animate({opacity:1},500);
                    $this.siblings().find("span").css("display","block").animate({opacity:1},500);
                }else{
                    $this.addClass("hide").removeClass("show");
                    $this.siblings().find("p").animate({opacity:0},500,function () {
                        $this.siblings().find("p").hide();
                    })
                    $this.siblings().find("span").animate({opacity:0},500,function () {
                        $this.siblings().find("span").hide();
                    })
                }
            });

            $(".tool_update_record").on("click",function () {
                console.log($("body"));
                // $("body").scrollTop($(".update_content").offset().top);
                $("html,body").animate({scrollTop:$(".update_content").offset().top - 120},500)
            });
        }
    };
    oPage.init();
});