define('widget/timeList', function(require, exports, module){
	function TimeList(opts) {
	    // this.template = _.template(__inline('./timeList.html'));
	
	    this.opts = opts || {};
	    this.curTimeType = this.opts.timeType;
	    this.curTimeValue = this.opts.timeValue;
	    this.timeText = "时间选择";
	    // this.$el = $('<ul class="nav w-time-list clearfix"></ul>');
	    if (this.opts.$dom && this.opts.$dom.length) {
	        this.$el = this.opts.$dom.find('.w-time-list');
	    } else {
	        this.$el = $('.w-time-list');
	    }
	    this.init();
	}
	
	TimeList.prototype.init = function() {
	    // this.getTime();
	    this.bindEvent();
	};
	TimeList.prototype.render = function(data) {
	    // this.$el.html(this.template({
	    //     'dataArr': data,
	    //     'userType': this.params.userType,
	    //     'timeType': this.params.timeType,
	    //     'timeValue': this.params.timeValue,
	    //     'timeText': this.timeText
	    // }));
	    // return this;
	};
	TimeList.prototype.bindEvent = function() {
	    var self = this;
	    this.$el.on('click', '.nowTime', function(e) {
	        e.stopPropagation();
	        var $this = $(this);
	        var timeType = $this.data('timetype');
	        var timeVal = $this.data('value');
	
	        if (self.opts.userType == 'new_anchor') {
	            self.$el.find('[data-timetype="dayRange"]').hide();
	        } else {
	            self.$el.find('[data-timetype="dayRange"]').show();
	        }
	
	        if (timeVal == 'select') {
	            self.$el.find(".select-menu").toggle();
	        } else {
	            if (self.curTimeType != timeType || self.curTimeValue != timeVal) {
	                self.curTimeType = timeType;
	                self.curTimeValue = timeVal;
	                $this.addClass('active').siblings().removeClass('active');
	                $.pub('timeType/change', [{
	                    'timeType': timeType,
	                    'timeValue': timeVal,
	                    'type': self.opts.type
	                }]);
	            }
	        }
	    });
	    $(document).click(function() {
	        self.$el.find(".select-menu").css('display', 'none');
	    });
	
	    this.$el.on('click', '.historyTime', function(e) {
	        e.stopPropagation();
	        var $this = $(this);
	        var timeType = $this.data('timetype');
	        var timeVal = $this.data('value');
	        if (self.curTimeValue != timeVal) {
	            self.curTimeValue = timeVal;
	            self.curTimeType = timeType;
	            self.$el.find(".select-menu").css({
	                'display': 'none'
	            });
	
	            $this.parents('#select').addClass('active').siblings().removeClass('active');
	            self.$el.find(".span").html(timeVal);
	            self.timeText = timeVal;
	            timeVal = timeVal.replace(/\//g, "").replace(/\s/g, "");
	            $.pub('timeType/change', [{
	                'timeType': timeType,
	                'timeValue': timeVal,
	                'type': self.opts.type
	            }]);
	        }
	    });
	    return this;
	};
	TimeList.prototype.updateUserType = function(userType) {
	    this.opts.userType = userType;
	};
	// TimeList.prototype.getTime = function() {
	//     // 近七天时间字符串
	//     var now = new Date();
	//     if (now.getHours() < 2) {
	//         now.setDate(now.getDate() - 1);
	//     }
	//     for (var i = 0; i < 7; i++) {
	//         now.setDate(now.getDate() - 1);
	//         this.dayArr.push({
	//             time: now.Format('yyyy/MM/dd'),
	//             type: 'day',
	//             text: now.Format('yyyy/MM/dd')
	//         });
	//         if (this.params.timeType == 'day') {
	//             if (now.Format('yyyy/MM/dd').replace(/\//g, "").replace(/\s/g, "") == this.params.timeValue) {
	//                 this.timeText = now.Format('yyyy/MM/dd');
	//             }
	//         }
	//     }
	
	//     // 近5周时间字符串
	//     for (var j = 0; j < 35; j = j + 7) {
	//         var arr = [];
	//         var arrText = [];
	//         var week = new Date();
	//         week.setDate(week.getDate() - week.getDay() - j);
	//         arr.push(week.Format('yyyy/MM/dd'));
	//         arrText.push(week.Format('MM/dd'));
	//         week.setDate(week.getDate() - week.getDay() - 6);
	//         arr.unshift(week.Format('yyyy/MM/dd'));
	//         arrText.push(week.Format('MM/dd'));
	//         this.dayArr.push({
	//             time: arr.join(" - "),
	//             type: "dayRange",
	//             text: arr.join(' - ')
	//         });
	//         if (this.params.timeType == 'dayRange') {
	//             if (arr.join(" - ").replace(/\//g, "").replace(/\s/g, "") == this.params.timeValue) {
	//                 this.timeText = arr.join(" - ");
	//             }
	//         }
	//     }
	
	//     // 近3个月时间字符串
	//     for (var k = 0; k < 3; k++) {
	//         var arr = [];
	//         var text = '';
	//         var month = new Date();
	//         month.setMonth(month.getMonth() - k, 1);
	//         month.setDate(month.getDate() - 1);
	//         arr.push(month.Format('yyyy/MM/dd'));
	//         month.setMonth(month.getMonth(), 1);
	//         arr.unshift(month.Format('yyyy/MM/dd'));
	//         text = month.Format('yyyy年MM月');
	//         this.dayArr.push({
	//             time: arr.join(" - "),
	//             type: "dayRange",
	//             text: text
	//         });
	
	//         if (this.params.timeType == 'dayRange') {
	//             if (arr.join(" - ").replace(/\//g, "").replace(/\s/g, "") == this.params.timeValue) {
	//                 this.timeText = arr.join(" - ");
	//             }
	//         }
	
	//     }
	//     this.render(this.dayArr);
	// };
	
	module.exports = TimeList;
});