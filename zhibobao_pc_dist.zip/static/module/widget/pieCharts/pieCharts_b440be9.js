define('widget/pieCharts', function(require, exports, module){
	// 使用该模块的页面需引入echarts
	
	var api = require('common/api');
	
	var chartColorsOutside = [{
	    type: 'linear',
	    x: 0,
	    y: 0,
	    x2: 0,
	    y2: 1,
	    colorStops: [{
	        offset: 0,
	        color: '#5549f4' // 0% 处的颜色
	    }, {
	        offset: 1,
	        color: '#4788ff' // 100% 处的颜色
	    }],
	    globalCoord: false // 缺省为 false
	}, {
	    type: 'linear',
	    x: 0,
	    y: 0,
	    x2: 0,
	    y2: 1,
	    colorStops: [{
	        offset: 0,
	        color: '#3477ff' // 0% 处的颜色
	    }, {
	        offset: 1,
	        color: '#43bfff' // 100% 处的颜色
	    }],
	    globalCoord: false // 缺省为 false
	}, {
	    type: 'linear',
	    x: 0,
	    y: 0,
	    x2: 0,
	    y2: 1,
	    colorStops: [{
	        offset: 0,
	        color: '#3aaeff' // 0% 处的颜色
	    }, {
	        offset: 1,
	        color: '#56edff' // 100% 处的颜色
	    }],
	    globalCoord: false // 缺省为 false
	}, {
	    type: 'linear',
	    x: 0,
	    y: 0,
	    x2: 0,
	    y2: 1,
	    colorStops: [{
	        offset: 0,
	        color: '#fe9131' // 0% 处的颜色
	    }, {
	        offset: 1,
	        color: '#ffd541' // 100% 处的颜色
	    }],
	    globalCoord: false // 缺省为 false
	}, {
	    type: 'linear',
	    x: 0,
	    y: 0,
	    x2: 0,
	    y2: 1,
	    colorStops: [{
	        offset: 0,
	        color: '#ff4f4f' // 0% 处的颜色
	    }, {
	        offset: 1,
	        color: '#ff8c3f' // 100% 处的颜色
	    }],
	    globalCoord: false // 缺省为 false
	}, {
	    type: 'linear',
	    x: 0,
	    y: 0,
	    x2: 0,
	    y2: 1,
	    colorStops: [{
	        offset: 0,
	        color: '#ff5172' // 0% 处的颜色
	    }, {
	        offset: 1,
	        color: '#fe927a' // 100% 处的颜色
	    }],
	    globalCoord: false // 缺省为 false
	}, {
	    type: 'linear',
	    x: 0,
	    y: 0,
	    x2: 0,
	    y2: 1,
	    colorStops: [{
	        offset: 0,
	        color: '#0ec7f5' // 0% 处的颜色
	    }, {
	        offset: 1,
	        color: '#26f0c3' // 100% 处的颜色
	    }],
	    globalCoord: false // 缺省为 false
	}, {
	    type: 'linear',
	    x: 0,
	    y: 0,
	    x2: 0,
	    y2: 1,
	    colorStops: [{
	        offset: 0,
	        color: '#16cf69' // 0% 处的颜色
	    }, {
	        offset: 1,
	        color: '#6ef3bc' // 100% 处的颜色
	    }],
	    globalCoord: false // 缺省为 false
	}];
	var chartColorsOutsideLength = chartColorsOutside.length;
	
	var chartColorsInner = ['#3083ff', '#ff9054', '#2bdfb2', '#47e7ff', '#f26bb7', '#21e5d0'];
	var chartColorsInnerLength = chartColorsInner.length;
	
	/**
	 * @param {Number} [company] [平台类型]
	 * @param {String} [indicator] [指标：开播数anchor，礼物价值gift，弹幕数barrage，新增主播new_anchor]
	 * @param {String} [timeType]	[时间类型：5分钟为minute、1小时为hour，今日为today；历史时间单日的为day；历史时间范围的为dayRange；]
	 * @param {Number | String | Array} [timeValue] [对应时间类型的值：5分钟为5；1小时为1；历史单日如2017-08-10；历史范围为“[2017-07-01,2017-07-30]”]
	 */
	function PieCharts(opts) {
	    this.opts = opts || {};
	
	    this.params = {
	        platform: this.opts.platform,
	        indicator: this.opts.indicator || 'anchor',
	        timeType: this.opts.timeType || 'hour',
	        timeValue: this.opts.timeValue || 1
	    };
	
	    this.$el = $('<div class="w-pie-charts"></div>');
	
	    this.init();
	};
	
	PieCharts.prototype.init = function() {
	    this.getData();
	    this.bindEvent();
	};
	PieCharts.prototype.render = function(chartParams) {
	    // echarts.init(this.$el[0]).clear();
	    this.myChart = echarts.init(this.$el[0]);
	    // 指定图表的配置项和数据
	    this.myChartOption = {
	        backgroundColor: {
	            type: 'pattern',
	            image: ZBB.canvasWaterMark(),
	            repeat: 'repeat'
	        },
	        tooltip: {
	            trigger: 'item',
	            formatter: function(params) {
	                var color = '';
	                if(params.seriesIndex == 0){
	                    color=params.color
	                }else{
	                    color =  params.color.colorStops[0].color
	                }
	                var sHtml = params.name;
	                var marker0 = '<span style="display:inline-block;margin-right:5px;border-radius:10px;width:9px;height:9px;background-color:' + color + ';"></span>';
	                sHtml += '<br/>' + marker0 + params.value.toLocaleString()+'('+ params.percent+'%)';
	                return sHtml;
	            }
	        },
	        legend: [{
	            orient: 'vertical',
	            x: 'left',
	            y: 'center',
	            itemGap: 15,
	            itemWidth: 15,
	            itemHeight: 15,
	            textStyle: {
	                color: '#8492af'
	            },
	            icon: 'circle',
	            data: chartParams.outNameData
	        },{
	            orient: 'vertical',
	            x: 'right',
	            y: 'center',
	            itemGap: 15,
	            itemWidth: 15,
	            itemHeight: 15,
	            textStyle: {
	                color: '#8492af'
	            },
	            icon: 'circle',
	            data: chartParams.innerNameData
	        }],
	        toolbox: {
	            show: false
	        },
	        series: [{
	            center: ['50%', '52%'],
	            color: chartColorsInner,
	            type: 'pie',
	            selectedMode: 'single',
	            radius: [0, 70],
	            legendHoverLink: true,
	            label: {
	                normal: {
	                    position: 'inner',
	                    color: '#ffffff',
	                    fontSize: 12
	                }
	            },
	            itemStyle: {
	                normal: {
	                    color: function(params) {
	                        return chartColorsInner[params.dataIndex % chartColorsInnerLength];
	                    }
	                },
	                emphasis: {
	                    shadowBlur: 20,
	                    shadowColor: 'rgba(0, 0, 0, 0.5)'
	                }
	            },
	            data: chartParams.innerSeriesData
	        }, {
	            center: ['50%', '52%'],
	            color: chartColorsOutside,
	            type: 'pie',
	            selectedMode: 'single',
	            radius: [100, 155],
	            legendHoverLink: true,
	            label: {
	                normal: {
	                    position: 'outside',
	                    textStyle: {
	                        color: '#8492af'
	                    },
	                    fontSize: 16
	                }
	            },
	            labelLine: {
	                normal: {
	                    lineStyle: {
	                        color: '#8492af'
	                    },
	                    length: 45,
	                    length2: 30
	                }
	            },
	            itemStyle: {
	                normal: {
	                    color: function(params) {
	                        return chartColorsOutside[params.dataIndex % chartColorsOutsideLength];
	                    }
	                },
	                emphasis: {
	                    shadowBlur: 20,
	                    shadowColor: 'rgba(0, 0, 0, 0.5)'
	                }
	            },
	            data: chartParams.outSeriesData
	        }]
	    };
	
	    // 使用刚指定的配置项和数据显示图表。
	    this.myChart.setOption(this.myChartOption);
	
	    return this;
	};
	PieCharts.prototype.bindEvent = function() {
	    var self = this;
	
	    return this;
	};
	var compare = function (prop) {
	    return function (obj1, obj2) {
	        var val1 = obj1[prop];
	        var val2 = obj2[prop];
	        if (val1 < val2) {
	            return 1;
	        } else if (val1 > val2) {
	            return -1;
	        } else {
	            return 0;
	        }
	    }
	};
	
	
	PieCharts.prototype.getData = function(data) {
	    $.extend(this.params, data);
	    this.myChart && this.myChart.clear();
	    var self = this;
	    var path = 'indust/platform';
	    api.get(path, this.params).done(function(data) {
	        if (data.code == 0) {
	            var outNameData = [];
	            var innerNameData = [];
	            var innerSeriesData = [];
	            var outSeriesData = [];
	            var arr = [];
	            var flagArr = [];
	            $.each(data.data.current, function(i, obj) {
	                var index = flagArr.indexOf(obj.className);
	                obj.value = parseInt( obj.value );
	                if( index > -1 ){
	                    arr[ index ].child.push( obj );
	                    arr[ index ].value += Number( obj.value );
	                    arr[ index ].child.sort( ZBB.compare( 'value' ) )
	                }else{
	                    flagArr.push( obj.className );
	                    arr.push({
	                        value: Number(obj.value),
	                        className: obj.className,
	                        child:[ obj ]
	                    });
	                }
	            });
	
	            arr.sort( ZBB.compare( 'value' ) );
	            $.each(arr, function(i, obj) {
	                innerNameData.push({name:obj.className,icon:'circle'});
	                innerSeriesData.push({
	                    value: Number(obj.value),
	                    name: obj.className
	                });
	                $.each(arr[i].child, function(j, data) {
	                    outNameData.push({name:data.cateName,icon:'circle'});
	                    outSeriesData.push({
	                        value: Number(data.value),
	                        name: data.cateName
	                    });
	                });
	            });
	            //承接最后一组数据
	            flagArr = [];
	            self.render({
	                innerNameData: innerNameData,
	                outNameData: outNameData,
	                innerSeriesData: innerSeriesData,
	                outSeriesData: outSeriesData
	            });
	        }
	    });
	};
	
	module.exports = PieCharts;
});