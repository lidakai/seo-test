define('widget/industryCharts', function(require, exports, module){
	// 使用该模块的页面需引入echarts
	var api = require('common/api');
	
	/**
	 * @param {Number} [category] [频道类型]
	 * @param {String} [indicator] [指标：开播数anchor，礼物价值gift，弹幕数barrage，新增主播new_anchor]
	 * @param {String} [timeType]	[时间类型：5分钟为minute、1小时为hour，今日为today；历史时间单日的为day；历史时间范围的为dayRange；]
	 * @param {Number | String | Array} [timeValue] [对应时间类型的值：5分钟为5；1小时为1；历史单日如2017-08-10；历史范围为“[2017-07-01,2017-07-30]”]
	 */
	function IndustryCharts(opts) {
		this.opts = opts || {};
	
		this.params = {
			category: this.opts.category || 1,
			indicator: this.opts.indicator || 'barrage',
			timeType: this.opts.timeType || 'hour',
			timeValue: this.opts.timeValue || 1
		};
		this.unit = "人";
		this.$el = $('<div class="w-industry-charts"></div>');
		this.init();
	};
	
	IndustryCharts.prototype.init = function() {
		this.getData();
		this.bindEvent();
	};
	
	IndustryCharts.prototype.render = function(chartParams) {
		// echarts.init(this.$el[0]).clear();
		this.myChart = echarts.init(this.$el[0]);
	
		// 指定图表的配置项和数据
		this.myChartOption = {
			backgroundColor: {
				type: 'pattern',
				image: ZBB.canvasWaterMark(),
				repeat: 'repeat'
			},
			title: {
				show: false
			},
			tooltip: {
				trigger: 'axis',
				axisPointer: { // 坐标轴指示器，坐标轴触发有效
					type: 'shadow', // 默认为直线，可选为：'line' | 'shadow'
					shadowStyle: {
						color: {
							type: 'linear',
							x: 0,
							y: 0,
							x2: 0,
							y2: 1,
							colorStops: [{
								offset: 0,
								color: 'rgba(0, 192, 255, 0.2)' // 0% 处的颜色
							}, {
								offset: 1,
								color: 'rgba(0, 192, 255, 0.05)' // 100% 处的颜色
							}],
							globalCoord: false // 缺省为 false
						}
					}
				},
				formatter: function(params) {
					var sHtml = params[0].name,
						value = "",
						oldValue = "";
					if (chartParams.sign) {
						value = Number(params[0].value).toFixed(1)
					} else {
						value = Number(params[0].value)
					}
					if (params.length == 1) {
						var marker0 = '<span style="display:inline-block;margin-right:5px;border-radius:10px;width:9px;height:9px;background-color:' + params[0].color.colorStops[0].color + ';"></span>';
						sHtml += '<br/>' + marker0 + value.toLocaleString();
					} else {
						if (chartParams.sign) {
							oldValue = Number(params[1].value).toFixed(1);
						} else {
							oldValue = Number(params[1].value)
						}
						var marker0 = '<span style="display:inline-block;margin-right:5px;border-radius:10px;width:9px;height:9px;background-color:' + params[0].color.colorStops[0].color + ';"></span>';
						var marker1 = '<span style="display:inline-block;margin-right:5px;border-radius:10px;width:9px;height:9px;background-color:' + params[1].color.colorStops[0].color + ';"></span>';
						sHtml += '<p style="text-align: right;">' + marker0 + chartParams.time + '：' + value.toLocaleString() + '</p><p style="text-align: right;">' + marker1 + '上周期：' + oldValue.toLocaleString() + '</p>';
					}
					return sHtml;
				}
			},
			legend: {
				data: chartParams.xAxisData
			},
			grid: {
				top: 20,
				left: 10,
				right: 10,
				bottom: 0,
				containLabel: true
			},
			xAxis: {
				type: 'category',
				axisLabel: {
					textStyle: {
						color: '#8492af'
					}
				},
				axisTick: {
					show: false
				},
				axisLine: {
					show: false
				},
				data: chartParams.xAxisData
			},
			yAxis: {
				type: 'value',
				axisLabel: {
					formatter: '{value} ' + chartParams.unit,
					textStyle: {
						color: '#8492af'
					}
				},
				axisLine: {
					show: false
				},
				axisTick: {
					show: false
				},
				splitLine: {
					lineStyle: {
						type: 'dotted',
						color: '#8492af',
						opacity: 0.55
					}
				}
			}
		};
	
		if (this.params.timeType == 'dayRange') {
			this.myChartOption.series = [{
				// name:chartParams.time,
				type: 'bar',
				itemStyle: {
					normal: {
						color: {
							type: 'linear',
							x: 0,
							y: 0,
							x2: 0,
							y2: 1,
							colorStops: [{
								offset: 0,
								color: '#44dee8' // 0% 处的颜色
							}, {
								offset: 1,
								color: '#319df0' // 100% 处的颜色
							}],
							globalCoord: false // 缺省为 false
						}
					}
				},
				data: chartParams.seriesData_one
			}, {
				// name:chartParams.time,
				type: 'bar',
				itemStyle: {
					normal: {
						color: {
							type: 'linear',
							x: 0,
							y: 0,
							x2: 0,
							y2: 1,
							colorStops: [{
								offset: 0,
								color: '#2cc1ff' // 0% 处的颜色
							}, {
								offset: 1,
								color: '#2875e8' // 100% 处的颜色
							}],
							globalCoord: false // 缺省为 false
						}
					}
				},
				data: chartParams.seriesData_two
			}];
		} else {
			this.myChartOption.series = [{
				type: 'bar',
				barCategoryGap: '50%',
				itemStyle: {
					normal: {
						color: {
							type: 'linear',
							x: 0,
							y: 0,
							x2: 0,
							y2: 1,
							colorStops: [{
								offset: 0,
								color: '#44dee8' // 0% 处的颜色
							}, {
								offset: 1,
								color: '#319df0' // 100% 处的颜色
							}],
							globalCoord: false // 缺省为 false
						}
					}
				},
				data: chartParams.seriesData_one
			}];
		};
	
		// 使用刚指定的配置项和数据显示图表。
		this.myChart.setOption(this.myChartOption);
	
		return this;
	};
	IndustryCharts.prototype.bindEvent = function() {
		var self = this;
	
		return this;
	};
	IndustryCharts.prototype.getData = function(data) {
		$.extend(this.params, data);
		var self = this;
		var path = 'indust/cate';
		var unit = false;
		switch (self.params.indicator) {
			case "anchor":
			case "new_anchor":
				self.unit = "人";
				break;
			case "gift":
				self.unit = "元";
				break;
			case "barrage":
				self.unit = "条";
				break;
			default:
				self.unit = "人";
				break;
		}
		this.myChart && this.myChart.clear();
		api.get(path, this.params).done(function(data) {
			if (data.code == 0) {
				var arr = [];
				var xAxisData = [];
				var seriesData_one = [];
				var seriesData_two = [];
				if (self.params.timeType == 'dayRange') {
					$.each(ZBB.platformName, function(i, n) {
						arr.push({
							name: n,
							current: Number(data.data.current[n]),
							lastValue: data.data.last[n]
						});
					});
					unit = ZBB.IsBeyond(arr);
					if (unit) {
						ZBB.dataChange(arr, ['current', 'lastValue']);
						self.unit = "万" + self.unit;
					}
				} else {
					$.each(ZBB.platformName, function(i, n) {
						arr.push({
							name: n,
							current: Number(data.data.current[n])
						});
					});
					unit = ZBB.IsBeyond(arr);
					if (unit) {
						ZBB.dataChange(arr, ['current']);
						self.unit = "万" + self.unit;
					}
				}
				arr = arr.sort(ZBB.compare('current'));
				$.each(arr, function(i, obj) {
					xAxisData.push(obj.name);
					seriesData_one.push(Number(obj.current));
					seriesData_two.push(Number(obj.lastValue));
				});
				self.render({
					xAxisData: xAxisData,
					seriesData_one: seriesData_one,
					seriesData_two: seriesData_two,
					time: self.params.timeValue,
					unit: self.unit,
					sign: unit
				});
			}
		});
	};
	
	module.exports = IndustryCharts;
});