define('widget/barrageReport', function(require, exports, module){
	var barrageReport = function (opts) {
	    this.template = _.template("");
	    this.opts = opts || {};
	    this.params = {
	
	    };
	    this.init();
	};
	
	barrageReport.prototype.init = function () {
	
	};
	
	barrageReport.prototype.bindEvent = function () {
	    
	};
	
	barrageReport.prototype.render = function () {
	
	};
	
	barrageReport.prototype.getData = function (data) {
	    $.extend(this.params, data);
	    var self = this;
	    api.get(path, this.params).done(function(data) {
	        if (data.code == 0) {
	
	        }
	    }).fail(function () {
	
	    });
	};
	
	module.exports = barrageReport;
});