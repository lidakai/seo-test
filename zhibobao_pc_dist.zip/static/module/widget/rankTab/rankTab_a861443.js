define('widget/rankTab', function(require, exports, module){
	var RANKTAB_List = [{
		'name': '主播榜单',
		'val': 'anchor'
	}, {
		'name': '新晋主播',
		'val': 'new_anchor'
	}, {
		'name': '土豪榜单',
		'val': 'user'
	}];
	
	function RankTab(opts) {
		// this.template = _.template(__inline('./rankTab.html'));
	
		this.opts = opts || {};
	
		// this.$el = $('<div class="w-rank-tab"></div>');
		if (this.opts.$dom && this.opts.$dom.length) {
	        this.$el = this.opts.$dom.find('.w-rank-tab');
	    } else {
	        this.$el = $('.w-rank-tab');
	    }
	
		this.init();
	}
	
	RankTab.prototype.init = function() {
		this.render();
		this.bindEvent();
	};
	RankTab.prototype.render = function() {
		// this.$el.html(this.template({
		// 	list: RANKTAB_List,
		// 	userType:this.opts.userType
		// }));
	
		return this;
	};
	RankTab.prototype.bindEvent = function() {
		this.$el.on('click', 'li', function() {
			var $this = $(this);
			var type = $this.data("type");
			if (!$this.hasClass("active")) {
				$this.addClass('active').siblings().removeClass('active');
				$.pub('rankTab/change', [{
					'userType': type
				}]);
			}
		});
	
		return this;
	};
	
	module.exports = RankTab;
});