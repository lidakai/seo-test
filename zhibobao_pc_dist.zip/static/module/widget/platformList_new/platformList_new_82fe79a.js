define('widget/platformList_new', function(require, exports, module){
	
});