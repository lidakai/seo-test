define('widget/anchorInfo', function(require, exports, module){
	
	var api = require('common/api');
	// 直播密度
	// 返回最近30天的直播
	// day表示周1-周日的，该日有过直播就加1；
	// time表示一天24小时的，1表示0-1点，24表示23-24点，在该范围内有在直播的就加1
	function anchorInfo( data ) {
		this.template = _.template("<img class=\"w-anchor-avatar\" src=\"<%= ZBB.parseAvatar(anchorInfo.avatar) %>\" alt=\"\">\r\n<p class=\"anchor-name text-able-select\"><%= anchorInfo.nickname %></p>\r\n<div>\r\n\t<span class=\"anchor-platform\"><%= ZBB.platformName[anchorInfo.platform] %></span>\r\n\t<% if(anchorInfo.cateName) { %>\r\n\t<span class=\"anchor-category\"><%= anchorInfo.cateName %></span>\r\n\t<% } %>\r\n</div>\r\n<a class=\"js_anchor_enter\" href=\"<%= anchorInfo.url %>\" target=\"_blank\">进入直播间</a>");
	
	    this.data =data;
		this.$el = $('<div class="w-anchor-info"></div>');
	
	};
	
	anchorInfo.prototype.init = function() {
	    var self = this;
	    this.render(self.data);
	};
	anchorInfo.prototype.render = function(data) {
		this.$el.html( this.template({
	        'anchorInfo':data
		}));
		return this;
	};
	module.exports = anchorInfo;
});