define('widget/indicatorList', function(require, exports, module){
	function IndicatorList(opts) {
	    // this.template = _.template(__inline('./indicatorList.html'));
	
	    this.opts = opts || {};
	
	    // this.$el = $('<ul class="w-indicator-list js_indicator_list clearfix"></ul>');
	    if (this.opts.$dom && this.opts.$dom.length) {
	        this.$el = this.opts.$dom.find('.w-indicator-list');
	    } else {
	        this.$el = $('.w-indicator-list');
	    }
	
	    this.init();
	};
	
	IndicatorList.prototype.init = function() {
	    this.render();
	    this.bindEvent();
	};
	IndicatorList.prototype.render = function() {
	    // this.$el.html(this.template());
	    return this;
	};
	IndicatorList.prototype.bindEvent = function() {
	    var self = this;
	    this.$el.on('click', 'li', function() {
	        var $this = $(this);
	        var indicator = $(this).data('indicator');
	        if (indicator != undefined) {
	            if (!$this.hasClass("active")) {
	                $this.addClass('active').siblings().removeClass('active');
	                $.pub('indicator/change', [{
	                    'indicator': indicator,
	                    'type': self.opts.type
	                }]);
	            }
	        }
	    });
	    return this;
	};
	
	module.exports = IndicatorList;
});