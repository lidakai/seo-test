define('widget/iconExhibition', function(require, exports, module){
	import logoList_info from '/mockData/logoList_info'
	function iconExhibition(opts) {
	    // this.template = _.template(__inline('./indicatorList.html'));
	
	    this.opts = opts || {};
	    // this.$el = $('<ul class="w-indicator-list js_indicator_list clearfix"></ul>');
	    if (this.opts.$dom && this.opts.$dom.length) {
	        this.$el = this.opts.$dom.find('.w-iconExhibition-box');
	    } else {
	        this.$el = $('.w-iconExhibition-box');
	    }
	    this.init();
	};
	iconExhibition.prototype.init = function() {
	    console.log(logoList_info)
	    this.render();
	    this.bindEvent();
	};
	iconExhibition.prototype.render = function() {
	    // this.$el.html(this.template());
	    return this;
	};
	iconExhibition.prototype.bindEvent = function() {
	    var self = this;
	    // 行业-频道类型
	    $.sub('category/change', function(e, data) {
	       console.log(data)
	    });
	    $.sub('platform/change', function(e, data) {
	        console.log(data)
	    });
	    return this;
	};
	
	module.exports = iconExhibition;
});