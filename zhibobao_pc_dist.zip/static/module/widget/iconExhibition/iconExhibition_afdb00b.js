define('widget/iconExhibition', function(require, exports, module){
	
});