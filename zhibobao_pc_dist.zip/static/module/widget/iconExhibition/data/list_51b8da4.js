define('widget/iconExhibition/data/list.js', function(require, exports, module){
	export default {
	    "code": 0,
	    "msg": "",
	    "data": {
	        "list" :[
	            {
	                "iconUrl":"https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1526464714916&di=18ab22a074f375ffd1c37c56117fc1b1&imgtype=0&src=http%3A%2F%2Fimg13.weikeimg.com%2Fdata%2Fuploads%2F2016%2F09%2F29%2F100126992757ecb01f2df98.png",
	                "id":"",
	                "name":"全部"
	            },{
	                "iconUrl":"//static.quanmin.tv/public/common/view/widget/header/img/logo_12efde8.png",
	                "id":"quanmin",
	                "name":"全民"
	            },{
	                "iconUrl":"https://staticlive.douyucdn.cn/upload/signs/201703031609518839.png",
	                "id":"douyu",
	                "name":"斗鱼"
	            },{
	                "iconUrl":"https://a.msstatic.com/huya/main/img/logo.png",
	                "id":"huya",
	                "name":"虎牙"
	            },{
	                "iconUrl":"https://i.h2.pdim.gs/b2a97149ec43dfc95eb177508af29f6c.png",
	                "id":"panda",
	                "name":"熊猫"
	            },{
	                "iconUrl":"https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1526464408733&di=97ae8d978caa6d9714671dcac62023f6&imgtype=0&src=http%3A%2F%2Fimg2.plures.net%2F4bf4%2F04a0%2Fc37e%2F4357%2F9198%2F4043%2F8f59%2F12b7.png",
	                "id":"longzhu",
	                "name":"龙珠"
	            },{
	                "iconUrl":"//kascdn.kascend.com/jellyfish/uiupload/images/common/logo2_modify1.png",
	                "id":"chushou",
	                "name":"触手"
	            },{
	                "iconUrl":"http://static.zhanqi.tv/assets/web/static/i/index/skin/logo.png",
	                "id":"zhanqi",
	                "name":"战旗"
	            }
	        ]
	    }
	}
});