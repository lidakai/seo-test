define('widget/iconExhibition/data/list.js', function(require, exports, module){
	
});