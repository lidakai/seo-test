define('widget/rewardReport', function(require, exports, module){
	var rewardReport = function (opts) {
	    this.template = _.template("");
	    this.opts = opts || {};
	    this.params = {
	
	    };
	    this.init();
	};
	
	rewardReport.prototype.init = function () {
	
	};
	
	rewardReport.prototype.bindEvent = function () {
	
	};
	
	rewardReport.prototype.render = function () {
	
	};
	
	rewardReport.prototype.getData = function (data) {
	    $.extend(this.params, data);
	    var self = this;
	    api.get(path, this.params).done(function(data) {
	        if (data.code == 0) {
	
	        }
	    }).fail(function () {
	
	    });
	};
	
	module.exports = rewardReport;
});