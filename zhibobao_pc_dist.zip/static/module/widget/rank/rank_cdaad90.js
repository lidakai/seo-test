define('widget/rank', function(require, exports, module){
	var api = require('common/api');
	
	/**
	 * @param {String} [userType] [用户类型，主播'anchor', 新晋主播'new_anchor', 土豪'user']
	 * @param {String} [platform]	[douyu，huya，quanmin，平台名拼音,没有的话则为全平台]
	 * @param {Number} [category]	[类型，不传为全部]
	 * @param {String} [timeType]	[时间类型：5分钟为minute、1小时为hour，今日为today；历史时间单日的为day；历史时间范围的为dayRange；]
	 * @param {Number | String | Array} [timeValue] [对应时间类型的值：5分钟为5；1小时为1；历史单日如2017-08-10；历史范围为“[2017-07-01,2017-07-30]”]
	 * @param {String | Array } [rankType] [榜单类型，'gift', 'barrage']
	 * @param {Number} [limit] [限制展示的数量，默认不限制]
	 */
	function Rank(opts) {
		this.template = _.template("<% if ( userType == 'user'){ %>\r\n        <!--用户列表展示-->\r\n        <div class=\"w-rank_title w-rank-<%= timeType %>_title\">\r\n            <i></i>\r\n            <span><%= title %></span>\r\n            <span class=\"w-rank_tips_icon tooltips-top\" data-tooltips=\"主播收到的礼物根据平台比例换算后的数值，单位：元\"></span>\r\n        </div>\r\n        <% if ( list.length ){ %>\r\n        <ul class=\"w-rank-body-<%= rankType %>\">\r\n            <% _.each(list, function(item, index) { %>\r\n            <li data-usertype=\"<%- userType %>\" data-roomid=\"<%- item.roomid %>\" data-platform=\"<%- item.platform %>\" class=\"clearfix\">\r\n                <a href=\"javascript:;\">\r\n                    <% if ( index > 2 ) { %>\r\n                    <div class=\"w-rank_ranking\">NO.<%= index+1 %></div>\r\n                    <% }else { %>\r\n                    <div class=\"w-rank_ranking more-than-three\"><i><%= index+1 %></i></div>\r\n                    <% } %>\r\n                    <div class=\"rank-content\">\r\n                        <img src=\"<%= ZBB.platformDefaultAvatar[item.platform] %>\" class=\"w-rank_avatar\">\r\n                        <div class=\"w-rank_anchor_info js_anchor_info\">\r\n                            <p class=\"w-rank_anchor_info_user_nickname text-able-select\"><%- item.nickname %></p>\r\n                        </div>\r\n                    </div>\r\n                    <% if ( item.value ) { %>\r\n                    <div class=\"w-rank_value text-able-select\"><%= '￥' + item.value %></div>\r\n                    <% } %>\r\n                </a>\r\n            </li>\r\n            <% }) %>\r\n        </ul>\r\n        <% } %>\r\n<% } else{ %>\r\n        <!--主播列表展示-->\r\n        <div class=\"w-rank_title w-rank-<%= rankType %>_title\">\r\n            <i></i>\r\n            <span><%= title %></span>\r\n            <% if ( rankType == 'gift' ){ %>\r\n            <span class=\"w-rank_tips_icon tooltips-top\" data-tooltips=\"主播收到的礼物根据平台比例换算后的数值，单位：元\"></span>\r\n            <% } else { %>\r\n            <span class=\"w-rank_tips_icon tooltips-top\" data-tooltips=\"直播间观众累计发送的弹幕条数，单位：条\"></span>\r\n            <% } %>\r\n        </div>\r\n        <% if ( list.length ){ %>\r\n        <ul class=\"w-rank-body-<%= rankType %>\">\r\n            <% _.each(list, function(item, index) { %>\r\n            <li data-usertype=\"<%- userType %>\" data-roomid=\"<%- item.roomid %>\" data-platform=\"<%- item.platform %>\" class=\"clearfix\">\r\n                    <a href=\"/anchor?roomId=<%- item.roomid %>&platform=<%- item.platform %>\" target=\"_blank\">\r\n                        <% if ( index > 2 ) { %>\r\n                        <div class=\"w-rank_ranking\">NO.<%= index+1 %></div>\r\n                        <% }else { %>\r\n                        <div class=\"w-rank_ranking more-than-three\"><i><%= index+1 %></i></div>\r\n                        <% } %>\r\n                        <div class=\"rank-content\">\r\n                            <img src=\"<%= ZBB.platformDefaultAvatar['default'] %>\" data-original =\"<%= ZBB.parseAvatar(item.avatar) %>\" class=\"w-rank_avatar lazy\">\r\n                            <div class=\"w-rank_anchor_info js_anchor_info\">\r\n                                <p class=\"w-rank_anchor_info_nickname text-able-select\">\r\n                                    <%- item.nickname %>\r\n                                </p>\r\n                                <p>\r\n                                    <span class=\"w-rank_anchor_info_platform fl\"><%= ZBB.platformName[item.platform] %></span>\r\n                                    <% if ( item.categoryName ) { %>\r\n                                    <i class=\"fl\">-</i>\r\n                                    <span class=\"w-rank_anchor_info_category fl\"><%= item.categoryName%></span>\r\n                                    <% } %>\r\n                                </p>\r\n                            </div>\r\n                        </div>\r\n                        <% if ( item.value ) { %>\r\n                        <div class=\"w-rank_value text-able-select\"><%= (rankType == 'gift' ? '￥' : '') + item.value %></div>\r\n                        <% } %>\r\n                    </a>\r\n            </li>\r\n            <% }) %>\r\n        </ul>\r\n        <% } %>\r\n<% } %>\r\n\r\n\r\n\r\n");
		this.opts = opts || {};
		this.limit = this.opts.limit || -1;
		this.params = {
			userType: this.opts.userType || 'anchor',
			platform: this.opts.platform,
			category: this.opts.category,
			timeType: this.opts.timeType || 'hour',
			timeValue: this.opts.timeValue || 1,
			rankType: this.opts.rankType || 'gift',
			limit: this.opts.limit || 5
		};
		this.rankData = {};
		if (this.opts.$dom && this.opts.$dom.length) {
			this.$el = this.opts.$dom.find('.w-rank');
		} else {
			this.$el = $('<div class="w-rank clearfix"></div>');
		}
		this.init();
	};
	
	Rank.prototype.init = function() {
	
	};
	Rank.prototype.render = function() {
		if (this.rankData) {
			if (this.opts.limit && this.rankData.list) {
				this.rankData.list = this.rankData.list.slice(0, this.opts.limit);
				if (this.params.rankType == 'gift') {
					for (var i = 0, len = this.rankData.list.length; i < len; i++) {
						this.rankData.list[i].value = this.rankData.list[i].value.toFixed(2);
					}
				}
			}
			this.$el.html(this.template(this.rankData));
		}
		this.$el.find(".lazy").lazyload();
		return this;
	};
	Rank.prototype.getData = function(data) {
		$.extend(this.params, data);
		var self = this;
		var path = "rank/list";
	
		api.get(path, this.params).done(function(data) {
			if (data.code == 0) {
				self.rankData = data.data;
				self.rankData.userType = self.params.userType;
				self.rankData.rankType = self.params.rankType;
				self.rankData.timeType = self.params.timeType;
				self.render();
				$.pub('rank/updateEnd', [{
					timestamp: data.data.timestamp,
					timeType: self.params.timeType,
					userType: self.params.userType,
					timeValue: self.params.timeValue
				}]);
			}
		}).fail(function() {
			self.rankData.list = [];
			self.render();
		});
	};
	
	
	module.exports = Rank;
});