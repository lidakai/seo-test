define('widget/header', function(require, exports, module){
	var Search = require("widget/search");
	
	function Header(pageType) {
		// if (window.location.hostname == 'www.zhibobao.com') {
		// 	this.template = _.template(__inline('./header.html'));
		// } else {
		// 	this.template = _.template(__inline('./header_tv.html'));
		// }
	
		this.pageType = pageType;
		// if (pageType == 'index') {
		// 	this.$el = $('<div class="w-header w-header-index"></div>');
		// } else {
		// 	this.$el = $('<div class="w-header"></div>');
		// }
		
		this.init();
	};
	
	Header.prototype.init = function() {
		this.render();
		this.bindEvent();
	};
	Header.prototype.render = function() {
		// this.$el.html(this.template());
	
		// var $head_nav = this.$el.find('.w-header_nav');
	
		// var pathname = location.pathname;
	
		// if (window.location.hostname == 'www.zhibobao.com') {
		// 	if (pathname == '/static/boot/main/main.html' || pathname == '/') {
		// 		$head_nav.find('[data-page="home"]').addClass('active');
		// 	} else if (pathname == '/static/boot/rank/rank.html' || pathname == '/rank') {
		// 		$head_nav.find('[data-page="rank"]').addClass('active');
		// 	} else if (pathname == '/static/boot/platform/platform.html' || pathname == '/platform') {
		// 		$head_nav.find('[data-page="platform"]').addClass('active');
		// 	} else if (pathname == '/static/boot/tool/tool.html' || pathname == '/tool') {
		// 		$head_nav.find('[data-page="tool"]').addClass('active');
		// 	}
		// } else {
		// 	if (pathname == '/static/boot/main/main.html' || pathname == '/data') {
		// 		$head_nav.find('[data-page="home"]').addClass('active');
		// 	} else if (pathname == '/static/boot/rank/rank.html' || pathname == '/rank') {
		// 		$head_nav.find('[data-page="rank"]').addClass('active');
		// 	} else if (pathname == '/static/boot/platform/platform.html' || pathname == '/platform') {
		// 		$head_nav.find('[data-page="platform"]').addClass('active');
		// 	} else if (pathname == '/static/boot/tool/tool.html' || pathname == '/') {
		// 		$head_nav.find('[data-page="tool"]').addClass('active');
		// 	}
		// }
		
		this.$el = $('.w-header');
		if (this.pageType == 'search') {
	
		} else {
			this.search = new Search();
			// this.$el.find('.js-w-header_search').html(this.search.$el);
		}
	
		return this;
	};
	Header.prototype.bindEvent = function() {
		var self = this;
	
		$(document).scroll(function() {
			var h = $(this).scrollTop();
			if (h > 0) {
				self.$el.addClass('w-header-scroll');
			} else {
				self.$el.removeClass('w-header-scroll');
			}
		});
	
		this.$el.find(".w-header_nav_link_warp a").on("click", function() {
			if($(this).attr('target') == '_blank') {
				return;
			}
	
			$(this).parent().addClass("active").siblings().removeClass('active');
			if ($(this).data('page') == "tool") {
				self.$el.parent().addClass('w-header-new');
			} else {
				self.$el.parent().removeClass('w-header-new');
			}
		});
		return this;
	};
	
	Header.prototype.activeNav = function(index) {
		var $list = this.$el.find('.w-header_nav_link_warp');
		$list.removeClass('active');
		$list.eq(index).addClass('active');
	
		if (index === 0) {
			this.$el.addClass('w-header-index');
		} else {
			this.$el.removeClass('w-header-index');
		}
	};
	
	module.exports = Header;
});