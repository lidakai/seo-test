define('widget/searchResult', function(require, exports, module){
	var api = require('common/api');
	
	/**
	 * @param {String} [searchVal] [搜索关键词]
	 * @param {Number} [page_num] [搜索的页数]
	 */
	function SearchResult(opts) {
	    this.template = _.template("<div class=\"search-result-title\">搜索结果 <span>总共为您搜索到关于“ <i class=\"search-name text-able-select\"><%=obj.search %></i> ”的 <i class=\"search-result-num\"><%=obj.total %></i> 个结果</span> </div>\r\n\r\n<ul class=\"w-searchResult clearfix\">\r\n    <% _.each(obj.list, function(item, index) { %>\r\n    <li class=\"w-searchResult-list\">\r\n        <div calss=\"w-searchResult-avatar fl\">\r\n            <img src=\"<%= ZBB.parseAvatar(item.avatar) %>\" onerror=\"this.src='<%= ZBB.platformDefaultAvatar.default %>';\">\r\n        </div>\r\n        <div class=\"w-searchResult-info fl\">\r\n            <p class=\"w-searchResult-info_nickname text-able-select\"><%=item.nickname %></p>\r\n            <p>\r\n                <span class=\"w-searchResult-info_platform fl\"><%= ZBB.platformName[item.plat] %></span>\r\n                <% if( item.cateName ) {%>\r\n                <span class=\"w-searchResult-info_category fl\"><%=item.cateName %></span>\r\n                <% } %>\r\n            </p>\r\n            <% if( item.follow > -1 ) {%>\r\n            <p class=\"text-able-select\">\r\n                粉丝数: <span><%=item.follow %></span>\r\n            </p>\r\n            <% } %>\r\n        </div>\r\n        <div class=\"w-searchResult-btn fr\">\r\n            <a href=\"/anchor?roomId=<%=item.roomId %>&platform=<%=item.plat %>\" target=\"_blank\">查看</a>\r\n        </div>\r\n    </li>\r\n    <% }) %>\r\n</ul>");
	    this.$el = $('<div id="container"></div>');
	    this.opts = opts || {};
	    this.params = {
	        page: this.opts.page || 1,
	        search: this.opts.search,
	        size:this.opts.size || 15
	    };
	    this.init();
	
	}
	SearchResult.prototype.render = function(data) {
	    this.$el.html(this.template({
	        'obj': data.data
	    }));
	};
	SearchResult.prototype.init = function() {
	    this.getData();
	};
	SearchResult.prototype.getData = function(data) {
	    $.extend(this.params, data);
	    if (!this.params.search) {
	        this.$el.html( '<p class="default">(｢･ω･)｢嘿，请按套路来</p>' );
	        return;
	    }
	    var self = this,
	        path = 'search';
	    api.get(path, this.params).done(function(data) {
	
	        if (data.code == 0) {
	            data.data.search= self.params.search;
	            self.render({
	                data: data.data
	            });
	            if( self.params.isPagination )return;
	            $.pub('page/change', [{
	                "page": Math.ceil( Number( data.data.total / self.params.size  ) ),
	                "search": self.params.search,
	                "current_page":1
	            }]);
	        }else{
	            self.$el.html( '<p class="default">服务繁忙，请稍后重试</p>' );
	            $.pub('page/change', [{"page": 0}]);
	        }
	    }).fail(function(data) {
	        self.$el.html( '<p class="default">服务繁忙，请稍后重试</p>' );
	        $.pub('page/change', [{"page": 0}]);
	    });
	};
	
	module.exports = SearchResult;
});