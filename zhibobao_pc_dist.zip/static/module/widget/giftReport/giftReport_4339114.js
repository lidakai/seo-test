define('widget/giftReport', function(require, exports, module){
	var giftReport = function (opts) {
	    this.template = _.template("");
	    this.opts = opts || {};
	    this.params = {
	
	    };
	    this.init();
	};
	
	giftReport.prototype.init = function () {
	
	};
	
	giftReport.prototype.bindEvent = function () {
	
	};
	
	giftReport.prototype.render = function () {
	
	};
	
	giftReport.prototype.getData = function (data) {
	    $.extend(this.params, data);
	    var self = this;
	    api.get(path, this.params).done(function(data) {
	        if (data.code == 0) {
	
	        }
	    }).fail(function () {
	
	    });
	};
	
	module.exports = giftReport;
});