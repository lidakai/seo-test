define('widget/categoryList_new', function(require, exports, module){
	
});