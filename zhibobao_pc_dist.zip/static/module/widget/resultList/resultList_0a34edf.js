define('widget/resultList', function(require, exports, module){
	var api = require('common/api');
	
	function ResultList(opts) {
	    this.template = _.template("<div class=\"w-result-list_col w-result-list_col_1\">\r\n    <p><label class=\"text-able-select js_gift_value\"><%= data.gift_value %></label><span class=\"w-result-list_unit\">元</span></p>\r\n    <p class=\"w-result-list_col_title\">礼物收入</p>\r\n</div>\r\n<div class=\"w-result-list_col w-result-list_col_2\">\r\n    <p><label class=\"text-able-select js_barrage_value\"><%= data.barrage_value %></label><span class=\"w-result-list_unit\">条</span></p>\r\n    <p class=\"w-result-list_col_title\">弹幕量</p>\r\n</div>\r\n<div class=\"w-result-list_col w-result-list_col_3\">\r\n    <p><label class=\"text-able-select js_anchor\"><%= data.anchor %></label><span class=\"w-result-list_unit\">人</span></p>\r\n    <p class=\"w-result-list_col_title\">开播数</p>\r\n</div>\r\n<div class=\"w-result-list_col w-result-list_col_4\">\r\n    <p><label class=\"text-able-select js_new_anchor\"><%= data.new_anchor %></label><span class=\"w-result-list_unit\">人</span></p>\r\n    <p class=\"w-result-list_col_title\">新增主播</p>\r\n</div>");
	    this.opts = opts || {};
	    this.isAnimate = this.opts.anim || false;
	    this.isFirstRender = true;
	    this.params = {
	        category: this.opts.category,
	        platform: this.opts.platform
	    };
	
	    if (this.opts.pageType == 'index') {
	        this.$el = $('<div class="w-result-list w-result-list-big"></div>');
	    } else {
	        this.$el = $('<div class="w-result-list"></div>');
	    }
	    this.getData();
	}
	
	ResultList.prototype.render = function(data) {
	    if (this.isAnimate) {
	        if (this.isFirstRender) {
	            this.$el.html(this.template({
	                'data': {}
	            }));
	        }
	
	        this.numAnimStart(data.data);
	    } else {
	        for (var key in data.data) {
	            data.data[key] = Number(data.data[key]).toLocaleString();
	        }
	        this.$el.html(this.template({
	            'data': data.data
	        }));
	    }
	
	    return this;
	};
	ResultList.prototype.numAnimStart = function(data) {
	    var options = {
	        useEasing: false,
	        useGrouping: true,
	        separator: ',',
	        decimal: '.'
	    };
	
	    var per = 24 * 60;
	    var timeDis = 3; // 3分钟请求间隔
	    var delayDetect = 1; // 延迟1秒钟执行
	
	    if (this.isFirstRender) {
	        var self = this;
	
	        var anim_gift_value = new CountUp(this.$el.find('.js_gift_value')[0], 0, parseInt(Number(data.gift_value) * (per - timeDis) / per), 0, delayDetect, options);
	        anim_gift_value.start();
	        setTimeout(function() {
	            anim_gift_value = new CountUp(self.$el.find('.js_gift_value')[0], parseInt(Number(data.gift_value) * (per - timeDis) / per), Number(data.gift_value), 0, timeDis * 60 - delayDetect, options);
	            anim_gift_value.start();
	        }, delayDetect * 1000);
	
	        var anim_barrage_value = new CountUp(this.$el.find('.js_barrage_value')[0], 0, parseInt(Number(data.barrage_value) * (per - timeDis) / per), 0, delayDetect, options);
	        anim_barrage_value.start();
	        setTimeout(function() {
	            anim_barrage_value = new CountUp(self.$el.find('.js_barrage_value')[0], parseInt(Number(data.barrage_value) * (per - timeDis) / per), Number(data.barrage_value), 0, timeDis * 60 - delayDetect, options);
	            anim_barrage_value.start();
	        }, delayDetect * 1000);
	
	        var anim_anchor = new CountUp(this.$el.find('.js_anchor')[0], 0, parseInt(Number(data.anchor) * (per - timeDis) / per), 0, delayDetect, options);
	        anim_anchor.start();
	        setTimeout(function() {
	            anim_anchor = new CountUp(self.$el.find('.js_anchor')[0], parseInt(Number(data.anchor) * (per - timeDis) / per), Number(data.anchor), 0, timeDis * 60 - delayDetect, options);
	            anim_anchor.start();
	        }, delayDetect * 1000);
	
	        var anim_new_anchor = new CountUp(this.$el.find('.js_new_anchor')[0], 0, parseInt(Number(data.new_anchor) * (per - timeDis) / per), 0, delayDetect, options);
	        anim_new_anchor.start();
	        setTimeout(function() {
	            anim_new_anchor = new CountUp(self.$el.find('.js_new_anchor')[0], parseInt(Number(data.new_anchor) * (per - timeDis) / per), Number(data.new_anchor), 0, timeDis * 60 - delayDetect, options);
	            anim_new_anchor.start();
	        }, delayDetect * 1000);
	
	        this.isFirstRender = false;
	    } else {
	        if (Number(this.lastData.gift_value) < Number(data.gift_value)) {
	            if (!this.anim_gift_value) {
	                this.anim_gift_value = new CountUp(this.$el.find('.js_gift_value')[0], Number(this.lastData.gift_value), Number(data.gift_value), 0, timeDis * 60, options);
	                this.anim_gift_value.start();
	            } else {
	                this.anim_gift_value.update(Number(data.gift_value));
	            }
	        }
	
	        if (Number(this.lastData.barrage_value) < Number(data.barrage_value)) {
	            if (!this.anim_barrage_value) {
	                this.anim_barrage_value = new CountUp(this.$el.find('.js_barrage_value')[0], Number(this.lastData.barrage_value), Number(data.barrage_value), 0, timeDis * 60, options);
	                this.anim_barrage_value.start();
	            } else {
	                this.anim_barrage_value.update(Number(data.barrage_value));
	            }
	        }
	
	        if (Number(this.lastData.anchor) < Number(data.anchor)) {
	            if (!this.anim_anchor) {
	                this.anim_anchor = new CountUp(this.$el.find('.js_anchor')[0], Number(this.lastData.anchor), Number(data.anchor), 0, timeDis * 60, options);
	                this.anim_anchor.start();
	            } else {
	                this.anim_anchor.update(Number(data.anchor));
	            }
	        }
	
	        if (Number(this.lastData.new_anchor) < Number(data.new_anchor)) {
	            if (!this.anim_new_anchor) {
	                this.anim_new_anchor = new CountUp(this.$el.find('.js_new_anchor')[0], Number(this.lastData.new_anchor), Number(data.new_anchor), 0, timeDis * 60, options);
	                this.anim_new_anchor.start();
	            } else {
	                this.anim_new_anchor.update(Number(data.new_anchor));
	            }
	        }
	    }
	
	    this.lastData = data;
	};
	
	ResultList.prototype.getData = function(data) {
	    $.extend(this.params, data);
	    var self = this;
	    var path = "indust/all";
	    api.get(path, this.params).done(function(data) {
	        if (data.code == 0) {
	            self.render({
	                data: data.data
	            });
	        }
	    });
	};
	module.exports = ResultList;
});