define('widget/peopleReport', function(require, exports, module){
	var LieCharts = require('widget/lieCharts');
	
	
	var peopleReport = function (opts) {
	    this.template = _.template("<p class=\"w-peopleReport-describe\">\r\n    <span class=\"w-peopleReport-describe-change fl\"><i class=\"down anchor-info_follow_change\"></i>比上次直播上涨了<i class=\"w-peopleReport-describe-change-num down\">1560</i></span>\r\n    <span class=\"fl w-peopleReport-describe-time\">开播 <i class=\"w-peopleReport-describe-change-timeWait\">62分钟</i>后<i class=\"w-peopleReport-describe-change-time\">18:24</i>达到人气最高峰</span>\r\n</p>\r\n<div class=\"w-peopleReport-chart\"></div>");
	    this.opts = opts || {};
	    this.params = {
	
	    };
	    this.$el = $('<div class="w-peopleReport"></div>');
	    this.$peopleReport_chart = this.$el.find(".w-peopleReport-chart");
	    this.init();
	};
	
	peopleReport.prototype.init = function () {
	    this.render();
	    this.bindEvent();
	};
	
	peopleReport.prototype.bindEvent = function () {
	
	};
	
	peopleReport.prototype.render = function () {
	    this.$el.html(this.template());
	
	
	    this.LieCharts = new LieCharts();
	    this.$peopleReport_chart.html( this.LieCharts.$el );
	    this.LieCharts.init();
	    return this;
	};
	
	peopleReport.prototype.getData = function (data) {
	    $.extend(this.params, data);
	    var self = this;
	    api.get(path, this.params).done(function(data) {
	        if (data.code == 0) {
	
	        }
	    }).fail(function () {
	
	    });
	};
	
	module.exports = peopleReport;
});