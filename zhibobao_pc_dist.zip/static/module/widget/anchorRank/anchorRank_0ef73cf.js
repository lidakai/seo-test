define('widget/anchorRank', function(require, exports, module){
	
	var api = require('common/api');
	// 直播密度
	// 返回最近30天的直播
	// day表示周1-周日的，该日有过直播就加1；
	// time表示一天24小时的，1表示0-1点，24表示23-24点，在该范围内有在直播的就加1
	function anchorRank( data ) {
		this.template = _.template("<p class=\"anchor-rank-title\">最近一个月主播排名</p>\r\n<section class=\"anchor-rank-content text-able-select\">\r\n    <div class=\"add-after-content fl\">\r\n        <p class=\"anchor-rank-content-title\"><span class=\"gift-bg\">礼物</span></p>\r\n\r\n        <div class=\"fl\">\r\n            <p class=\"anchor-rank-content-value\"><%= anchorRank.gift.all %></p>\r\n            <p class=\"anchor-rank-content-platform\">全网排名\r\n                <span class=\"anchor-rank_tips tooltips-top\" data-tooltips=\"全网排名：以最近30天的礼物数据进行计算，得出全部直播平台中，主播所在分类的排名\"></span>\r\n            </p>\r\n        </div>\r\n        <div class=\"fl\">\r\n            <p class=\"anchor-rank-content-value\"><%= anchorRank.gift.platform %></p>\r\n            <p class=\"anchor-rank-content-platform\"><%= anchorRank.platformName %>排名\r\n                <span class=\"anchor-rank_tips tooltips-top\" data-tooltips=\"<%= anchorRank.platformName %>排名：以最近30天的礼物数据进行计算，得出主播所在的直播平台所在分类的排名\"></span>\r\n            </p>\r\n        </div>\r\n    </div>\r\n    <div class=\"fr\">\r\n        <p class=\"anchor-rank-content-title\"><span class=\"barrage-bg\">弹幕</span></p>\r\n        <div class=\"fl\">\r\n            <p class=\"anchor-rank-content-value\"><%= anchorRank.barrage.all %></p>\r\n            <p class=\"anchor-rank-content-platform\">全网排名\r\n                <span class=\"anchor-rank_tips tooltips-top\" data-tooltips=\"全网排名：以最近30天的弹幕数据进行计算，得出全部直播平台中，主播所在分类的排名\"></span>\r\n            </p>\r\n        </div>\r\n        <div class=\"fl\">\r\n            <p class=\"anchor-rank-content-value\"><%= anchorRank.barrage.platform %></p>\r\n            <p class=\"anchor-rank-content-platform\"><%= anchorRank.platformName %>排名\r\n                <span class=\"anchor-rank_tips tooltips-top\" data-tooltips=\"<%= anchorRank.platformName %>排名：以最近30天的弹幕数据进行计算，得出主播所在的直播平台所在分类的排名\"></span>\r\n            </p>\r\n        </div>\r\n    </div>\r\n</section>");
	
	    this.data =data;
		this.$el = $('<div></div>');
	};
	
	anchorRank.prototype.init = function() {
	    var self = this;
	    this.render({
	        data:self.data
	    })
	};
	anchorRank.prototype.render = function(data) {
		this.$el.html( this.template({
	        'anchorRank':data.data
		}));
		return this;
	};
	module.exports = anchorRank;
});