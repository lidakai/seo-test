define('page/rank', function(require, exports, module){
	var RankTab = require('widget/rankTab');
	var PlatformList = require('widget/platformList');
	var Rank = require('widget/rank');
	var CategoryList = require('widget/categoryList');
	var TimeList = require('widget/timeList');
	var RankUpdateTime = require('widget/rank/rankUpdateTime.js');
	
	function RankPage( opts ) {
	    this.opts = opts || {};
	    this.rankOption = {
	        userType: this.opts.userType,
	        platform: this.opts.platform,
	        category: this.opts.category,
	        limit: this.opts.limit,
	        timeType: this.opts.timeType,
	        timeValue: this.opts.timeValue
	    };
	    this._template = _.template("<div class=\"rank-bg\"></div>\r\n\r\n<div id=\"container\">\r\n    <div class=\"rank-title w1200\">榜单 <span>Billboard</span> </div>\r\n    <div class=\"rank-body\">\r\n        <div class=\"js-w-rank_rank_tab\"></div>\r\n\r\n        <div class=\"js-w-rank_platform_list\"></div>\r\n\r\n        <div class=\"js-w-rank_category_list\"></div>\r\n\r\n        <div class=\"js-w-rank_timeList\"><div class=\"js-w-rank_rankUpdateTime\"></div></div>\r\n\r\n        <div class=\"js-w-rank_content clearfix\">\r\n            <div class=\"js-w-rank_gift\"></div>\r\n            <div class=\"js-w-rank_barrage\"></div>\r\n            <div class=\"js-w-rank_money\"></div>\r\n        </div>\r\n\r\n    </div>\r\n</div>");
		this.$el = $('<div class="rank-wrap"></div>');
		this.$el.html(this._template());
	
		this.$platform_list = this.$el.find('.js-w-rank_platform_list');
		this.$rank_tab = this.$el.find('.js-w-rank_rank_tab');
		this.$gift_rank = this.$el.find('.js-w-rank_gift');
		this.$barrage_rank = this.$el.find('.js-w-rank_barrage');
		this.$money_rank = this.$el.find('.js-w-rank_money');
		this.$category_list = this.$el.find('.js-w-rank_category_list');
		this.$timelist = this.$el.find('.js-w-rank_timeList');
		this.$rank_update_time = this.$el.find('.js-w-rank_rankUpdateTime');
		this.init();
	}
	
	RankPage.prototype.init = function() {
		this.bindEvent();
		this.render();
	};
	
	RankPage.prototype.bindEvent = function() {
		var self = this;
		//初始化分类列表再初始化礼物、弹幕榜单
		$.sub('category/getCategory', function(e, data) {
	        self.rankOption.category = data.category;
			if( self.rankOption.userType == 'user' ){
				self.renderMoneyRank();
			}else{
				self.renderRank();
			}
		});
	
		//tab切换监听
		$.sub('rankTab/change', function(e, data) {
	        self.rankOption.userType = data.userType;
	        if( data.userType == "new_anchor" && self.rankOption.timeType == 'dayRange' ){
	                self.rankOption.timeType = 'hour';
	                self.rankOption.timeValue = 1;
	        }
	        self.location();
		});
	
		//平台切换监听
		$.sub('platform/change', function(e, data) {
	        self.rankOption.platform = data.platform;
	        self.location();
		});
	
		//直播频道监听
		$.sub('category/change', function(e, data) {
			self.rankOption.category = data.category;
	        self.location();
		});
	
		//  时间监听
		$.sub('timeType/change', function(e, data) {
			self.rankOption.timeType = data.timeType;
			self.rankOption.timeValue = data.timeValue;
	        self.location();
		});
	
		//更新時間監聽
		$.sub('rank/updateEnd', function(e, data) {
			self.rankUpdateTime.update(data);
		});
	};
	RankPage.prototype.render = function() {
		this.rankTab = new RankTab({
	        'userType':this.rankOption.userType
		});
		this.$rank_tab.html(this.rankTab.$el);
	
		this.platformList = new PlatformList({
	        'platform':this.rankOption.platform
		});
		this.$platform_list.html(this.platformList.$el);
	
		this.categoryList = new CategoryList({
			'hasAllCate': true,
			'platform':this.rankOption.platform,
			'category':this.rankOption.category
		});
		this.$category_list.append(this.categoryList.$el);
	
		this.companyTimeList = new TimeList({
	        'hasAllCate': true,
			'userType':this.rankOption.userType,
	        'timeType':this.rankOption.timeType,
	        'timeValue':this.rankOption.timeValue
		});
		this.$timelist.prepend(this.companyTimeList.$el);
	
	    this.rankUpdateTime = new RankUpdateTime({
	        timeType: this.rankOption.timeType,
	        timeValue: this.rankOption.timeValue
	    });
	    this.$rank_update_time.html(this.rankUpdateTime.$el);
		return this;
	};
	
	RankPage.prototype.renderRank = function() {
	    this.giftRank = new Rank({
			userType: this.rankOption.userType,
			rankType: 'gift',
			platform: this.rankOption.platform,
			category: this.rankOption.category,
			limit: this.rankOption.limit,
			timeType: this.rankOption.timeType,
			timeValue: this.rankOption.timeValue
		});
		this.$gift_rank.html(this.giftRank.$el);
	
		this.barrageRank = new Rank({
			userType: this.rankOption.userType,
			rankType: 'barrage',
			platform: this.rankOption.platform,
			category: this.rankOption.category,
			limit: this.rankOption.limit,
			timeType: this.rankOption.timeType,
			timeValue: this.rankOption.timeValue
		});
		this.$barrage_rank.html(this.barrageRank.$el);
	};
	RankPage.prototype.renderMoneyRank = function() {
	    this.moneyRank = new Rank({
			userType: 'user',
			rankType: 'gift',
			platform: this.rankOption.platform,
			category: this.rankOption.category,
			limit: this.rankOption.limit,
			timeType: this.rankOption.timeType,
			timeValue: this.rankOption.timeValue
		});
		this.$money_rank.html(this.moneyRank.$el);
	};
	//页面无刷新修改url
	RankPage.prototype.location=function () {
	    page('/rank?platform='+this.rankOption.platform
	        +'&category='+this.rankOption.category
	        +'&userType='+this.rankOption.userType
	        +'&limit='+this.rankOption.limit
	        +'&timeType='+this.rankOption.timeType
	        +'&timeValue='+this.rankOption.timeValue);
	};
	
	RankPage.prototype.destroy = function() {
		this.$el.remove();
		this.$el = null;
		$.unsub('category/getCategory');
		$.unsub('rankTab/change');
		$.unsub('platform/change');
		$.unsub('category/change');
		$.unsub('timeType/change');
		$.unsub('rank/updateEnd');
	};
	
	module.exports = function(ctx, callback) {
		callback(new RankPage({
	        platform: decodeURIComponent(ctx.query.platform || ''),
	        userType: decodeURIComponent(ctx.query.userType || 'anchor'),
	        category: decodeURIComponent(ctx.query.category || ''),
	        limit: decodeURIComponent(ctx.query.limit || 100),
	        timeType: decodeURIComponent(ctx.query.timeType || 'hour'),
	        timeValue: decodeURIComponent(ctx.query.timeValue || '1')
		}));
	};
});