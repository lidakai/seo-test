#!/bin/bash
# rm -rf ../zhibobao_pc_dist/static
fis release -compd ../zhibobao_pc_dist