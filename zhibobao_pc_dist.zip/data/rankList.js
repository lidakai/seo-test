const request = require('./myRequest');
const globalConfig = require('./global.js');

/**
 * @param {String} [userType] [用户类型，主播'anchor', 新晋主播'new_anchor', 土豪'user']
 * @param {String} [platform]   [douyu，huya，quanmin，平台名拼音,没有的话则为全平台]
 * @param {Number} [category]   [类型，不传为全部]
 * @param {String} [timeType]   [时间类型：5分钟为minute、1小时为hour，今日为today；历史时间单日的为day；历史时间范围的为dayRange；]
 * @param {Number | String | Array} [timeValue] [对应时间类型的值：5分钟为5；1小时为1；历史单日如2017-08-10；历史范围为“[2017-07-01,2017-07-30]”]
 * @param {String | Array } [rankType] [榜单类型，'gift', 'barrage']
 * @param {Number} [limit] [限制展示的数量，默认不限制]
 */

var rankList = (opts) => {
    opts = opts || {};

    var formData = {
        userType: opts.userType || 'anchor',
        platform: opts.platform,
        category: opts.category,
        timeType: opts.timeType || 'hour',
        timeValue: opts.timeValue || 1,
        rankType: opts.rankType || 'gift',
        limit: opts.limit || 5
    };

    return new Promise(function(resolve, reject) {
        request.get({
            url: '/rank/list',
            formData: formData
        }, function(error, response, body) {
            if (!error && response.statusCode == 200) {
                var data = JSON.parse(body);
                if (data.code == 0) {
                    for (var i = 0, len = data.data.list.length; i < len; i++) {
                        data.data.list[i].platformName = globalConfig.platformName[data.data.list[i].platform];
                        if (formData.userType == 'user') {
                            data.data.list[i].platformDefaultAvatar = globalConfig.platformDefaultAvatar[data.data.list[i].platform];
                        } else {
                            data.data.list[i].platformDefaultAvatar = globalConfig.platformDefaultAvatar['default'];
                        }
                        data.data.list[i].avatar = globalConfig.parseAvatar([data.data.list[i].avatar]);

                        if(formData.rankType == 'gift') {
                            data.data.list[i].value = data.data.list[i].value.toFixed(2);
                        }
                    }

                    formData.data = data.data;
                    resolve(formData);
                } else {
                    data.reqUrl = response.req.path;
                    reject(data);
                }
            }
        });
    });
};

module.exports = rankList;