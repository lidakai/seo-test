module.exports = {
	parseAvatar: function(str) {
		if (!str) {
			return this.platformDefaultAvatar['default'];
		}
		if (/^https?:\/\//.test(str)) {
			return str;
		}
		return 'http://fentuan-image.oss-cn-hangzhou.aliyuncs.com/' + str;
	},
	platformDefaultAvatar: {
		default: '/static/lib/tools/avatar/zhibobao_ee6d698.png',
		douyu: '/static/lib/tools/avatar/douyu_bb8fb2d.png',
		huya: '/static/lib/tools/avatar/huya_c561678.png',
		quanmin: '/static/lib/tools/avatar/quanmin_baff0a0.png',
		panda: '/static/lib/tools/avatar/panda_d16bba6.png',
		zhanqi: '/static/lib/tools/avatar/zhanqi_0f14959.png',
		longzhu: '/static/lib/tools/avatar/longzhu_cbf72d6.png',
		chushou: '/static/lib/tools/avatar/chushou_daf3779.png'
	},
	platformName: {
		douyu: '斗鱼',
		huya: '虎牙',
		quanmin: '全民',
		panda: '熊猫',
		zhanqi: '战旗',
		longzhu: '龙珠',
		chushou: '触手'
	},
	platformUnit: {
		douyu: '鱼翅',
		huya: '金豆',
		quanmin: '牛币',
		panda: '猫币',
		zhanqi: '金币',
		longzhu: '龙币',
		chushou: '触手币'
	}
};