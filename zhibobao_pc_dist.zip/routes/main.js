var moment = require('moment');
var industry = require('../data/industry');
var platformList = require('../data/platformList');
var categoryList = require('../data/categoryList');
var rankList = require('../data/rankList');

var tvDomain = require('./tvDomain');

module.exports = function(req, res, next) {
	if (tvDomain(req.hostname) && req.path == '/') {
		res.render('page/tool/tool', {
			g_isTvDomain: true,
			pageType: 'tool',
			title: '专业游戏直播工具_直播宝_直播平台大数据'
		});
	} else {
		var opts = {
			'platform': '',
			'userType': 'anchor'
		};

		var arrRequest = [industry(opts), platformList(opts), rankList(Object.assign({}, opts, {
			'rankType': 'gift',
			'limit': 5
		})), rankList(Object.assign({}, opts, {
			'rankType': 'barrage',
			'limit': 5
		})), categoryList(Object.assign({}, opts, {
			'platform': ''
		}))];

		Promise.all(arrRequest).then((arrValue) => {
			var industryData = arrValue[0];
			var platformListData = arrValue[1];
			var rankListGiftData = arrValue[2];
			var rankListBarrageData = arrValue[3];
			var categoryListData = arrValue[4];

			var updateTime = Math.max(parseInt(rankListGiftData.data.timestamp), parseInt(rankListBarrageData.data.timestamp));
			updateTime = moment(updateTime * 1000).format('HH:mm');

			res.render('page/main/main', {
				g_isTvDomain: tvDomain(req.hostname),
				title: '主播榜单_直播宝_直播平台大数据',
				isMainPage: true,
				pageType: 'main',
				curUserType: opts.userType,
				curTimeType: 'hour',
				curTimeValue: 1,
				industryData: industryData,
				platformListData: platformListData,
				rankListGiftData: rankListGiftData,
				rankListBarrageData: rankListBarrageData,
				categoryListData: categoryListData,
				updateTime: updateTime
			});
		}).catch((e) => {
			console.warn('===== warn =====', e);
			res.render('error', {
				message: e.msg,
				code: e.code
			});
		});
	}
}