var express = require('express');
var debug = require('debug')('node-site:server');
var http = require('http');
var request = require('request');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var nunjucks = require('nunjucks');

var config = require('./config');
var routes = require('./routes/index');

var app = express();

// view engine setup
nunjucks.configure(path.join(__dirname, 'views'), { // 设置模板文件的目录，为views
  noCache: true,
  autoescape: true,
  express: app
});
app.set('view engine', 'html'); // 模板文件的后缀名字为html

// app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
  extended: false
}));
app.use(cookieParser());

app.use(express.static(path.join(__dirname)));
// app.use(express.static(path.join(__dirname, 'static')));

app.use('/', routes);

var PROXY = config.proxy;
console.log('[D] proxy to %s', PROXY);

app.use(function(req, res, next) {
  var originalUrl = req.originalUrl.replace('\/api', '');
  var url = PROXY + originalUrl;
  // var url = 'http://' + PROXY + '.zhibobao.com' + originalUrl;
  console.log('[D] proxy: %s => %s', originalUrl, url);

  var tStart = new Date();

  var x = request({
    url: url,
    headers: {
      't-code': req.headers['t-code']
    }
  }, function(error, response, body) {
    if (error) {
      console.log('[D] error:', url, error);
    }

    var tEnd = new Date();
    var diff = tEnd.getTime() - tStart.getTime();
    if (diff > 1000) {
      console.warn('[D] proxy-api time: %s ms => %s', diff, url);
    } else {
      console.log('[D] proxy-api time: %s ms => %s', diff, url);
    }
  });

  x.pipe(res);
});

var port = config.port
app.set('port', port);

var server = http.createServer(app);

server.listen(port);
server.on('error', onError);
server.on('listening', onListening);


/**
 * Event listener for HTTP server "error" event.
 */

function onError(error) {
  if (error.syscall !== 'listen') {
    throw error;
  }

  var bind = typeof port === 'string' ? 'Pipe ' + port : 'Port ' + port;

  // handle specific listen errors with friendly messages
  switch (error.code) {
    case 'EACCES':
      console.error(bind + ' requires elevated privileges');
      process.exit(1);
      break;
    case 'EADDRINUSE':
      console.error(bind + ' is already in use');
      process.exit(1);
      break;
    default:
      throw error;
  }
}


function onListening() {
  var addr = server.address();
  var bind = typeof addr === 'string' ? 'pipe ' + addr : 'port ' + addr.port;
  debug('Listening on ' + bind);

  console.log('app listening at http://%s:%s', addr.host || 'localhost', addr.port);
}