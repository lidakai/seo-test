const APP_ENV = process.env.NODE_ENV || 'dev';

var config;

if(APP_ENV == 'master') {
	config = require('./prod.config.js');
} else {
	config = require('./dev.config.js');
}

module.exports = config;