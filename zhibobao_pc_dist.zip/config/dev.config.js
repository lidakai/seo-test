module.exports = {
	env: 'dev',
	proxy: 'http://test-api.zhibobao.com',
	port: 3008
};